// console.log("this runs");
var cols = [];
var colsSelected = [];
var rootSelect = "Count"

var choicesSelected = [];

var clicksOut = 0;
var clicksIn = 0;

var count = 0;

var pastSvg = "";

// generateChart(false);


function ans(num){
	var title = document.getElementById("title");
	title.class = "questionTitle"
	var caption = document.getElementById("caption");
	caption.class = "questionCaption"


	if (num === 1){
		colsSelected = ["Sub Industry  (SSIC 2010)","Occupation","Pct Manual Work","Cause"];
		title.innerHTML = "Which industries did accidents happen the most? Which jobs? Were their work mostly manual labour? What was the cause?"
		caption.innerHTML = "Perhaps heavy industries tend to have the highest injury count - perhaps not. Perhaps certain occupations with manual labor tend to have more injuries, and of a certain type. \n You can see the proportion of injuries by industry. Click on one to drill-down into one, and see the occupations with the highest injury count in that industry. Thereafter, you can know if the work involved consists of manual labour, and the cause of the accident. This allows one to navigate through the levels with ease, proceeding forward or backward only when fully appreciating the data at each level of the hierarchy. \n\n You can click on the orange breadcrumbs to go back a level. \n\n"

	} else if (num === 2){
		colsSelected = ["Nature of Injury", "Accident Time", "Cause", "Sub Industry  (SSIC 2010)"];
		title.innerHTML = "Which injuries happened the most at which times? What industry?"
		caption.innerHTML = "Odd or late hours tend to be when we are at our lowest levels of concentration, possibly leading to accidents. After-lunch sleepiness could also affect our focus. Could there be a correlation between these timings and the injuries, perhaps of a certain type? \n You can see the proportion of injuries by its type, and the timings when they tend to occur. Click on one to drill-down, and see the timings, cause and industry they happen frequently in. Thereafter, you can know if there are patterns to the timings for each injury. \n\n You can click on the orange breadcrumbs to go back a level. \n\n"
	} else if (num === 3){
		colsSelected = ["Cause", "Accident Agency Level 2 Desc"];
		title.innerHTML = "What type of accident happened, what objects where involved?"
		caption.innerHTML = "What were the common accidents, and what equipment, tools or objects were involved? This question aims to uncover a pattern between these two variables - if the count is higher for a certain object, further investigation can be done on the operational processes or its individual handling. Perhaps the object is faulty, or the nature of its handling make it accident-prone.\n You can see the types of accidents, and for each, the objects involved. Click on one to drill-down and make comparisons to other types of accidents. \n\n You can click on the orange breadcrumbs to go back a level. \n\n"
		
	} else if (num === 4){
		colsSelected = ["Nature of Injury", "Months worked"];
		title.innerHTML = "For those who were injured, how long have they been working in the company?"
		caption.innerHTML = "Perhaps it isn't the tool/object that is at fault. Accidents could arise due to the inexperience of the individual, and this question aims to let us know if it is true. \n You can see the types of injuries, and the work experience of the victims. We can compare between the types of injuries and see if a large proportion belong to those who have only been with the company for a relatively short period of time. \n\n You can click on the orange breadcrumbs to go back a level. \n\n"
		
	} else if (num === 5){
		colsSelected = ["Accident Date", "Reported Date", "Informant's Company Name"];
		title.innerHTML = "How long did informant/company wait to report the injury? Which companies were these?"
		caption.innerHTML = "There have been cases where companies do what they can to cover up workplace injuries, even delaying sending the staff for medical treatment. In this question, we want to see how long the gap was between the accident time and reported time. \n You can see which companies have delayed the report by clicking on another date in the second level, thereafter seeing which companies have done so. The company names are in ID format, but this is useful for watchdog organizations looking out for such practices. \n\n You can click on the orange breadcrumbs to go back a level. \n\n"
		
	} else if (num === 6){
		colsSelected = ["Accident Agency Level 2 Desc", "Accident Weekday", "Accident Time"];
		title.innerHTML = "For each type of accident, which day of the week did they frequently occur on? Which times of the day did accidents occur the most?"
		caption.innerHTML = "Related to time, we want to see if there is a certain day of the week and time of that day when accidents occur. \n Categorizing by injury, you can see which injuries make up the bulk, and when it usually occurs. \n\n You can click on the orange breadcrumbs to go back a level. \n\n"
		
	} else if (num === 7){
		colsSelected = ["Major Injury Indicator", "Nature of Injury", "Accident Agency Level 2 Desc", "No. of MC Days", "Hospitalised for at least 24 hours"];
		title.innerHTML = "How bad were the injuries?"
		caption.innerHTML = "We want to know the severity of the injuries, based on how long the victim was given to rest and whether they were hospitalized. Adding the accident category also lets us know if some cases were treated differently from others. For example, there were news reports of construction workers having only half or a day's medical leave when they had a part of their finger missing. \n Depending on the severity of the injury, you can see which injuries required more rest, and compare between other cases were it was recognized as severe, but given with less rest - perhaps even without hospitalization. \n\n You can click on the orange breadcrumbs to go back a level. \n\n"
		
	} else if (num === 8){
		colsSelected = ["Major Injury Indicator", "Supposed Start Work Timing on Day Injured", "Nature of Injury"];
		title.innerHTML = "Did major injuries happen during shift periods, late at night, during OT? What types of injuries?"
		caption.innerHTML = "In the context of severe injuries, we can discover if they tended to happen when workers were working late or on overtime, indicating tiredness leading to accidents. \n For major injuries, you can see when the victim has started work and the injury incurred. \n\n You can click on the orange breadcrumbs to go back a level. \n\n"
		
	}
	
	generateChart(true);

}

function applyCols(){

	$('*[id*=view-hierarchy-selector-]:visible').each(function() {

    // console.log(this);
	    if (this.value.indexOf("Set Level") == -1){
	    	colsSelected.push(this.value.toString());
	    }
	});
	// console.log(colsSelected);

    // console.log(colsSelected);
    var title = document.getElementById("title");
	title.innerHTML = ""
	var caption = document.getElementById("caption");
	caption.innerHTML = ""
    generateChart(true);

}




function generateChart(custom) {
	clearDrawings();

	// console.log($('chart' + count + " g"));
	// $('#chart' + count + " path").remove();
	// console.log(pastChart);
	// pastChart.innerHTML = null;

	var margin = {top: 30, right: 0, bottom: 0, left: 0},
    width = 1100,
    height = 580 - margin.top - margin.bottom,
    formatNumber = d3.format(""),
    // colorDomain = [-.1, 0, .1],
	// colorRange = ['#dda8db', '#ebf2f7', '#9cbdd9'],
    transitioning;

  //   var color = d3.scale.linear()
		// .domain(colorDomain)
		// .range(colorRange);

	var color = d3.scale.category20();

/* create x and y scales */
var x = d3.scale.linear()
	.domain([0, width])
	.range([0, width]);

var y = d3.scale.linear()
	.domain([0, height])
	.range([0, height]);

var treemap = d3.layout.treemap()
	.children(function(d, depth) { return depth ? null : d.children; })
	.sort(function(a, b) { return a.value - b.value; })
	.ratio(height / width * 0.5 * (1 + Math.sqrt(5)))
	.round(false);

	/* create svg */
var svg = d3.select("#chart" + count).append("svg")
	.attr("width", width + margin.left + margin.right)
	.attr("height", height + margin.bottom + margin.top)
	.style("margin-left", -margin.left + "px")
	.style("margin.right", -margin.right + "px")
	.append("g")
	.attr("transform", "translate(" + margin.left + "," + margin.top + ")")
	.style("shape-rendering", "crispEdges");
	count++;

	// pastSvg = svg;





var grandparent = svg.append("g")
	.attr("class", "grandparent");

grandparent.append("rect")
	.attr("y", -margin.top)
	.attr("width", width)
	.attr("height", margin.top);

grandparent.append("text")
	.attr("x", 5)
	.attr("y", 5 - margin.top)
	.attr("dy", ".75em");

function initialize(root) {
	root.x = root.y = 0;
	root.dx = width;
	root.dy = height;
	root.depth = 0;
}

// Aggregate the values for internal nodes. This is normally done by the
// treemap layout, but not here because of the custom implementation.
function accumulate(d) {
	return d.children
	? d.value = d.children.reduce(function(p, v) { return p + accumulate(v); }, 0)
	: d.value;
}

// Compute the treemap layout recursively such that each group of siblings
// uses the same size (1×1) rather than the dimensions of the parent cell.
// This optimizes the layout for the current zoom state. Note that a wrapper
// object is created for the parent node for each group of siblings so that
// the parent’s dimensions are not discarded as we recurse. Since each group
// of sibling was laid out in 1×1, we must rescale to fit using absolute
// coordinates. This lets us use a viewport to zoom.
function layout(d) {
	if (d.children) {
		treemap.nodes({children: d.children})
		d.children.forEach(function(c) {
			c.x = d.x + c.x * d.dx;
			c.y = d.y + c.y * d.dy;
			c.dx *= d.dx;
			c.dy *= d.dy;
			c.parent = d;
			layout(c);
		});
	}
}


/* display shows the treemap and writes the embedded transition function */
function display(d) {
/* create grandparent bar at top */
	grandparent
		.datum(d.parent)
		.on("click", transition)
		.select("text")
		.text(name(d));

	var g1 = svg.insert("g", ".grandparent")
		.datum(d)
		.attr("class", "depth");
		/* add in data */
	var g = g1.selectAll("g")
		.data(d.children)
		.enter().append("g");
		/* transition on child click */
	g.filter(function(d) { return d.children; })
		.classed("children", true)
		.on("click", transition);
		/* write children rectangles */
	g.selectAll(".child")
		.data(function(d) { return d.children || [d]; })
		.enter().append("rect")
		.attr("class", "child")
		.call(rect)
		.append("title")
		.text(function(d) { return d.name + " " + formatNumber(d.size); });

	/* write parent rectangle */
	g.append("rect")
		.attr("class", "parent")
		.attr("style", "opacity")
		.call(rect)
		/* open new window based on the json's URL value for leaf nodes */
		/* Chrome displays this on top */
		.on("click", function(d) { 
			if(!d.children){
				// window.open(d.url);
				alert("Oops, you've reached the last level!");
			}
		})
		.append("title")
		.text(function(d) { return d.name + " " + formatNumber(d.value); });

	/* Adding a foreign object instead of a text object, allows for text wrapping */
	g.append("foreignObject")
		.call(rect)
		/* open new window based on the json's URL value for leaf nodes */
		/* Firefox displays this on top */
		.on("click", function(d) { 
			if(!d.children){
				alert("Oops, you've reached the last level!");
			}
		})
		.attr("class","foreignobj")
		.append("xhtml:div") 
		.attr("dy", ".75em")
		.html(function(d) { 
			if (d.size) {
				console.log(d.size)
				if (d.value == "undefined"){
					return "LAST LEVEL";
				}
				return d.name + " (" + formatNumber(d.size) + ")"; 
			} 
			if (d.value > 0 && typeof(d.value) !== "undefined") {
				return d.name + " (" + formatNumber(d.value) + ")";  //this is shown at the last level of the hierarchy view
				// return formatNumber(d.value);
			}


			return d.name;
		})
		.attr("class","textdiv"); //textdiv class allows us to style the text easily with CSS
			/* create transition function for transitions */
	function transition(d) {
		if (transitioning || !d) return;
		transitioning = true;
		var g2 = display(d),
		    t1 = g1.transition().duration(550),
		    t2 = g2.transition().duration(550);
			// Update the domain only after entering new elements.
		x.domain([d.x, d.x + d.dx]);
		y.domain([d.y, d.y + d.dy]);
			// Enable anti-aliasing during the transition.
		svg.style("shape-rendering", null);

		// Draw child nodes on top of parent nodes.
		svg.selectAll(".depth").sort(function(a, b) { return b.depth; });
		// Fade-in entering text.
		g2.selectAll("text").style("fill-opacity", 0);
		g2.selectAll("foreignObject div").style("display", "none"); /*added*/
		// Transition to the new view.
		t1.selectAll("text").call(text).style("fill-opacity", 0);
		t2.selectAll("text").call(text).style("fill-opacity", 1);
		t1.selectAll("rect").call(rect);
		t2.selectAll("rect").call(rect);


		//these are to 'hide' the child nodes
		t1.selectAll(".textdiv").style("display", "none"); /* added */
		t1.selectAll(".foreignobj").call(foreign); /* added */
		t2.selectAll(".textdiv").style("display", "block"); /* added */
		t2.selectAll(".foreignobj").call(foreign); /* added */ 

		// Remove the old node when the transition is finished.
		t1.remove().each("end", function() {
			svg.style("shape-rendering", "crispEdges");
			transitioning = false;
		});
		// console.log(d);

	}//endfunc transition

	return g;
}//endfunc display

function getContrast50(hexcolor){
		return (parseInt(hexcolor.replace('#', ''), 16) > 0xffffff/3) ? 'black':'white';
	}

function text(text) {
	text.attr("x", function(d) { return x(d.x) + 6; })
	    .attr("y", function(d) { return y(d.y) + 6; })
        .attr("fill", function (d) {return getContrast50(color(parseFloat(d.rate)))});
  
}

function rect(rect) {
	rect.attr("x", function(d) { return x(d.x); })
 		.attr("y", function(d) { return y(d.y); })
		.attr("width", function(d) { return x(d.x + d.dx) - x(d.x); })
		.attr("height", function(d) { return y(d.y + d.dy) - y(d.y); })
		.style("fill", function(d) { return d.parent ? color(d.name) : null; })
        // .attr("fill", function(d){return color(parseFloat(d.name));});
}

function foreign(foreign){ /* added */
	foreign.attr("x", function(d) { return x(d.x); })
		.attr("y", function(d) { return y(d.y); })
		.attr("width", function(d) { return x(d.x + d.dx) - x(d.x); })
		.attr("height", function(d) { return y(d.y + d.dy) - y(d.y); });
}

function name(d) {
	return d.parent ? name(d.parent) + " >>> " + d.name : d.name;
}


function loadData(root) {
	initialize(root);
	accumulate(root);
	layout(root);
	display(root);
}

function reSortRoot(root,value_key) {
		//console.log("Calling");
		for (var key in root) {
			if (key == "key") {
				root.name = root.key;
				delete root.key;
			}
			if (key == "values") {
				root.children = [];
				for (item in root.values) {
					// console.log(item)
					root.children.push(reSortRoot(root.values[item],value_key));
				}


				delete root.values;
			}
			if (key == value_key) {
				root.value = parseFloat(root[value_key]);
				delete root[value_key];
			}
		}
		// console.log(root);
		return root;
	}


function createNestingFunction(propertyName){
  return function(d){ 
            return d[propertyName];
         };
}



		var temp = document.createElement("div");
		temp.id = "chart" + count;

		$("#chartArea").prepend(temp);
		


    	d3.csv(treemap_fileName, function(csv_data){

			// Add, remove or change the key values to change the hierarchy. 

			if (custom === true) {


				var nested_data = d3.nest();

	      		for (var i in colsSelected){
	  				var col = colsSelected[i];
	  				// console.log(col);
	  				nested_data = nested_data.key(createNestingFunction(col));
	      		};	
	      		// console.log(nested_data.toString())
	   				
					// .entries(csv_data);
				
				// Creat the root node for the treemap
				var root = {};
				
				// Add the data to the tree
				// root.values = nested_data;
				
				root.key = colsSelected[0]
				root.values = nested_data.entries(csv_data);
			
				// Change the key names and children values from .next and add values for a chosen column to define the size of the blocks
				
				// console.log("Selected root: " + rootSelect)
				root = reSortRoot(root, rootSelect);
				
				
				loadData(root);
				colsSelected = [];
				// console.log("this runs");

				
			} else {
				//for custom or fixed hierarchies
				// console.log("this runs");

				var nested_data = d3.nest()
	   				.key(function(d)  { return d["Sub Industry  (SSIC 2010)"]; })
	   				.key(function(d)  { return d["Occupation"]; })
	   				.key(function(d)  { return d["Cause"]; })
	   				.key(function(d)  { return d["Nature of Injury"]; })
	   				.key(function(d)  { return d["Body Parts Injured"]; })

	   				.entries(csv_data);

	   				var root = {};
				
					root.key = "Sub Industry  (SSIC 2010)"
					root.values = nested_data;
					root = reSortRoot(root, "Count");
					loadData(root);
			}

		});


		// console.log("chart" + count-1);
		// pastChart.toggle();
}

 function clearDrawings(){
    d3.selectAll("svg > *").remove();
}
