var data = [
["2007",
{className:"Aruba",
axes: [
{axis:"Inflation",value:"5.39120264"},
{axis:"Deposit Interest Rate",value:"4.033333333"},
{axis:"Lending Interest Rate",value:"11.00833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.654626242"},
{axis:"Unemployment",value:""}]
    },
{className:"Andorra",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.078039378"},
{axis:"Unemployment",value:""}]
    },
{className:"Afghanistan",
axes: [
{axis:"Inflation",value:"8.482889268"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"18.135"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"13.74020499"},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"Angola",
axes: [
{axis:"Inflation",value:"12.24867552"},
{axis:"Deposit Interest Rate",value:"6.756433685"},
{axis:"Lending Interest Rate",value:"17.6988356"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"22.5930543"},
{axis:"Unemployment",value:"6.699999809"}]
    },
{className:"Albania",
axes: [
{axis:"Inflation",value:"2.932682482"},
{axis:"Deposit Interest Rate",value:"5.65909854"},
{axis:"Lending Interest Rate",value:"14.09962279"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.900000009"},
{axis:"Unemployment",value:"13.5"}]
    },
{className:"United Arab Emirates",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.184390174"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"Argentina",
axes: [
{axis:"Inflation",value:"8.831412989"},
{axis:"Deposit Interest Rate",value:"7.971632256"},
{axis:"Lending Interest Rate",value:"11.05203333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.01574459"},
{axis:"Unemployment",value:"8.5"}]
    },
{className:"Armenia",
axes: [
{axis:"Inflation",value:"4.407360896"},
{axis:"Deposit Interest Rate",value:"6.254303237"},
{axis:"Lending Interest Rate",value:"17.51568537"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"13.74920196"},
{axis:"Unemployment",value:"28.39999962"}]
    },
{className:"Antigua and Barbuda",
axes: [
{axis:"Inflation",value:"1.416052594"},
{axis:"Deposit Interest Rate",value:"3.523923934"},
{axis:"Lending Interest Rate",value:"10.43853504"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.49894448"},
{axis:"Unemployment",value:""}]
    },
{className:"Australia",
axes: [
{axis:"Inflation",value:"2.332361516"},
{axis:"Deposit Interest Rate",value:"4.529166667"},
{axis:"Lending Interest Rate",value:"8.195833333"},
{axis:"Central Government Debt",value:"20.27246427"},
{axis:"GDP",value:"3.757657864"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Austria",
axes: [
{axis:"Inflation",value:"2.168599053"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.621510423"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Azerbaijan",
axes: [
{axis:"Inflation",value:"16.59536673"},
{axis:"Deposit Interest Rate",value:"11.55666667"},
{axis:"Lending Interest Rate",value:"19.13083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"25.04899952"},
{axis:"Unemployment",value:"6.300000191"}]
    },
{className:"Burundi",
axes: [
{axis:"Inflation",value:"8.342032406"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"16.84333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.785831951"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Belgium",
axes: [
{axis:"Inflation",value:"1.822063641"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"8.570833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.397471914"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Benin",
axes: [
{axis:"Inflation",value:"1.298068133"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.986515522"},
{axis:"Unemployment",value:"1.100000024"}]
    },
{className:"Burkina Faso",
axes: [
{axis:"Inflation",value:"-0.230627306"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.655005118"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Bangladesh",
axes: [
{axis:"Inflation",value:"9.106984969"},
{axis:"Deposit Interest Rate",value:"6.993333333"},
{axis:"Lending Interest Rate",value:"12.635"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.058636206"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Bulgaria",
axes: [
{axis:"Inflation",value:"8.402486753"},
{axis:"Deposit Interest Rate",value:"3.68195"},
{axis:"Lending Interest Rate",value:"9.997766667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.675350685"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Bahrain",
axes: [
{axis:"Inflation",value:"3.256666667"},
{axis:"Deposit Interest Rate",value:"4.485"},
{axis:"Lending Interest Rate",value:"8.266342679"},
{axis:"Central Government Debt",value:"7.545455934"},
{axis:"GDP",value:"8.292443822"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"The Bahamas",
axes: [
{axis:"Inflation",value:"2.492577949"},
{axis:"Deposit Interest Rate",value:"3.690833333"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.446522215"},
{axis:"Unemployment",value:"7.900000095"}]
    },
{className:"Bosnia and Herzegovina",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"3.555833333"},
{axis:"Lending Interest Rate",value:"7.1725"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.728757014"},
{axis:"Unemployment",value:"29.70000076"}]
    },
{className:"Belarus",
axes: [
{axis:"Inflation",value:"8.421500392"},
{axis:"Deposit Interest Rate",value:"8.308333333"},
{axis:"Lending Interest Rate",value:"8.575"},
{axis:"Central Government Debt",value:"8.909260816"},
{axis:"GDP",value:"8.6"},
{axis:"Unemployment",value:"6.300000191"}]
    },
{className:"Belize",
axes: [
{axis:"Inflation",value:"2.315984293"},
{axis:"Deposit Interest Rate",value:"8.3225"},
{axis:"Lending Interest Rate",value:"14.33333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.105586127"},
{axis:"Unemployment",value:"8.5"}]
    },
{className:"Bermuda",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.845890114"},
{axis:"Unemployment",value:""}]
    },
{className:"Bolivia",
axes: [
{axis:"Inflation",value:"8.706247231"},
{axis:"Deposit Interest Rate",value:"3.545541667"},
{axis:"Lending Interest Rate",value:"12.86080833"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.564383902"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"Brazil",
axes: [
{axis:"Inflation",value:"3.637027934"},
{axis:"Deposit Interest Rate",value:"10.57725257"},
{axis:"Lending Interest Rate",value:"43.71666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.07228369"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Barbados",
axes: [
{axis:"Inflation",value:"4.034229829"},
{axis:"Deposit Interest Rate",value:"5.134166667"},
{axis:"Lending Interest Rate",value:"10.75833333"},
{axis:"Central Government Debt",value:"68.70851351"},
{axis:"GDP",value:"1.700984781"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Brunei Darussalam",
axes: [
{axis:"Inflation",value:"0.96777412"},
{axis:"Deposit Interest Rate",value:"1.172756667"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.15458146"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Bhutan",
axes: [
{axis:"Inflation",value:"5.156111388"},
{axis:"Deposit Interest Rate",value:"4.5"},
{axis:"Lending Interest Rate",value:"14"},
{axis:"Central Government Debt",value:"62.79525431"},
{axis:"GDP",value:"17.92582494"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Botswana",
axes: [
{axis:"Inflation",value:"7.080998472"},
{axis:"Deposit Interest Rate",value:"8.618639167"},
{axis:"Lending Interest Rate",value:"16.215"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.280147493"},
{axis:"Unemployment",value:"18.5"}]
    },
{className:"Central African Republic",
axes: [
{axis:"Inflation",value:"0.92841211"},
{axis:"Deposit Interest Rate",value:"4.25"},
{axis:"Lending Interest Rate",value:"15"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.607561983"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Canada",
axes: [
{axis:"Inflation",value:"2.138383993"},
{axis:"Deposit Interest Rate",value:"2.083333333"},
{axis:"Lending Interest Rate",value:"6.104166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.06274769"},
{axis:"Unemployment",value:"6"}]
    },
{className:"Central Europe and the Baltics",
axes: [
{axis:"Inflation",value:"4.835779384"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.450407729"},
{axis:"Unemployment",value:"7.778025378"}]
    },
{className:"Switzerland",
axes: [
{axis:"Inflation",value:"0.732636421"},
{axis:"Deposit Interest Rate",value:"2.13"},
{axis:"Lending Interest Rate",value:"3.15"},
{axis:"Central Government Debt",value:"28.60271439"},
{axis:"GDP",value:"4.140348369"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Chile",
axes: [
{axis:"Inflation",value:"4.407797905"},
{axis:"Deposit Interest Rate",value:"5.610227425"},
{axis:"Lending Interest Rate",value:"8.671258486"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.1608256"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"China",
axes: [
{axis:"Inflation",value:"4.750296622"},
{axis:"Deposit Interest Rate",value:"4.14"},
{axis:"Lending Interest Rate",value:"7.47"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"14.19496167"},
{axis:"Unemployment",value:"3.799999952"}]
    },
{className:"Cote dIvoire",
axes: [
{axis:"Inflation",value:"1.892006293"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.765036784"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Cameroon",
axes: [
{axis:"Inflation",value:"0.921402246"},
{axis:"Deposit Interest Rate",value:"4.25"},
{axis:"Lending Interest Rate",value:"15"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.255664493"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Republic of Congo",
axes: [
{axis:"Inflation",value:"2.656413243"},
{axis:"Deposit Interest Rate",value:"4.25"},
{axis:"Lending Interest Rate",value:"15"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.58222275"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"Colombia",
axes: [
{axis:"Inflation",value:"5.543753935"},
{axis:"Deposit Interest Rate",value:"8.013912051"},
{axis:"Lending Interest Rate",value:"15.3818501"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.900627655"},
{axis:"Unemployment",value:"11.19999981"}]
    },
{className:"Comoros",
axes: [
{axis:"Inflation",value:"4.466167101"},
{axis:"Deposit Interest Rate",value:"2.5"},
{axis:"Lending Interest Rate",value:"10.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.800152799"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"Cabo Verde",
axes: [
{axis:"Inflation",value:"4.410997042"},
{axis:"Deposit Interest Rate",value:"3.286461815"},
{axis:"Lending Interest Rate",value:"10.55104815"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"15.17068797"},
{axis:"Unemployment",value:"9.399999619"}]
    },
{className:"Costa Rica",
axes: [
{axis:"Inflation",value:"9.357331387"},
{axis:"Deposit Interest Rate",value:"6.350833333"},
{axis:"Lending Interest Rate",value:"12.79833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.935340515"},
{axis:"Unemployment",value:"4.599999905"}]
    },
{className:"Caribbean small states",
axes: [
{axis:"Inflation",value:"4.034229829"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"64.45925056"},
{axis:"GDP",value:"3.24122442"},
{axis:"Unemployment",value:"8.201976658"}]
    },
{className:"Cuba",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.262137034"},
{axis:"Unemployment",value:"1.799999952"}]
    },
{className:"Cyprus",
axes: [
{axis:"Inflation",value:"2.372492743"},
{axis:"Deposit Interest Rate",value:"3.439166667"},
{axis:"Lending Interest Rate",value:"6.740833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.934072991"},
{axis:"Unemployment",value:"3.900000095"}]
    },
{className:"Czech Republic",
axes: [
{axis:"Inflation",value:"2.927443471"},
{axis:"Deposit Interest Rate",value:"1.323685906"},
{axis:"Lending Interest Rate",value:"5.788379584"},
{axis:"Central Government Debt",value:"23.12473528"},
{axis:"GDP",value:"5.529266339"},
{axis:"Unemployment",value:"5.300000191"}]
    },
{className:"Germany",
axes: [
{axis:"Inflation",value:"2.29834058"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.260535297"},
{axis:"Unemployment",value:"8.600000381"}]
    },
{className:"Djibouti",
axes: [
{axis:"Inflation",value:"4.965976546"},
{axis:"Deposit Interest Rate",value:"4.525"},
{axis:"Lending Interest Rate",value:"10.9375"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.100061387"},
{axis:"Unemployment",value:""}]
    },
{className:"Dominica",
axes: [
{axis:"Inflation",value:"3.237836144"},
{axis:"Deposit Interest Rate",value:"3.258102061"},
{axis:"Lending Interest Rate",value:"9.168012472"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.356736243"},
{axis:"Unemployment",value:""}]
    },
{className:"Denmark",
axes: [
{axis:"Inflation",value:"1.714031313"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.824417532"},
{axis:"Unemployment",value:"3.799999952"}]
    },
{className:"Dominican Republic",
axes: [
{axis:"Inflation",value:"6.143566552"},
{axis:"Deposit Interest Rate",value:"6.961666667"},
{axis:"Lending Interest Rate",value:"15.82666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.47462478"},
{axis:"Unemployment",value:"15.69999981"}]
    },
{className:"Algeria",
axes: [
{axis:"Inflation",value:"3.673827269"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.4"},
{axis:"Unemployment",value:"13.80000019"}]
    },
{className:"East Asia and Pacific",
axes: [
{axis:"Inflation",value:"4.522297607"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.71430617"},
{axis:"Unemployment",value:"4.221889295"}]
    },
{className:"Europe and Central Asia",
axes: [
{axis:"Inflation",value:"2.932682482"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.719613227"},
{axis:"Unemployment",value:"7.51180766"}]
    },
{className:"Ecuador",
axes: [
{axis:"Inflation",value:"2.276301235"},
{axis:"Deposit Interest Rate",value:"5.26"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.190063972"},
{axis:"Unemployment",value:"5"}]
    },
{className:"Egypt",
axes: [
{axis:"Inflation",value:"9.318969058"},
{axis:"Deposit Interest Rate",value:"6.1"},
{axis:"Lending Interest Rate",value:"12.50833333"},
{axis:"Central Government Debt",value:"85.78853383"},
{axis:"GDP",value:"7.088015957"},
{axis:"Unemployment",value:"8.899999619"}]
    },
{className:"Eritrea",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.42682206"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Spain",
axes: [
{axis:"Inflation",value:"2.786703534"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"29.72121726"},
{axis:"GDP",value:"3.768895263"},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"Estonia",
axes: [
{axis:"Inflation",value:"6.597638594"},
{axis:"Deposit Interest Rate",value:"4.371805748"},
{axis:"Lending Interest Rate",value:"6.458545773"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.748203062"},
{axis:"Unemployment",value:"4.699999809"}]
    },
{className:"Ethiopia",
axes: [
{axis:"Inflation",value:"17.23800196"},
{axis:"Deposit Interest Rate",value:"4.111559252"},
{axis:"Lending Interest Rate",value:"7.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.456167"},
{axis:"Unemployment",value:"5.300000191"}]
    },
{className:"European Union",
axes: [
{axis:"Inflation",value:"2.633694973"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.117209445"},
{axis:"Unemployment",value:"7.175435049"}]
    },
{className:"Finland",
axes: [
{axis:"Inflation",value:"2.510666229"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.184800809"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Fiji",
axes: [
{axis:"Inflation",value:"4.803706413"},
{axis:"Deposit Interest Rate",value:"7.044833333"},
{axis:"Lending Interest Rate",value:"9.00558733"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.850653611"},
{axis:"Unemployment",value:"8.600000381"}]
    },
{className:"France",
axes: [
{axis:"Inflation",value:"1.488073528"},
{axis:"Deposit Interest Rate",value:"2.854166667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.361498873"},
{axis:"Unemployment",value:"8"}]
    },
{className:"Federal States of Micronesia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.535"},
{axis:"Lending Interest Rate",value:"14.02958333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.059676851"},
{axis:"Unemployment",value:""}]
    },
{className:"Gabon",
axes: [
{axis:"Inflation",value:"5.030318837"},
{axis:"Deposit Interest Rate",value:"4.25"},
{axis:"Lending Interest Rate",value:"15"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.658952383"},
{axis:"Unemployment",value:"21.10000038"}]
    },
{className:"United Kingdom",
axes: [
{axis:"Inflation",value:"2.321035915"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"5.508708333"},
{axis:"Central Government Debt",value:"46.71701051"},
{axis:"GDP",value:"2.586036583"},
{axis:"Unemployment",value:"5.400000095"}]
    },
{className:"Georgia",
axes: [
{axis:"Inflation",value:"9.244956705"},
{axis:"Deposit Interest Rate",value:"10.19425252"},
{axis:"Lending Interest Rate",value:"17.08611667"},
{axis:"Central Government Debt",value:"22.68712595"},
{axis:"GDP",value:"12.34399988"},
{axis:"Unemployment",value:"13.30000019"}]
    },
{className:"Ghana",
axes: [
{axis:"Inflation",value:"10.73272807"},
{axis:"Deposit Interest Rate",value:"8.895833333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.346819153"},
{axis:"Unemployment",value:"2.799999952"}]
    },
{className:"Guinea",
axes: [
{axis:"Inflation",value:"22.84442192"},
{axis:"Deposit Interest Rate",value:"17.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.757682351"},
{axis:"Unemployment",value:"2"}]
    },
{className:"Gambia",
axes: [
{axis:"Inflation",value:"5.369134737"},
{axis:"Deposit Interest Rate",value:"12.89166667"},
{axis:"Lending Interest Rate",value:"27.91666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.631025533"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Guinea-Bissau",
axes: [
{axis:"Inflation",value:"4.617437722"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.204668686"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Equatorial Guinea",
axes: [
{axis:"Inflation",value:"2.803738318"},
{axis:"Deposit Interest Rate",value:"4.25"},
{axis:"Lending Interest Rate",value:"15"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"12.25217091"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Greece",
axes: [
{axis:"Inflation",value:"2.89500102"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.273746857"},
{axis:"Unemployment",value:"8.300000191"}]
    },
{className:"Grenada",
axes: [
{axis:"Inflation",value:"3.860670607"},
{axis:"Deposit Interest Rate",value:"3.12584593"},
{axis:"Lending Interest Rate",value:"9.755943172"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.150583245"},
{axis:"Unemployment",value:""}]
    },
{className:"Greenland",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.513059779"},
{axis:"Unemployment",value:""}]
    },
{className:"Guatemala",
axes: [
{axis:"Inflation",value:"6.821617536"},
{axis:"Deposit Interest Rate",value:"4.763333333"},
{axis:"Lending Interest Rate",value:"12.83666667"},
{axis:"Central Government Debt",value:"21.63557357"},
{axis:"GDP",value:"6.304056538"},
{axis:"Unemployment",value:"2.5"}]
    },
{className:"Guyana",
axes: [
{axis:"Inflation",value:"12.30442642"},
{axis:"Deposit Interest Rate",value:"2.473333333"},
{axis:"Lending Interest Rate",value:"14.61083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.020313451"},
{axis:"Unemployment",value:"10.80000019"}]
    },
{className:"Hong Kong",
axes: [
{axis:"Inflation",value:"1.956521739"},
{axis:"Deposit Interest Rate",value:"2.423333333"},
{axis:"Lending Interest Rate",value:"6.75"},
{axis:"Central Government Debt",value:"30.11159727"},
{axis:"GDP",value:"6.464748708"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Honduras",
axes: [
{axis:"Inflation",value:"6.936214709"},
{axis:"Deposit Interest Rate",value:"7.783333333"},
{axis:"Lending Interest Rate",value:"16.605"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.188327167"},
{axis:"Unemployment",value:"2.900000095"}]
    },
{className:"Croatia",
axes: [
{axis:"Inflation",value:"2.899282756"},
{axis:"Deposit Interest Rate",value:"2.335833333"},
{axis:"Lending Interest Rate",value:"9.330833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.15000498"},
{axis:"Unemployment",value:"9.600000381"}]
    },
{className:"Haiti",
axes: [
{axis:"Inflation",value:"8.528784648"},
{axis:"Deposit Interest Rate",value:"5.916666667"},
{axis:"Lending Interest Rate",value:"23.08333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.343279015"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Hungary",
axes: [
{axis:"Inflation",value:"7.935008875"},
{axis:"Deposit Interest Rate",value:"6.806704764"},
{axis:"Lending Interest Rate",value:"9.085947496"},
{axis:"Central Government Debt",value:"69.22755445"},
{axis:"GDP",value:"0.42581997"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Indonesia",
axes: [
{axis:"Inflation",value:"6.407448459"},
{axis:"Deposit Interest Rate",value:"7.975833333"},
{axis:"Lending Interest Rate",value:"13.86166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.345022227"},
{axis:"Unemployment",value:"9.100000381"}]
    },
{className:"India",
axes: [
{axis:"Inflation",value:"6.369996746"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"13.02083333"},
{axis:"Central Government Debt",value:"56.47807126"},
{axis:"GDP",value:"8.608212487"},
{axis:"Unemployment",value:"3.700000048"}]
    },

{className:"Ireland",
axes: [
{axis:"Inflation",value:"4.87992471"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"26.95255197"},
{axis:"GDP",value:"5.542750825"},
{axis:"Unemployment",value:"4.599999905"}]
    },
{className:"Iran",
axes: [
{axis:"Inflation",value:"17.21304635"},
{axis:"Deposit Interest Rate",value:"11.60142123"},
{axis:"Lending Interest Rate",value:"12"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.116167365"},
{axis:"Unemployment",value:"10.60000038"}]
    },
{className:"Iraq",
axes: [
{axis:"Inflation",value:"-10.06749258"},
{axis:"Deposit Interest Rate",value:"10.43"},
{axis:"Lending Interest Rate",value:"19.46666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.377598148"},
{axis:"Unemployment",value:"16.89999962"}]
    },
{className:"Iceland",
axes: [
{axis:"Inflation",value:"5.06366784"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"19.29081428"},
{axis:"Central Government Debt",value:"41.20578697"},
{axis:"GDP",value:"9.492910314"},
{axis:"Unemployment",value:"2.299999952"}]
    },
{className:"Israel",
axes: [
{axis:"Inflation",value:"0.51010202"},
{axis:"Deposit Interest Rate",value:"3.49592"},
{axis:"Lending Interest Rate",value:"6.9138938"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.135078996"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"Italy",
axes: [
{axis:"Inflation",value:"1.821444594"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"6.3347"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.473871503"},
{axis:"Unemployment",value:"6.099999905"}]
    },
{className:"Jamaica",
axes: [
{axis:"Inflation",value:"9.293255157"},
{axis:"Deposit Interest Rate",value:"7.135833333"},
{axis:"Lending Interest Rate",value:"17.1975"},
{axis:"Central Government Debt",value:"112.9904969"},
{axis:"GDP",value:"1.431954037"},
{axis:"Unemployment",value:"9.399999619"}]
    },
{className:"Jordan",
axes: [
{axis:"Inflation",value:"5.386824032"},
{axis:"Deposit Interest Rate",value:"5.446666667"},
{axis:"Lending Interest Rate",value:"8.676666667"},
{axis:"Central Government Debt",value:"69.9588209"},
{axis:"GDP",value:"8.175719022"},
{axis:"Unemployment",value:"13.10000038"}]
    },
{className:"Japan",
axes: [
{axis:"Inflation",value:"0.057951817"},
{axis:"Deposit Interest Rate",value:"0.808166667"},
{axis:"Lending Interest Rate",value:"1.88325"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.192186233"},
{axis:"Unemployment",value:"3.900000095"}]
    },
{className:"Kazakhstan",
axes: [
{axis:"Inflation",value:"10.76867075"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.9"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"Kenya",
axes: [
{axis:"Inflation",value:"9.75888023"},
{axis:"Deposit Interest Rate",value:"5.162251046"},
{axis:"Lending Interest Rate",value:"13.34034368"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.850729771"},
{axis:"Unemployment",value:"9.399999619"}]
    },
{className:"Kyrgyz Republic",
axes: [
{axis:"Inflation",value:"10.17524134"},
{axis:"Deposit Interest Rate",value:"2.96145511"},
{axis:"Lending Interest Rate",value:"25.83"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.542874896"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Cambodia",
axes: [
{axis:"Inflation",value:"7.66839343"},
{axis:"Deposit Interest Rate",value:"1.9046875"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.21257181"},
{axis:"Unemployment",value:"0.600000024"}]
    },
{className:"St Kitts and Nevis",
axes: [
{axis:"Inflation",value:"4.513026439"},
{axis:"Deposit Interest Rate",value:"4.595707192"},
{axis:"Lending Interest Rate",value:"9.278149524"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.832379042"},
{axis:"Unemployment",value:""}]
    },
{className:"South Korea",
axes: [
{axis:"Inflation",value:"2.534347678"},
{axis:"Deposit Interest Rate",value:"5.174166667"},
{axis:"Lending Interest Rate",value:"6.551666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.463406088"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Kosovo",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"3.997541159"},
{axis:"Lending Interest Rate",value:"14.05603713"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.286082986"},
{axis:"Unemployment",value:""}]
    },
{className:"Kuwait",
axes: [
{axis:"Inflation",value:"5.484949833"},
{axis:"Deposit Interest Rate",value:"5.446641667"},
{axis:"Lending Interest Rate",value:"8.536283333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.991661246"},
{axis:"Unemployment",value:"1.5"}]
    },
{className:"Lao PDR",
axes: [
{axis:"Inflation",value:"4.522297607"},
{axis:"Deposit Interest Rate",value:"5"},
{axis:"Lending Interest Rate",value:"28.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.596828801"},
{axis:"Unemployment",value:"1.399999976"}]
    },
{className:"Lebanon",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"7.974166667"},
{axis:"Lending Interest Rate",value:"10.25583333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.4040866"},
{axis:"Unemployment",value:"9"}]
    },
{className:"Liberia",
axes: [
{axis:"Inflation",value:"11.39070907"},
{axis:"Deposit Interest Rate",value:"3.768535799"},
{axis:"Lending Interest Rate",value:"15.04615123"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.534892858"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Libya",
axes: [
{axis:"Inflation",value:"6.25098783"},
{axis:"Deposit Interest Rate",value:"2.5"},
{axis:"Lending Interest Rate",value:"6"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.352316994"},
{axis:"Unemployment",value:"19.10000038"}]
    },
{className:"St Lucia",
axes: [
{axis:"Inflation",value:"3.072637855"},
{axis:"Deposit Interest Rate",value:"3.100783694"},
{axis:"Lending Interest Rate",value:"10.1219068"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.621413851"},
{axis:"Unemployment",value:""}]
    },
{className:"Latin America and Caribbean",
axes: [
{axis:"Inflation",value:"5.543753935"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.724852199"},
{axis:"Unemployment",value:"6.897323953"}]
    },
{className:"Liechtenstein",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.325962956"},
{axis:"Unemployment",value:""}]
    },
{className:"Sri Lanka",
axes: [
{axis:"Inflation",value:"15.84211149"},
{axis:"Deposit Interest Rate",value:"16.5"},
{axis:"Lending Interest Rate",value:"16.5"},
{axis:"Central Government Debt",value:"84.99441695"},
{axis:"GDP",value:"6.796826119"},
{axis:"Unemployment",value:"6"}]
    },
{className:"Lesotho",
axes: [
{axis:"Inflation",value:"8.01243669"},
{axis:"Deposit Interest Rate",value:"6.458333333"},
{axis:"Lending Interest Rate",value:"14.13166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.733465098"},
{axis:"Unemployment",value:"26.39999962"}]
    },
{className:"Lithuania",
axes: [
{axis:"Inflation",value:"5.730244104"},
{axis:"Deposit Interest Rate",value:"5.4"},
{axis:"Lending Interest Rate",value:"6.8625"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.08695439"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Luxembourg",
axes: [
{axis:"Inflation",value:"2.303365771"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"4.681462456"},
{axis:"GDP",value:"8.395647185"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Latvia",
axes: [
{axis:"Inflation",value:"10.14084507"},
{axis:"Deposit Interest Rate",value:"6.0625"},
{axis:"Lending Interest Rate",value:"10.90916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.96049931"},
{axis:"Unemployment",value:"6"}]
    },
{className:"Macau",
axes: [
{axis:"Inflation",value:"5.57037037"},
{axis:"Deposit Interest Rate",value:"2.851144836"},
{axis:"Lending Interest Rate",value:"7.80848393"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"14.44754993"},
{axis:"Unemployment",value:"3"}]
    },
{className:"Morocco",
axes: [
{axis:"Inflation",value:"2.042085127"},
{axis:"Deposit Interest Rate",value:"3.669166667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"50.93539693"},
{axis:"GDP",value:"3.531913925"},
{axis:"Unemployment",value:"9.800000191"}]
    },
{className:"Monaco",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"14.58244232"},
{axis:"Unemployment",value:""}]
    },
{className:"Moldova",
axes: [
{axis:"Inflation",value:"12.13550114"},
{axis:"Deposit Interest Rate",value:"15.01"},
{axis:"Lending Interest Rate",value:"18.825"},
{axis:"Central Government Debt",value:"23.23975238"},
{axis:"GDP",value:"3.067943527"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Madagascar",
axes: [
{axis:"Inflation",value:"10.30072119"},
{axis:"Deposit Interest Rate",value:"16.5"},
{axis:"Lending Interest Rate",value:"45"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.240578451"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Maldives",
axes: [
{axis:"Inflation",value:"7.372987378"},
{axis:"Deposit Interest Rate",value:"6.5"},
{axis:"Lending Interest Rate",value:"13"},
{axis:"Central Government Debt",value:"31.22992844"},
{axis:"GDP",value:"10.79088228"},
{axis:"Unemployment",value:"12.60000038"}]
    },
{className:"Middle East and North Africa",
axes: [
{axis:"Inflation",value:"4.567344955"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.160316751"},
{axis:"Unemployment",value:"10.33351251"}]
    },
{className:"Mexico",
axes: [
{axis:"Inflation",value:"3.966849629"},
{axis:"Deposit Interest Rate",value:"3.205"},
{axis:"Lending Interest Rate",value:"7.560833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.204123017"},
{axis:"Unemployment",value:"3.400000095"}]
    },

{className:"Macedonia",
axes: [
{axis:"Inflation",value:"2.251757983"},
{axis:"Deposit Interest Rate",value:"4.875"},
{axis:"Lending Interest Rate",value:"10.23333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.473486858"},
{axis:"Unemployment",value:"34.90000153"}]
    },
{className:"Mali",
axes: [
{axis:"Inflation",value:"1.412002017"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.302834121"},
{axis:"Unemployment",value:"8.5"}]
    },
{className:"Malta",
axes: [
{axis:"Inflation",value:"1.251349406"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"6.238333333"},
{axis:"Central Government Debt",value:"170.9141298"},
{axis:"GDP",value:"4.279227098"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Myanmar",
axes: [
{axis:"Inflation",value:"35.02459707"},
{axis:"Deposit Interest Rate",value:"12"},
{axis:"Lending Interest Rate",value:"17"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Montenegro",
axes: [
{axis:"Inflation",value:"4.347122157"},
{axis:"Deposit Interest Rate",value:"5.08"},
{axis:"Lending Interest Rate",value:"9.2025"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.65790133"},
{axis:"Unemployment",value:"19.39999962"}]
    },
{className:"Mongolia",
axes: [
{axis:"Inflation",value:"9.045246163"},
{axis:"Deposit Interest Rate",value:"13.46"},
{axis:"Lending Interest Rate",value:"21.82833333"},
{axis:"Central Government Debt",value:"43.51401239"},
{axis:"GDP",value:"10.24801636"},
{axis:"Unemployment",value:"7.199999809"}]
    },

{className:"Mozambique",
axes: [
{axis:"Inflation",value:"8.162567333"},
{axis:"Deposit Interest Rate",value:"11.85053709"},
{axis:"Lending Interest Rate",value:"19.51733333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.426060991"},
{axis:"Unemployment",value:"22.60000038"}]
    },
{className:"Mauritania",
axes: [
{axis:"Inflation",value:"7.254108413"},
{axis:"Deposit Interest Rate",value:"8"},
{axis:"Lending Interest Rate",value:"23.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.817836772"},
{axis:"Unemployment",value:"31.39999962"}]
    },
{className:"Mauritius",
axes: [
{axis:"Inflation",value:"8.802724653"},
{axis:"Deposit Interest Rate",value:"11.77083333"},
{axis:"Lending Interest Rate",value:"21.87416667"},
{axis:"Central Government Debt",value:"36.28779887"},
{axis:"GDP",value:"5.890498632"},
{axis:"Unemployment",value:"8.5"}]
    },
{className:"Malawi",
axes: [
{axis:"Inflation",value:"7.952209909"},
{axis:"Deposit Interest Rate",value:"5.973888889"},
{axis:"Lending Interest Rate",value:"27.71527778"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.599999997"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Malaysia",
axes: [
{axis:"Inflation",value:"2.027353178"},
{axis:"Deposit Interest Rate",value:"3.165833333"},
{axis:"Lending Interest Rate",value:"6.409166667"},
{axis:"Central Government Debt",value:"40.08812577"},
{axis:"GDP",value:"6.298785931"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"North America",
axes: [
{axis:"Inflation",value:"2.495528237"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"55.63429465"},
{axis:"GDP",value:"1.806127951"},
{axis:"Unemployment",value:"4.836463748"}]
    },
{className:"Namibia",
axes: [
{axis:"Inflation",value:"6.547881411"},
{axis:"Deposit Interest Rate",value:"7.546666667"},
{axis:"Lending Interest Rate",value:"12.88416667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.617094453"},
{axis:"Unemployment",value:"19.39999962"}]
    },
{className:"Niger",
axes: [
{axis:"Inflation",value:"0.053959261"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.146570396"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Nigeria",
axes: [
{axis:"Inflation",value:"5.382223652"},
{axis:"Deposit Interest Rate",value:"10.28833333"},
{axis:"Lending Interest Rate",value:"16.93916667"},
{axis:"Central Government Debt",value:"12.40490451"},
{axis:"GDP",value:"6.828398348"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Nicaragua",
axes: [
{axis:"Inflation",value:"11.12693474"},
{axis:"Deposit Interest Rate",value:"6.075202459"},
{axis:"Lending Interest Rate",value:"13.04146496"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.287768464"},
{axis:"Unemployment",value:"5"}]
    },
{className:"Netherlands",
axes: [
{axis:"Inflation",value:"1.614180118"},
{axis:"Deposit Interest Rate",value:"3.8892"},
{axis:"Lending Interest Rate",value:"4.604166667"},
{axis:"Central Government Debt",value:"40.21539999"},
{axis:"GDP",value:"3.698473106"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Norway",
axes: [
{axis:"Inflation",value:"0.728997098"},
{axis:"Deposit Interest Rate",value:"4.85923624"},
{axis:"Lending Interest Rate",value:"6.647344589"},
{axis:"Central Government Debt",value:"44.87967716"},
{axis:"GDP",value:"2.929766044"},
{axis:"Unemployment",value:"2.5"}]
    },
{className:"Nepal",
axes: [
{axis:"Inflation",value:"5.745910312"},
{axis:"Deposit Interest Rate",value:"2.25"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:"42.97866114"},
{axis:"GDP",value:"3.411560276"},
{axis:"Unemployment",value:"2.299999952"}]
    },
{className:"New Zealand",
axes: [
{axis:"Inflation",value:"2.37614328"},
{axis:"Deposit Interest Rate",value:"7.783991667"},
{axis:"Lending Interest Rate",value:"8.612206614"},
{axis:"Central Government Debt",value:"36.94151192"},
{axis:"GDP",value:"2.864627982"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Oman",
axes: [
{axis:"Inflation",value:"5.95521677"},
{axis:"Deposit Interest Rate",value:"4.14"},
{axis:"Lending Interest Rate",value:"7.285"},
{axis:"Central Government Debt",value:"6.185344028"},
{axis:"GDP",value:"4.452694304"},
{axis:"Unemployment",value:"7.800000191"}]
    },
{className:"Pakistan",
axes: [
{axis:"Inflation",value:"7.598684411"},
{axis:"Deposit Interest Rate",value:"5.308333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.832817277"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Panama",
axes: [
{axis:"Inflation",value:"4.168633003"},
{axis:"Deposit Interest Rate",value:"4.756666667"},
{axis:"Lending Interest Rate",value:"8.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"15.31592358"},
{axis:"Unemployment",value:"6.400000095"}]
    },
{className:"Peru",
axes: [
{axis:"Inflation",value:"1.779986447"},
{axis:"Deposit Interest Rate",value:"3.229795833"},
{axis:"Lending Interest Rate",value:"22.85564806"},
{axis:"Central Government Debt",value:"28.52881848"},
{axis:"GDP",value:"8.518441947"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Philippines",
axes: [
{axis:"Inflation",value:"2.9"},
{axis:"Deposit Interest Rate",value:"3.696"},
{axis:"Lending Interest Rate",value:"8.691416667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.616668505"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Palau",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.053191489"},
{axis:"Unemployment",value:""}]
    },
{className:"Papua New Guinea",
axes: [
{axis:"Inflation",value:"0.911350456"},
{axis:"Deposit Interest Rate",value:"1.060833333"},
{axis:"Lending Interest Rate",value:"9.7775"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.151762439"},
{axis:"Unemployment",value:"2.5"}]
    },
{className:"Poland",
axes: [
{axis:"Inflation",value:"2.388059701"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"42.47602525"},
{axis:"GDP",value:"7.201683419"},
{axis:"Unemployment",value:"9.600000381"}]
    },
{className:"Puerto Rico",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.325701786"},
{axis:"Unemployment",value:"11.10000038"}]
    },
{className:"Portugal",
axes: [
{axis:"Inflation",value:"2.805070127"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.492002475"},
{axis:"Unemployment",value:"8"}]
    },
{className:"Paraguay",
axes: [
{axis:"Inflation",value:"8.128776435"},
{axis:"Deposit Interest Rate",value:"5.0025"},
{axis:"Lending Interest Rate",value:"25.02496179"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.421622463"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Qatar",
axes: [
{axis:"Inflation",value:"13.75816258"},
{axis:"Deposit Interest Rate",value:"4.425"},
{axis:"Lending Interest Rate",value:"7.428333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"17.98565677"},
{axis:"Unemployment",value:"0.5"}]
    },
{className:"Romania",
axes: [
{axis:"Inflation",value:"4.835779384"},
{axis:"Deposit Interest Rate",value:"6.7"},
{axis:"Lending Interest Rate",value:"13.34833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.863757382"},
{axis:"Unemployment",value:"6.400000095"}]
    },
{className:"Russian Federation",
axes: [
{axis:"Inflation",value:"8.991328161"},
{axis:"Deposit Interest Rate",value:"5.141666667"},
{axis:"Lending Interest Rate",value:"10.03333333"},
{axis:"Central Government Debt",value:"7.158429729"},
{axis:"GDP",value:"8.535080209"},
{axis:"Unemployment",value:"6"}]
    },
{className:"Rwanda",
axes: [
{axis:"Inflation",value:"9.080722059"},
{axis:"Deposit Interest Rate",value:"6.77"},
{axis:"Lending Interest Rate",value:"16.11"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.612853864"},
{axis:"Unemployment",value:"0.600000024"}]
    },
{className:"South Asia",
axes: [
{axis:"Inflation",value:"7.485835894"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"56.47807126"},
{axis:"GDP",value:"8.087745614"},
{axis:"Unemployment",value:"3.938591813"}]
    },
{className:"Saudi Arabia",
axes: [
{axis:"Inflation",value:"4.168713364"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.992309707"},
{axis:"Unemployment",value:"5.699999809"}]
    },
{className:"Sudan",
axes: [
{axis:"Inflation",value:"7.976023489"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.52191003"},
{axis:"Unemployment",value:"14.69999981"}]
    },
{className:"Senegal",
axes: [
{axis:"Inflation",value:"5.853304285"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.938485083"},
{axis:"Unemployment",value:"8.800000191"}]
    },
{className:"Singapore",
axes: [
{axis:"Inflation",value:"2.095144195"},
{axis:"Deposit Interest Rate",value:"0.529166667"},
{axis:"Lending Interest Rate",value:"5.33"},
{axis:"Central Government Debt",value:"77.68853654"},
{axis:"GDP",value:"9.111527148"},
{axis:"Unemployment",value:"3"}]
    },
{className:"Solomon Islands",
axes: [
{axis:"Inflation",value:"7.666020135"},
{axis:"Deposit Interest Rate",value:"0.678124646"},
{axis:"Lending Interest Rate",value:"14.12109886"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.320001264"},
{axis:"Unemployment",value:"3.799999952"}]
    },
{className:"Sierra Leone",
axes: [
{axis:"Inflation",value:"11.65614168"},
{axis:"Deposit Interest Rate",value:"10.7875"},
{axis:"Lending Interest Rate",value:"25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.058321564"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"El Salvador",
axes: [
{axis:"Inflation",value:"4.578085724"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"41.02333246"},
{axis:"GDP",value:"3.839765177"},
{axis:"Unemployment",value:"6.300000191"}]
    },
{className:"San Marino",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.6275"},
{axis:"Lending Interest Rate",value:"7.5825"},
{axis:"Central Government Debt",value:"61.45918962"},
{axis:"GDP",value:"3.493449782"},
{axis:"Unemployment",value:""}]
    },
{className:"Somalia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Serbia",
axes: [
{axis:"Inflation",value:"6.391706444"},
{axis:"Deposit Interest Rate",value:"4.08"},
{axis:"Lending Interest Rate",value:"11.13"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.888760078"},
{axis:"Unemployment",value:"18.10000038"}]
    },
{className:"Sao Tome and Principe",
axes: [
{axis:"Inflation",value:"18.54851363"},
{axis:"Deposit Interest Rate",value:"12.75"},
{axis:"Lending Interest Rate",value:"32.4"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.253604914"},
{axis:"Unemployment",value:""}]
    },
{className:"Suriname",
axes: [
{axis:"Inflation",value:"6.426279345"},
{axis:"Deposit Interest Rate",value:"6.416666667"},
{axis:"Lending Interest Rate",value:"13.76666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.111487808"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Slovak Republic",
axes: [
{axis:"Inflation",value:"2.756723716"},
{axis:"Deposit Interest Rate",value:"3.7225"},
{axis:"Lending Interest Rate",value:"7.989166667"},
{axis:"Central Government Debt",value:"31.18789636"},
{axis:"GDP",value:"10.83443581"},
{axis:"Unemployment",value:"11"}]
    },
{className:"Slovenia",
axes: [
{axis:"Inflation",value:"3.611165333"},
{axis:"Deposit Interest Rate",value:"3.5975"},
{axis:"Lending Interest Rate",value:"5.9125"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.94157235"},
{axis:"Unemployment",value:"4.800000191"}]
    },
{className:"Sweden",
axes: [
{axis:"Inflation",value:"2.212168834"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.404948895"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"Swaziland",
axes: [
{axis:"Inflation",value:"8.076088279"},
{axis:"Deposit Interest Rate",value:"7.054166667"},
{axis:"Lending Interest Rate",value:"13.16666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.503652056"},
{axis:"Unemployment",value:"23"}]
    },
{className:"Seychelles",
axes: [
{axis:"Inflation",value:"5.320600273"},
{axis:"Deposit Interest Rate",value:"3.06859282"},
{axis:"Lending Interest Rate",value:"10.8936722"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.42143611"},
{axis:"Unemployment",value:""}]
    },
{className:"Syrian Arab Republic",
axes: [
{axis:"Inflation",value:"3.907709504"},
{axis:"Deposit Interest Rate",value:"8.363"},
{axis:"Lending Interest Rate",value:"10.17"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.699999996"},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"Chad",
axes: [
{axis:"Inflation",value:"-8.97473962"},
{axis:"Deposit Interest Rate",value:"4.25"},
{axis:"Lending Interest Rate",value:"15"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.271499579"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Togo",
axes: [
{axis:"Inflation",value:"0.959947037"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.290453889"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Thailand",
axes: [
{axis:"Inflation",value:"2.241540953"},
{axis:"Deposit Interest Rate",value:"2.875"},
{axis:"Lending Interest Rate",value:"7.05"},
{axis:"Central Government Debt",value:"22.9934521"},
{axis:"GDP",value:"5.43509257"},
{axis:"Unemployment",value:"1.200000048"}]
    },
{className:"Tajikistan",
axes: [
{axis:"Inflation",value:"13.14912471"},
{axis:"Deposit Interest Rate",value:"10.99385083"},
{axis:"Lending Interest Rate",value:"22.96"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.800001545"},
{axis:"Unemployment",value:"11.69999981"}]
    },
{className:"Turkmenistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.05929947"},
{axis:"Unemployment",value:"11"}]
    },
{className:"Timor-Leste",
axes: [
{axis:"Inflation",value:"10.30090202"},
{axis:"Deposit Interest Rate",value:"0.781387668"},
{axis:"Lending Interest Rate",value:"15.04658814"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.44781145"},
{axis:"Unemployment",value:"6.699999809"}]
    },
{className:"Tonga",
axes: [
{axis:"Inflation",value:"5.885904014"},
{axis:"Deposit Interest Rate",value:"6.766666668"},
{axis:"Lending Interest Rate",value:"12.16366461"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.571113139"},
{axis:"Unemployment",value:""}]
    },
{className:"Trinidad and Tobago",
axes: [
{axis:"Inflation",value:"7.889358223"},
{axis:"Deposit Interest Rate",value:"5.9"},
{axis:"Lending Interest Rate",value:"11.75"},
{axis:"Central Government Debt",value:"15.92800424"},
{axis:"GDP",value:"4.754189988"},
{axis:"Unemployment",value:"5.5"}]
    },
{className:"Tunisia",
axes: [
{axis:"Inflation",value:"3.416546647"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"45.78954125"},
{axis:"GDP",value:"6.709620392"},
{axis:"Unemployment",value:"12.39999962"}]
    },
{className:"Turkey",
axes: [
{axis:"Inflation",value:"8.75618091"},
{axis:"Deposit Interest Rate",value:"22.55916667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.668578895"},
{axis:"Unemployment",value:"10.30000019"}]
    },
{className:"Tuvalu",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.350564875"},
{axis:"Unemployment",value:""}]
    },
{className:"Tanzania",
axes: [
{axis:"Inflation",value:"7.02551437"},
{axis:"Deposit Interest Rate",value:"8.679536808"},
{axis:"Lending Interest Rate",value:"16.07036615"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.464381242"},
{axis:"Unemployment",value:"2"}]
    },
{className:"Uganda",
axes: [
{axis:"Inflation",value:"6.138510833"},
{axis:"Deposit Interest Rate",value:"9.262089712"},
{axis:"Lending Interest Rate",value:"19.10574548"},
{axis:"Central Government Debt",value:"26.49240327"},
{axis:"GDP",value:"8.412425966"},
{axis:"Unemployment",value:"3"}]
    },
{className:"Ukraine",
axes: [
{axis:"Inflation",value:"12.84019539"},
{axis:"Deposit Interest Rate",value:"8.120266667"},
{axis:"Lending Interest Rate",value:"13.89916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.900000767"},
{axis:"Unemployment",value:"6.400000095"}]
    },
{className:"Uruguay",
axes: [
{axis:"Inflation",value:"8.114214042"},
{axis:"Deposit Interest Rate",value:"2.361180667"},
{axis:"Lending Interest Rate",value:"8.939703917"},
{axis:"Central Government Debt",value:"58.51206053"},
{axis:"GDP",value:"6.54151084"},
{axis:"Unemployment",value:"9.199999809"}]
    },
{className:"United States",
axes: [
{axis:"Inflation",value:"2.852672482"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"8.05"},
{axis:"Central Government Debt",value:"55.63429465"},
{axis:"GDP",value:"1.77857024"},
{axis:"Unemployment",value:"4.699999809"}]
    },
{className:"Uzbekistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.921153846"},
{axis:"Unemployment",value:"11"}]
    },
{className:"St Vincent and the Grenadines",
axes: [
{axis:"Inflation",value:"6.915692354"},
{axis:"Deposit Interest Rate",value:"2.820098234"},
{axis:"Lending Interest Rate",value:"9.612582863"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.617029317"},
{axis:"Unemployment",value:""}]
    },
{className:"Venezuela",
axes: [
{axis:"Inflation",value:"18.69864535"},
{axis:"Deposit Interest Rate",value:"10.70666667"},
{axis:"Lending Interest Rate",value:"17.105"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.753578808"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Vietnam",
axes: [
{axis:"Inflation",value:"8.30378949"},
{axis:"Deposit Interest Rate",value:"7.4925"},
{axis:"Lending Interest Rate",value:"11.18"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.129504484"},
{axis:"Unemployment",value:"2.299999952"}]
    },
{className:"Vanuatu",
axes: [
{axis:"Inflation",value:"3.956989247"},
{axis:"Deposit Interest Rate",value:"1.3125"},
{axis:"Lending Interest Rate",value:"8.160833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.175676788"},
{axis:"Unemployment",value:""}]
    },
{className:"West Bank and Gaza",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"3.015"},
{axis:"Lending Interest Rate",value:"7.9775"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.727003605"},
{axis:"Unemployment",value:"21.60000038"}]
    },
{className:"World",
axes: [
{axis:"Inflation",value:"5.344867505"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.310557133"},
{axis:"Unemployment",value:"5.483626964"}]
    },
{className:"Samoa",
axes: [
{axis:"Inflation",value:"5.577063932"},
{axis:"Deposit Interest Rate",value:"6.4425"},
{axis:"Lending Interest Rate",value:"12.65083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.322641763"},
{axis:"Unemployment",value:""}]
    },
{className:"Yemen",
axes: [
{axis:"Inflation",value:"7.90511779"},
{axis:"Deposit Interest Rate",value:"13"},
{axis:"Lending Interest Rate",value:"18"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.338427946"},
{axis:"Unemployment",value:"15.30000019"}]
    },
{className:"South Africa",
axes: [
{axis:"Inflation",value:"7.098419808"},
{axis:"Deposit Interest Rate",value:"9.1525"},
{axis:"Lending Interest Rate",value:"13.16666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.360474053"},
{axis:"Unemployment",value:"22.29999924"}]
    },
{className:"Democratic Republic of the Congo",
axes: [
{axis:"Inflation",value:"16.94510065"},
{axis:"Deposit Interest Rate",value:"14.38758333"},
{axis:"Lending Interest Rate",value:"47.00101833"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.259469847"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Zambia",
axes: [
{axis:"Inflation",value:"10.6573496"},
{axis:"Deposit Interest Rate",value:"9.215544872"},
{axis:"Lending Interest Rate",value:"18.8891"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.352436224"},
{axis:"Unemployment",value:"15.19999981"}]
    },
{className:"Zimbabwe",
axes: [
{axis:"Inflation",value:"24411.03081"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.653327043"},
{axis:"Unemployment",value:"5.099999905"}]
    }
],
["2008",
{className:"Aruba",
axes: [
{axis:"Inflation",value:"8.957732188"},
{axis:"Deposit Interest Rate",value:"3.616666667"},
{axis:"Lending Interest Rate",value:"11.23333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-6.881302064"},
{axis:"Unemployment",value:""}]
    },
{className:"Andorra",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-8.594256008"},
{axis:"Unemployment",value:""}]
    },
{className:"Afghanistan",
axes: [
{axis:"Inflation",value:"30.55494061"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"14.9175"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.611368392"},
{axis:"Unemployment",value:"8.899999619"}]
    },
{className:"Angola",
axes: [
{axis:"Inflation",value:"12.47371341"},
{axis:"Deposit Interest Rate",value:"6.538077601"},
{axis:"Lending Interest Rate",value:"12.53360576"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"13.81714581"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Albania",
axes: [
{axis:"Inflation",value:"3.359242418"},
{axis:"Deposit Interest Rate",value:"6.802742388"},
{axis:"Lending Interest Rate",value:"13.01964271"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.529999989"},
{axis:"Unemployment",value:"13"}]
    },
{className:"United Arab Emirates",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.191836271"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Argentina",
axes: [
{axis:"Inflation",value:"8.584013752"},
{axis:"Deposit Interest Rate",value:"11.04932902"},
{axis:"Lending Interest Rate",value:"19.46815833"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.0938615"},
{axis:"Unemployment",value:"7.800000191"}]
    },
{className:"Armenia",
axes: [
{axis:"Inflation",value:"8.949953354"},
{axis:"Deposit Interest Rate",value:"6.628018609"},
{axis:"Lending Interest Rate",value:"17.04948273"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.900000002"},
{axis:"Unemployment",value:"16.39999962"}]
    },
{className:"Antigua and Barbuda",
axes: [
{axis:"Inflation",value:"5.333806398"},
{axis:"Deposit Interest Rate",value:"3.537201557"},
{axis:"Lending Interest Rate",value:"10.42910094"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.071111021"},
{axis:"Unemployment",value:""}]
    },
{className:"Australia",
axes: [
{axis:"Inflation",value:"4.352643242"},
{axis:"Deposit Interest Rate",value:"4.725"},
{axis:"Lending Interest Rate",value:"8.908333333"},
{axis:"Central Government Debt",value:"18.28626377"},
{axis:"GDP",value:"3.706699506"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Austria",
axes: [
{axis:"Inflation",value:"3.21592066"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.547263839"},
{axis:"Unemployment",value:"3.799999952"}]
    },
{className:"Azerbaijan",
axes: [
{axis:"Inflation",value:"20.79157914"},
{axis:"Deposit Interest Rate",value:"12.22416667"},
{axis:"Lending Interest Rate",value:"19.7625"},
{axis:"Central Government Debt",value:"4.576537975"},
{axis:"GDP",value:"10.77242078"},
{axis:"Unemployment",value:"5.900000095"}]
    },
{className:"Burundi",
axes: [
{axis:"Inflation",value:"24.10735481"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"16.52083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.048118783"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Belgium",
axes: [
{axis:"Inflation",value:"4.489444205"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"9.208333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.747103204"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Benin",
axes: [
{axis:"Inflation",value:"7.947298761"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.893393918"},
{axis:"Unemployment",value:"1.100000024"}]
    },
{className:"Burkina Faso",
axes: [
{axis:"Inflation",value:"10.6597979"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.29449815"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Bangladesh",
axes: [
{axis:"Inflation",value:"8.901944895"},
{axis:"Deposit Interest Rate",value:"7.546666667"},
{axis:"Lending Interest Rate",value:"12.88916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.013789759"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Bulgaria",
axes: [
{axis:"Inflation",value:"12.34877209"},
{axis:"Deposit Interest Rate",value:"4.444641667"},
{axis:"Lending Interest Rate",value:"10.861425"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.647005429"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Bahrain",
axes: [
{axis:"Inflation",value:"3.526003164"},
{axis:"Deposit Interest Rate",value:"1.6475"},
{axis:"Lending Interest Rate",value:"8.223460614"},
{axis:"Central Government Debt",value:"7.292633199"},
{axis:"GDP",value:"6.245128341"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"The Bahamas",
axes: [
{axis:"Inflation",value:"4.489559954"},
{axis:"Deposit Interest Rate",value:"3.920833333"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.323937248"},
{axis:"Unemployment",value:"8.699999809"}]
    },
{className:"Bosnia and Herzegovina",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"3.485"},
{axis:"Lending Interest Rate",value:"6.978333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.481507958"},
{axis:"Unemployment",value:"23.89999962"}]
    },
{className:"Belarus",
axes: [
{axis:"Inflation",value:"14.83787648"},
{axis:"Deposit Interest Rate",value:"8.525"},
{axis:"Lending Interest Rate",value:"8.55"},
{axis:"Central Government Debt",value:"10.65663437"},
{axis:"GDP",value:"10.2"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"Belize",
axes: [
{axis:"Inflation",value:"6.389275766"},
{axis:"Deposit Interest Rate",value:"8.4575"},
{axis:"Lending Interest Rate",value:"14.14083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.229101316"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Bermuda",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.52789391"},
{axis:"Unemployment",value:""}]
    },
{className:"Bolivia",
axes: [
{axis:"Inflation",value:"14.00040758"},
{axis:"Deposit Interest Rate",value:"4.655833333"},
{axis:"Lending Interest Rate",value:"13.87333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.148497195"},
{axis:"Unemployment",value:"2.900000095"}]
    },
{className:"Brazil",
axes: [
{axis:"Inflation",value:"5.663098519"},
{axis:"Deposit Interest Rate",value:"11.65533226"},
{axis:"Lending Interest Rate",value:"47.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.093767012"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Barbados",
axes: [
{axis:"Inflation",value:"8.108108108"},
{axis:"Deposit Interest Rate",value:"4.46"},
{axis:"Lending Interest Rate",value:"10.03333333"},
{axis:"Central Government Debt",value:"74.06486146"},
{axis:"GDP",value:"0.440140845"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Brunei Darussalam",
axes: [
{axis:"Inflation",value:"2.084980237"},
{axis:"Deposit Interest Rate",value:"0.875761458"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.939714507"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Bhutan",
axes: [
{axis:"Inflation",value:"8.327160494"},
{axis:"Deposit Interest Rate",value:"2"},
{axis:"Lending Interest Rate",value:"13.75"},
{axis:"Central Government Debt",value:"60.41025501"},
{axis:"GDP",value:"4.768354226"},
{axis:"Unemployment",value:"3.799999952"}]
    },
{className:"Botswana",
axes: [
{axis:"Inflation",value:"12.70218839"},
{axis:"Deposit Interest Rate",value:"8.673225"},
{axis:"Lending Interest Rate",value:"16.54166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.242117247"},
{axis:"Unemployment",value:"21.89999962"}]
    },
{className:"Central African Republic",
axes: [
{axis:"Inflation",value:"9.272618503"},
{axis:"Deposit Interest Rate",value:"3.75"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.054126562"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Canada",
axes: [
{axis:"Inflation",value:"2.370270674"},
{axis:"Deposit Interest Rate",value:"1.5"},
{axis:"Lending Interest Rate",value:"4.729166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.000360973"},
{axis:"Unemployment",value:"6.099999905"}]
    },
{className:"Central Europe and the Baltics",
axes: [
{axis:"Inflation",value:"6.350986289"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.666408627"},
{axis:"Unemployment",value:"6.588664469"}]
    },
{className:"Switzerland",
axes: [
{axis:"Inflation",value:"2.426637033"},
{axis:"Deposit Interest Rate",value:"0.16"},
{axis:"Lending Interest Rate",value:"3.3425"},
{axis:"Central Government Debt",value:"26.20416368"},
{axis:"GDP",value:"2.277240085"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"Chile",
axes: [
{axis:"Inflation",value:"8.716268548"},
{axis:"Deposit Interest Rate",value:"7.489197399"},
{axis:"Lending Interest Rate",value:"13.26177137"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.292454897"},
{axis:"Unemployment",value:"7.800000191"}]
    },
{className:"China",
axes: [
{axis:"Inflation",value:"5.864383723"},
{axis:"Deposit Interest Rate",value:"2.25"},
{axis:"Lending Interest Rate",value:"5.31"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.623377486"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Cote dIvoire",
axes: [
{axis:"Inflation",value:"6.308527692"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.542841476"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Cameroon",
axes: [
{axis:"Inflation",value:"5.337806276"},
{axis:"Deposit Interest Rate",value:"3.75"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.884046234"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Republic of Congo",
axes: [
{axis:"Inflation",value:"7.334245387"},
{axis:"Deposit Interest Rate",value:"3.75"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.572264173"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"Colombia",
axes: [
{axis:"Inflation",value:"6.996990766"},
{axis:"Deposit Interest Rate",value:"9.741080032"},
{axis:"Lending Interest Rate",value:"17.17562314"},
{axis:"Central Government Debt",value:"64.76493854"},
{axis:"GDP",value:"3.546804886"},
{axis:"Unemployment",value:"11.10000038"}]
    },
{className:"Comoros",
axes: [
{axis:"Inflation",value:"1.700781763"},
{axis:"Deposit Interest Rate",value:"2.5"},
{axis:"Lending Interest Rate",value:"10.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.400266855"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"Cabo Verde",
axes: [
{axis:"Inflation",value:"6.782768103"},
{axis:"Deposit Interest Rate",value:"3.810163856"},
{axis:"Lending Interest Rate",value:"9.989013523"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.650520523"},
{axis:"Unemployment",value:"9.399999619"}]
    },
{className:"Costa Rica",
axes: [
{axis:"Inflation",value:"13.42335635"},
{axis:"Deposit Interest Rate",value:"4.15"},
{axis:"Lending Interest Rate",value:"15.8275"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.731620422"},
{axis:"Unemployment",value:"4.900000095"}]
    },
{className:"Caribbean small states",
axes: [
{axis:"Inflation",value:"8.032255793"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"120.4172619"},
{axis:"GDP",value:"1.382636785"},
{axis:"Unemployment",value:"8.658616348"}]
    },
{className:"Cuba",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.116828059"},
{axis:"Unemployment",value:"1.600000024"}]
    },
{className:"Cyprus",
axes: [
{axis:"Inflation",value:"4.669171081"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.652696543"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Czech Republic",
axes: [
{axis:"Inflation",value:"6.350986289"},
{axis:"Deposit Interest Rate",value:"1.612033333"},
{axis:"Lending Interest Rate",value:"6.251708333"},
{axis:"Central Government Debt",value:"24.41605281"},
{axis:"GDP",value:"2.710955571"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Germany",
axes: [
{axis:"Inflation",value:"2.628383067"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.082315404"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Djibouti",
axes: [
{axis:"Inflation",value:"11.95862069"},
{axis:"Deposit Interest Rate",value:"2.9625"},
{axis:"Lending Interest Rate",value:"11.38375"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.799962619"},
{axis:"Unemployment",value:""}]
    },
{className:"Dominica",
axes: [
{axis:"Inflation",value:"6.334754545"},
{axis:"Deposit Interest Rate",value:"3.202075737"},
{axis:"Lending Interest Rate",value:"9.064046388"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.047279215"},
{axis:"Unemployment",value:""}]
    },
{className:"Denmark",
axes: [
{axis:"Inflation",value:"3.399474759"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.717955926"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"Dominican Republic",
axes: [
{axis:"Inflation",value:"10.6446211"},
{axis:"Deposit Interest Rate",value:"10.3475"},
{axis:"Lending Interest Rate",value:"19.945"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.143711459"},
{axis:"Unemployment",value:"14.19999981"}]
    },
{className:"Algeria",
axes: [
{axis:"Inflation",value:"4.862990528"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.4"},
{axis:"Unemployment",value:"11.30000019"}]
    },
{className:"East Asia and Pacific (excluding high income)",
axes: [
{axis:"Inflation",value:"9.776585195"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.407978346"},
{axis:"Unemployment",value:"4.635707091"}]
    },
{className:"East Asia and Pacific",
axes: [
{axis:"Inflation",value:"7.732278579"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.581443365"},
{axis:"Unemployment",value:"4.558680811"}]
    },
{className:"Europe and Central Asia (excluding high income)",
axes: [
{axis:"Inflation",value:"12.41098678"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.381207012"},
{axis:"Unemployment",value:"7.92863742"}]
    },
{className:"Europe and Central Asia",
axes: [
{axis:"Inflation",value:"6.066157153"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.016887441"},
{axis:"Unemployment",value:"7.365459672"}]
    },
{className:"Ecuador",
axes: [
{axis:"Inflation",value:"8.400825434"},
{axis:"Deposit Interest Rate",value:"4.865"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.3571306"},
{axis:"Unemployment",value:"6"}]
    },
{className:"Egypt",
axes: [
{axis:"Inflation",value:"18.31683168"},
{axis:"Deposit Interest Rate",value:"6.583333333"},
{axis:"Lending Interest Rate",value:"12.325"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.152051034"},
{axis:"Unemployment",value:"8.699999809"}]
    },
{className:"Eritrea",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-9.783030037"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Spain",
axes: [
{axis:"Inflation",value:"4.075721828"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"33.86800212"},
{axis:"GDP",value:"1.115972755"},
{axis:"Unemployment",value:"11.5"}]
    },
{className:"Estonia",
axes: [
{axis:"Inflation",value:"10.36560303"},
{axis:"Deposit Interest Rate",value:"5.718191538"},
{axis:"Lending Interest Rate",value:"8.548630673"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.419463511"},
{axis:"Unemployment",value:"5.5"}]
    },
{className:"Ethiopia",
axes: [
{axis:"Inflation",value:"44.39128123"},
{axis:"Deposit Interest Rate",value:"4.675193071"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.78852168"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"European Union",
axes: [
{axis:"Inflation",value:"4.204766653"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.50211812"},
{axis:"Unemployment",value:"6.972085958"}]
    },
{className:"Finland",
axes: [
{axis:"Inflation",value:"4.065951657"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.720668487"},
{axis:"Unemployment",value:"6.300000191"}]
    },
{className:"Fiji",
axes: [
{axis:"Inflation",value:"7.732278579"},
{axis:"Deposit Interest Rate",value:"2.753583333"},
{axis:"Lending Interest Rate",value:"7.997269544"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.032794285"},
{axis:"Unemployment",value:"9"}]
    },
{className:"France",
axes: [
{axis:"Inflation",value:"2.813915043"},
{axis:"Deposit Interest Rate",value:"3.666666667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.195294766"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Federal States of Micronesia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.466666667"},
{axis:"Lending Interest Rate",value:"14.37833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.559644172"},
{axis:"Unemployment",value:""}]
    },
{className:"Gabon",
axes: [
{axis:"Inflation",value:"5.264301456"},
{axis:"Deposit Interest Rate",value:"3.75"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.308430649"},
{axis:"Unemployment",value:"21.20000076"}]
    },
{className:"United Kingdom",
axes: [
{axis:"Inflation",value:"3.613498886"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"4.675308333"},
{axis:"Central Government Debt",value:"57.38258269"},
{axis:"GDP",value:"-0.466876766"},
{axis:"Unemployment",value:"5.400000095"}]
    },
{className:"Georgia",
axes: [
{axis:"Inflation",value:"9.999415709"},
{axis:"Deposit Interest Rate",value:"11.23927392"},
{axis:"Lending Interest Rate",value:"18.04413333"},
{axis:"Central Government Debt",value:"27.01777146"},
{axis:"GDP",value:"2.314047429"},
{axis:"Unemployment",value:"16.5"}]
    },
{className:"Ghana",
axes: [
{axis:"Inflation",value:"16.52214331"},
{axis:"Deposit Interest Rate",value:"11.285"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.149799094"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Guinea",
axes: [
{axis:"Inflation",value:"18.38406459"},
{axis:"Deposit Interest Rate",value:"17.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.936932709"},
{axis:"Unemployment",value:"2"}]
    },
{className:"Gambia",
axes: [
{axis:"Inflation",value:"4.44365491"},
{axis:"Deposit Interest Rate",value:"12.86666667"},
{axis:"Lending Interest Rate",value:"27"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.734641946"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Guinea-Bissau",
axes: [
{axis:"Inflation",value:"10.46007314"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.204910483"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Equatorial Guinea",
axes: [
{axis:"Inflation",value:"6.551766912"},
{axis:"Deposit Interest Rate",value:"3.75"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.908375613"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Greece",
axes: [
{axis:"Inflation",value:"4.15279636"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.335172557"},
{axis:"Unemployment",value:"7.699999809"}]
    },
{className:"Grenada",
axes: [
{axis:"Inflation",value:"8.032255793"},
{axis:"Deposit Interest Rate",value:"3.22884066"},
{axis:"Lending Interest Rate",value:"9.52898493"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.949050949"},
{axis:"Unemployment",value:""}]
    },
{className:"Greenland",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.345909084"},
{axis:"Unemployment",value:""}]
    },
{className:"Guatemala",
axes: [
{axis:"Inflation",value:"11.35576113"},
{axis:"Deposit Interest Rate",value:"5.079166667"},
{axis:"Lending Interest Rate",value:"13.39166667"},
{axis:"Central Government Debt",value:"20.05394502"},
{axis:"GDP",value:"3.281079816"},
{axis:"Unemployment",value:"2.799999952"}]
    },
{className:"Guyana",
axes: [
{axis:"Inflation",value:"8.1004624"},
{axis:"Deposit Interest Rate",value:"2.373541667"},
{axis:"Lending Interest Rate",value:"14.5825"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.976647058"},
{axis:"Unemployment",value:"11.80000019"}]
    },
{className:"Hong Kong",
axes: [
{axis:"Inflation",value:"4.264392324"},
{axis:"Deposit Interest Rate",value:"0.448333333"},
{axis:"Lending Interest Rate",value:"5"},
{axis:"Central Government Debt",value:"29.89035854"},
{axis:"GDP",value:"2.127864186"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Honduras",
axes: [
{axis:"Inflation",value:"11.4062209"},
{axis:"Deposit Interest Rate",value:"9.490833333"},
{axis:"Lending Interest Rate",value:"17.93666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.23160011"},
{axis:"Unemployment",value:"3.099999905"}]
    },
{className:"Croatia",
axes: [
{axis:"Inflation",value:"6.076968388"},
{axis:"Deposit Interest Rate",value:"2.82"},
{axis:"Lending Interest Rate",value:"10.06916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.0533655"},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"Haiti",
axes: [
{axis:"Inflation",value:"15.51967613"},
{axis:"Deposit Interest Rate",value:"2.148333333"},
{axis:"Lending Interest Rate",value:"17.81083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.843944329"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Hungary",
axes: [
{axis:"Inflation",value:"6.066157153"},
{axis:"Deposit Interest Rate",value:"9.9215909"},
{axis:"Lending Interest Rate",value:"10.18166774"},
{axis:"Central Government Debt",value:"72.54313474"},
{axis:"GDP",value:"0.839345785"},
{axis:"Unemployment",value:"7.800000191"}]
    },
{className:"Indonesia",
axes: [
{axis:"Inflation",value:"9.776585195"},
{axis:"Deposit Interest Rate",value:"8.4925"},
{axis:"Lending Interest Rate",value:"13.59833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.0137036"},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"India",
axes: [
{axis:"Inflation",value:"8.351816444"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"13.3125"},
{axis:"Central Government Debt",value:"56.11267486"},
{axis:"GDP",value:"3.890957062"},
{axis:"Unemployment",value:"4.099999905"}]
    },

{className:"Ireland",
axes: [
{axis:"Inflation",value:"4.053506283"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"46.82606805"},
{axis:"GDP",value:"-2.162410157"},
{axis:"Unemployment",value:"6"}]
    },
{className:"Iran",
axes: [
{axis:"Inflation",value:"25.54984461"},
{axis:"Deposit Interest Rate",value:"13.30485123"},
{axis:"Lending Interest Rate",value:"12"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.923695792"},
{axis:"Unemployment",value:"10.5"}]
    },
{className:"Iraq",
axes: [
{axis:"Inflation",value:"12.66285283"},
{axis:"Deposit Interest Rate",value:"10.54"},
{axis:"Lending Interest Rate",value:"19.495"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.228107104"},
{axis:"Unemployment",value:"15.30000019"}]
    },
{className:"Iceland",
axes: [
{axis:"Inflation",value:"12.67818916"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"20.143333"},
{axis:"Central Government Debt",value:"79.6043338"},
{axis:"GDP",value:"1.478781618"},
{axis:"Unemployment",value:"3"}]
    },
{className:"Israel",
axes: [
{axis:"Inflation",value:"4.597472385"},
{axis:"Deposit Interest Rate",value:"2.31"},
{axis:"Lending Interest Rate",value:"5.7439939"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.059407048"},
{axis:"Unemployment",value:"6.099999905"}]
    },
{className:"Italy",
axes: [
{axis:"Inflation",value:"3.375044061"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"6.83731"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.050405284"},
{axis:"Unemployment",value:"6.699999809"}]
    },
{className:"Jamaica",
axes: [
{axis:"Inflation",value:"22.02092769"},
{axis:"Deposit Interest Rate",value:"7.555833333"},
{axis:"Lending Interest Rate",value:"16.82583333"},
{axis:"Central Government Debt",value:"120.4172619"},
{axis:"GDP",value:"-0.72230904"},
{axis:"Unemployment",value:"10.60000038"}]
    },
{className:"Jordan",
axes: [
{axis:"Inflation",value:"14.92781501"},
{axis:"Deposit Interest Rate",value:"5.460833333"},
{axis:"Lending Interest Rate",value:"9.0275"},
{axis:"Central Government Debt",value:"56.78487995"},
{axis:"GDP",value:"7.23240848"},
{axis:"Unemployment",value:"12.69999981"}]
    },
{className:"Japan",
axes: [
{axis:"Inflation",value:"1.373489988"},
{axis:"Deposit Interest Rate",value:"0.58875"},
{axis:"Lending Interest Rate",value:"1.9095"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.041636034"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Kazakhstan",
axes: [
{axis:"Inflation",value:"17.1519334"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.3"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"Kenya",
axes: [
{axis:"Inflation",value:"26.23981664"},
{axis:"Deposit Interest Rate",value:"5.302130634"},
{axis:"Lending Interest Rate",value:"14.01693938"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.232282746"},
{axis:"Unemployment",value:"9.399999619"}]
    },
{className:"Kyrgyz Republic",
axes: [
{axis:"Inflation",value:"24.5242075"},
{axis:"Deposit Interest Rate",value:"2.55676677"},
{axis:"Lending Interest Rate",value:"25.69"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.401615957"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Cambodia",
axes: [
{axis:"Inflation",value:"24.99717885"},
{axis:"Deposit Interest Rate",value:"1.905208333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.691577475"},
{axis:"Unemployment",value:"0.300000012"}]
    },
{className:"St Kitts and Nevis",
axes: [
{axis:"Inflation",value:"5.338104135"},
{axis:"Deposit Interest Rate",value:"4.549304601"},
{axis:"Lending Interest Rate",value:"8.702346054"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.128683688"},
{axis:"Unemployment",value:""}]
    },
{className:"South Korea",
axes: [
{axis:"Inflation",value:"4.674315076"},
{axis:"Deposit Interest Rate",value:"5.870833333"},
{axis:"Lending Interest Rate",value:"7.168333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.829214457"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Kosovo",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"4.420761635"},
{axis:"Lending Interest Rate",value:"13.78533918"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.644818653"},
{axis:"Unemployment",value:""}]
    },
{className:"Kuwait",
axes: [
{axis:"Inflation",value:"10.58270979"},
{axis:"Deposit Interest Rate",value:"4.805675"},
{axis:"Lending Interest Rate",value:"7.612991667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.479843833"},
{axis:"Unemployment",value:"1.799999952"}]
    },
{className:"Latin America and Caribbean (excluding high income)",
axes: [
{axis:"Inflation",value:"8.758683177"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.128844882"},
{axis:"Unemployment",value:"6.380333182"}]
    },
{className:"Lao PDR",
axes: [
{axis:"Inflation",value:"7.629305029"},
{axis:"Deposit Interest Rate",value:"4.666666667"},
{axis:"Lending Interest Rate",value:"24"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.824902763"},
{axis:"Unemployment",value:"1.399999976"}]
    },
{className:"Lebanon",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"7.704166667"},
{axis:"Lending Interest Rate",value:"9.964166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.098076674"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Liberia",
axes: [
{axis:"Inflation",value:"17.49021427"},
{axis:"Deposit Interest Rate",value:"3.995833333"},
{axis:"Lending Interest Rate",value:"14.39802886"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.146939285"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Libya",
axes: [
{axis:"Inflation",value:"10.3607289"},
{axis:"Deposit Interest Rate",value:"2.5"},
{axis:"Lending Interest Rate",value:"6"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.66735579"},
{axis:"Unemployment",value:"18.79999924"}]
    },
{className:"St Lucia",
axes: [
{axis:"Inflation",value:"7.175961687"},
{axis:"Deposit Interest Rate",value:"3.259833505"},
{axis:"Lending Interest Rate",value:"10.08493104"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.793275138"},
{axis:"Unemployment",value:""}]
    },
{className:"Latin America and Caribbean",
axes: [
{axis:"Inflation",value:"8.584013752"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.969707989"},
{axis:"Unemployment",value:"6.451974521"}]
    },
{className:"Liechtenstein",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.798087686"},
{axis:"Unemployment",value:""}]
    },
{className:"Sri Lanka",
axes: [
{axis:"Inflation",value:"22.56449553"},
{axis:"Deposit Interest Rate",value:"16.5"},
{axis:"Lending Interest Rate",value:"16.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.950088145"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"Lesotho",
axes: [
{axis:"Inflation",value:"10.71566613"},
{axis:"Deposit Interest Rate",value:"7.641666667"},
{axis:"Lending Interest Rate",value:"16.18694444"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.733473897"},
{axis:"Unemployment",value:"25.29999924"}]
    },
{className:"Lithuania",
axes: [
{axis:"Inflation",value:"10.92741147"},
{axis:"Deposit Interest Rate",value:"7.65"},
{axis:"Lending Interest Rate",value:"8.409166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.628077961"},
{axis:"Unemployment",value:"5.800000191"}]
    },
{className:"Luxembourg",
axes: [
{axis:"Inflation",value:"3.400264976"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"12.29401251"},
{axis:"GDP",value:"-0.843120826"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Latvia",
axes: [
{axis:"Inflation",value:"15.43052003"},
{axis:"Deposit Interest Rate",value:"6.339166667"},
{axis:"Lending Interest Rate",value:"11.8525"},
{axis:"Central Government Debt",value:"21.68745534"},
{axis:"GDP",value:"-3.597639193"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Macau",
axes: [
{axis:"Inflation",value:"8.602301431"},
{axis:"Deposit Interest Rate",value:"1.099018495"},
{axis:"Lending Interest Rate",value:"5.426666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.393762962"},
{axis:"Unemployment",value:"3"}]
    },
{className:"Morocco",
axes: [
{axis:"Inflation",value:"3.707317073"},
{axis:"Deposit Interest Rate",value:"3.914166667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"45.44276564"},
{axis:"GDP",value:"5.922950526"},
{axis:"Unemployment",value:"9.600000381"}]
    },
{className:"Monaco",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10"},
{axis:"Unemployment",value:""}]
    },
{className:"Moldova",
axes: [
{axis:"Inflation",value:"12.89707603"},
{axis:"Deposit Interest Rate",value:"17.93416667"},
{axis:"Lending Interest Rate",value:"21.06416667"},
{axis:"Central Government Debt",value:"18.44264949"},
{axis:"GDP",value:"7.764846405"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Madagascar",
axes: [
{axis:"Inflation",value:"9.223620364"},
{axis:"Deposit Interest Rate",value:"11.5"},
{axis:"Lending Interest Rate",value:"45"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.128513539"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Maldives",
axes: [
{axis:"Inflation",value:"12.25763226"},
{axis:"Deposit Interest Rate",value:"6.5"},
{axis:"Lending Interest Rate",value:"13"},
{axis:"Central Government Debt",value:"32.54781635"},
{axis:"GDP",value:"12.47675617"},
{axis:"Unemployment",value:"12.60000038"}]
    },
{className:"Middle East and North Africa",
axes: [
{axis:"Inflation",value:"11.27066524"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.028647754"},
{axis:"Unemployment",value:"9.924997801"}]
    },
{className:"Mexico",
axes: [
{axis:"Inflation",value:"5.124981692"},
{axis:"Deposit Interest Rate",value:"3.0425"},
{axis:"Lending Interest Rate",value:"8.705767857"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.40029037"},
{axis:"Unemployment",value:"3.5"}]
    },

{className:"Macedonia",
axes: [
{axis:"Inflation",value:"8.33189667"},
{axis:"Deposit Interest Rate",value:"5.891666667"},
{axis:"Lending Interest Rate",value:"9.683333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.471711774"},
{axis:"Unemployment",value:"33.79999924"}]
    },
{className:"Mali",
axes: [
{axis:"Inflation",value:"9.170988137"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.545858585"},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"Malta",
axes: [
{axis:"Inflation",value:"4.256736946"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"5.888333333"},
{axis:"Central Government Debt",value:"75.84570102"},
{axis:"GDP",value:"3.9"},
{axis:"Unemployment",value:"6"}]
    },
{className:"Myanmar",
axes: [
{axis:"Inflation",value:"26.79953719"},
{axis:"Deposit Interest Rate",value:"12"},
{axis:"Lending Interest Rate",value:"17"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"3.5"}]
    },
{className:"Montenegro",
axes: [
{axis:"Inflation",value:"8.758727696"},
{axis:"Deposit Interest Rate",value:"3.822316667"},
{axis:"Lending Interest Rate",value:"9.238333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.922597533"},
{axis:"Unemployment",value:"16.79999924"}]
    },
{className:"Mongolia",
axes: [
{axis:"Inflation",value:"25.05666447"},
{axis:"Deposit Interest Rate",value:"11.39166667"},
{axis:"Lending Interest Rate",value:"20.58333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.900367946"},
{axis:"Unemployment",value:"5.599999905"}]
    },

{className:"Mozambique",
axes: [
{axis:"Inflation",value:"10.3277911"},
{axis:"Deposit Interest Rate",value:"10.9847672"},
{axis:"Lending Interest Rate",value:"18.31"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.876205447"},
{axis:"Unemployment",value:"22.60000038"}]
    },
{className:"Mauritania",
axes: [
{axis:"Inflation",value:"7.346635412"},
{axis:"Deposit Interest Rate",value:"8"},
{axis:"Lending Interest Rate",value:"20.33333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.079967167"},
{axis:"Unemployment",value:"31.20000076"}]
    },
{className:"Mauritius",
axes: [
{axis:"Inflation",value:"9.732723333"},
{axis:"Deposit Interest Rate",value:"10.10833333"},
{axis:"Lending Interest Rate",value:"11.54166667"},
{axis:"Central Government Debt",value:"34.91972743"},
{axis:"GDP",value:"5.511089889"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Malawi",
axes: [
{axis:"Inflation",value:"8.712601866"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:"25.27777778"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.639736774"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Malaysia",
axes: [
{axis:"Inflation",value:"5.440782211"},
{axis:"Deposit Interest Rate",value:"3.125833333"},
{axis:"Lending Interest Rate",value:"6.08"},
{axis:"Central Government Debt",value:"39.79975453"},
{axis:"GDP",value:"4.831769894"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"North America",
axes: [
{axis:"Inflation",value:"3.104685486"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"64.03177718"},
{axis:"GDP",value:"-0.167114794"},
{axis:"Unemployment",value:"5.921093723"}]
    },
{className:"Namibia",
axes: [
{axis:"Inflation",value:"9.094643072"},
{axis:"Deposit Interest Rate",value:"8.384166667"},
{axis:"Lending Interest Rate",value:"13.73666667"},
{axis:"Central Government Debt",value:"17.35966049"},
{axis:"GDP",value:"2.649811967"},
{axis:"Unemployment",value:"37.59999847"}]
    },

{className:"Niger",
axes: [
{axis:"Inflation",value:"11.30510988"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.587673209"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Nigeria",
axes: [
{axis:"Inflation",value:"11.57798352"},
{axis:"Deposit Interest Rate",value:"11.97083333"},
{axis:"Lending Interest Rate",value:"15.47983333"},
{axis:"Central Government Debt",value:"11.5287729"},
{axis:"GDP",value:"6.270263697"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Nicaragua",
axes: [
{axis:"Inflation",value:"19.82620313"},
{axis:"Deposit Interest Rate",value:"6.572587152"},
{axis:"Lending Interest Rate",value:"13.16935036"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.851710935"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"Netherlands",
axes: [
{axis:"Inflation",value:"2.486550321"},
{axis:"Deposit Interest Rate",value:"4.370833333"},
{axis:"Lending Interest Rate",value:"4.604166667"},
{axis:"Central Government Debt",value:"52.83800845"},
{axis:"GDP",value:"1.699060778"},
{axis:"Unemployment",value:"2.799999952"}]
    },
{className:"Norway",
axes: [
{axis:"Inflation",value:"3.766160764"},
{axis:"Deposit Interest Rate",value:"5.498123211"},
{axis:"Lending Interest Rate",value:"7.278970292"},
{axis:"Central Government Debt",value:"43.51568466"},
{axis:"GDP",value:"0.384306038"},
{axis:"Unemployment",value:"2.599999905"}]
    },
{className:"Nepal",
axes: [
{axis:"Inflation",value:"9.878396059"},
{axis:"Deposit Interest Rate",value:"2.395833333"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:"43.79998725"},
{axis:"GDP",value:"6.104639142"},
{axis:"Unemployment",value:"2.700000048"}]
    },
{className:"New Zealand",
axes: [
{axis:"Inflation",value:"3.958944282"},
{axis:"Deposit Interest Rate",value:"7.551441667"},
{axis:"Lending Interest Rate",value:"8.938532681"},
{axis:"Central Government Debt",value:"36.05602849"},
{axis:"GDP",value:"-1.309300019"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Oman",
axes: [
{axis:"Inflation",value:"12.09082734"},
{axis:"Deposit Interest Rate",value:"4.48"},
{axis:"Lending Interest Rate",value:"7.099"},
{axis:"Central Government Debt",value:"4.11989017"},
{axis:"GDP",value:"8.199695813"},
{axis:"Unemployment",value:"7.699999809"}]
    },
{className:"Pakistan",
axes: [
{axis:"Inflation",value:"20.28612109"},
{axis:"Deposit Interest Rate",value:"6.918333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.701405465"},
{axis:"Unemployment",value:"5"}]
    },
{className:"Panama",
axes: [
{axis:"Inflation",value:"8.758683177"},
{axis:"Deposit Interest Rate",value:"3.531064366"},
{axis:"Lending Interest Rate",value:"8.163375659"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.611646134"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Peru",
axes: [
{axis:"Inflation",value:"5.785875982"},
{axis:"Deposit Interest Rate",value:"3.506433706"},
{axis:"Lending Interest Rate",value:"23.6734449"},
{axis:"Central Government Debt",value:"25.85717367"},
{axis:"GDP",value:"9.143148198"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Philippines",
axes: [
{axis:"Inflation",value:"8.260447036"},
{axis:"Deposit Interest Rate",value:"4.4895"},
{axis:"Lending Interest Rate",value:"8.751083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.152757145"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"Palau",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.588078765"},
{axis:"Unemployment",value:""}]
    },
{className:"Papua New Guinea",
axes: [
{axis:"Inflation",value:"10.76141823"},
{axis:"Deposit Interest Rate",value:"1.313661021"},
{axis:"Lending Interest Rate",value:"9.196666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.610958325"},
{axis:"Unemployment",value:"2.5"}]
    },
{className:"Poland",
axes: [
{axis:"Inflation",value:"4.349378235"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"44.57075181"},
{axis:"GDP",value:"3.920379277"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Puerto Rico",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.798808345"},
{axis:"Unemployment",value:"11.80000019"}]
    },
{className:"Portugal",
axes: [
{axis:"Inflation",value:"2.590407797"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.199272251"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Paraguay",
axes: [
{axis:"Inflation",value:"10.15454466"},
{axis:"Deposit Interest Rate",value:"3.0775"},
{axis:"Lending Interest Rate",value:"25.80750112"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.35911702"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Qatar",
axes: [
{axis:"Inflation",value:"15.05014516"},
{axis:"Deposit Interest Rate",value:"2.965"},
{axis:"Lending Interest Rate",value:"6.844166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"17.66355638"},
{axis:"Unemployment",value:"0.300000012"}]
    },
{className:"Romania",
axes: [
{axis:"Inflation",value:"7.848325144"},
{axis:"Deposit Interest Rate",value:"9.513333333"},
{axis:"Lending Interest Rate",value:"14.98833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.45898402"},
{axis:"Unemployment",value:"5.800000191"}]
    },
{className:"Russian Federation",
axes: [
{axis:"Inflation",value:"14.11222781"},
{axis:"Deposit Interest Rate",value:"5.758333333"},
{axis:"Lending Interest Rate",value:"12.225"},
{axis:"Central Government Debt",value:"6.495287372"},
{axis:"GDP",value:"5.247953532"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"Rwanda",
axes: [
{axis:"Inflation",value:"15.44493118"},
{axis:"Deposit Interest Rate",value:"6.72"},
{axis:"Lending Interest Rate",value:"16.51"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.16246001"},
{axis:"Unemployment",value:"0.600000024"}]
    },
{className:"South Asia",
axes: [
{axis:"Inflation",value:"11.06801416"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.883498889"},
{axis:"Unemployment",value:"4.249849954"}]
    },
{className:"Saudi Arabia",
axes: [
{axis:"Inflation",value:"9.868751965"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.427164639"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Sudan",
axes: [
{axis:"Inflation",value:"14.30651248"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.801963334"},
{axis:"Unemployment",value:"14.80000019"}]
    },
{className:"Senegal",
axes: [
{axis:"Inflation",value:"5.769758507"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.682524403"},
{axis:"Unemployment",value:"9.399999619"}]
    },
{className:"Singapore",
axes: [
{axis:"Inflation",value:"6.518590053"},
{axis:"Deposit Interest Rate",value:"0.419166667"},
{axis:"Lending Interest Rate",value:"5.38"},
{axis:"Central Government Debt",value:"97.10515905"},
{axis:"GDP",value:"1.787620228"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Solomon Islands",
axes: [
{axis:"Inflation",value:"17.3200652"},
{axis:"Deposit Interest Rate",value:"0.95"},
{axis:"Lending Interest Rate",value:"14.43583333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.094495143"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Sierra Leone",
axes: [
{axis:"Inflation",value:"-35.83667636"},
{axis:"Deposit Interest Rate",value:"10.5925"},
{axis:"Lending Interest Rate",value:"24.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.399676742"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"El Salvador",
axes: [
{axis:"Inflation",value:"6.707922935"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"40.64439528"},
{axis:"GDP",value:"1.274227301"},
{axis:"Unemployment",value:"5.900000095"}]
    },
{className:"San Marino",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.2275"},
{axis:"Lending Interest Rate",value:"7.8925"},
{axis:"Central Government Debt",value:"59.04640987"},
{axis:"GDP",value:"1.898734177"},
{axis:"Unemployment",value:""}]
    },
{className:"Somalia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Serbia",
axes: [
{axis:"Inflation",value:"12.41098678"},
{axis:"Deposit Interest Rate",value:"7.32"},
{axis:"Lending Interest Rate",value:"16.1267"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.366683424"},
{axis:"Unemployment",value:"13.60000038"}]
    },
{className:"Sao Tome and Principe",
axes: [
{axis:"Inflation",value:"31.99010395"},
{axis:"Deposit Interest Rate",value:"12.75"},
{axis:"Lending Interest Rate",value:"32.4"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.186171817"},
{axis:"Unemployment",value:""}]
    },
{className:"Suriname",
axes: [
{axis:"Inflation",value:"14.66714274"},
{axis:"Deposit Interest Rate",value:"6.341666667"},
{axis:"Lending Interest Rate",value:"12.2"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.143406525"},
{axis:"Unemployment",value:"5.800000191"}]
    },
{className:"Slovak Republic",
axes: [
{axis:"Inflation",value:"4.598179763"},
{axis:"Deposit Interest Rate",value:"3.729166667"},
{axis:"Lending Interest Rate",value:"5.747916667"},
{axis:"Central Government Debt",value:"29.58298"},
{axis:"GDP",value:"5.652722009"},
{axis:"Unemployment",value:"9.600000381"}]
    },
{className:"Slovenia",
axes: [
{axis:"Inflation",value:"5.65184627"},
{axis:"Deposit Interest Rate",value:"4.051666667"},
{axis:"Lending Interest Rate",value:"6.658333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.300289653"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Sweden",
axes: [
{axis:"Inflation",value:"3.437049106"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.557047628"},
{axis:"Unemployment",value:"6.300000191"}]
    },
{className:"Swaziland",
axes: [
{axis:"Inflation",value:"12.65746019"},
{axis:"Deposit Interest Rate",value:"8.166666667"},
{axis:"Lending Interest Rate",value:"14.83333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.373518272"},
{axis:"Unemployment",value:"23"}]
    },
{className:"Seychelles",
axes: [
{axis:"Inflation",value:"36.96475829"},
{axis:"Deposit Interest Rate",value:"3.966166155"},
{axis:"Lending Interest Rate",value:"11.80777072"},
{axis:"Central Government Debt",value:"176.7930824"},
{axis:"GDP",value:"-2.146892655"},
{axis:"Unemployment",value:""}]
    },
{className:"Syrian Arab Republic",
axes: [
{axis:"Inflation",value:"15.74532522"},
{axis:"Deposit Interest Rate",value:"8.118666707"},
{axis:"Lending Interest Rate",value:"10.1880127"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"10.89999962"}]
    },
{className:"Chad",
axes: [
{axis:"Inflation",value:"10.29697582"},
{axis:"Deposit Interest Rate",value:"3.75"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.052691532"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"East Asia and Pacific (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"9.776585195"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.407978346"},
{axis:"Unemployment",value:"4.641640011"}]
    },
{className:"Europe and Central Asia (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"12.34877209"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.280132439"},
{axis:"Unemployment",value:"7.8621262"}]
    },
{className:"Togo",
axes: [
{axis:"Inflation",value:"8.681967213"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.225480232"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Thailand",
axes: [
{axis:"Inflation",value:"5.468489496"},
{axis:"Deposit Interest Rate",value:"2.479166667"},
{axis:"Lending Interest Rate",value:"7.041666667"},
{axis:"Central Government Debt",value:"22.45021048"},
{axis:"GDP",value:"1.725667908"},
{axis:"Unemployment",value:"1.200000048"}]
    },
{className:"Tajikistan",
axes: [
{axis:"Inflation",value:"20.47052191"},
{axis:"Deposit Interest Rate",value:"9.370259837"},
{axis:"Lending Interest Rate",value:"23.5944101"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.899997831"},
{axis:"Unemployment",value:"11.30000019"}]
    },
{className:"Turkmenistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"14.7"},
{axis:"Unemployment",value:"11.10000038"}]
    },
{className:"Latin America and the Caribbean (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"8.65014115"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.110491298"},
{axis:"Unemployment",value:"6.514138926"}]
    },
{className:"Middle East and North Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"12.66285283"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.849959014"},
{axis:"Unemployment",value:"10.90280335"}]
    },
{className:"Timor-Leste",
axes: [
{axis:"Inflation",value:"9.064236219"},
{axis:"Deposit Interest Rate",value:"0.79656919"},
{axis:"Lending Interest Rate",value:"13.10989918"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"14.19939577"},
{axis:"Unemployment",value:"5.900000095"}]
    },
{className:"Tonga",
axes: [
{axis:"Inflation",value:"10.43899658"},
{axis:"Deposit Interest Rate",value:"6.525"},
{axis:"Lending Interest Rate",value:"12.45787603"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.456248639"},
{axis:"Unemployment",value:""}]
    },
{className:"South Asia (IDA and IBRD)",
axes: [
{axis:"Inflation",value:"11.06801416"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.883498889"},
{axis:"Unemployment",value:"4.249849954"}]
    },
{className:"Sub-Saharan Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"10.39393212"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.318824314"},
{axis:"Unemployment",value:"8.14805872"}]
    },
{className:"Trinidad and Tobago",
axes: [
{axis:"Inflation",value:"12.0484971"},
{axis:"Deposit Interest Rate",value:"7.37"},
{axis:"Lending Interest Rate",value:"12.4375"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.390421366"},
{axis:"Unemployment",value:"4.599999905"}]
    },
{className:"Tunisia",
axes: [
{axis:"Inflation",value:"4.920696325"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"43.29193491"},
{axis:"GDP",value:"4.237776836"},
{axis:"Unemployment",value:"12.39999962"}]
    },
{className:"Turkey",
axes: [
{axis:"Inflation",value:"10.44412838"},
{axis:"Deposit Interest Rate",value:"22.91333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"43.47996964"},
{axis:"GDP",value:"0.658839041"},
{axis:"Unemployment",value:"11"}]
    },
{className:"Tuvalu",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.983260905"},
{axis:"Unemployment",value:""}]
    },
{className:"Tanzania",
axes: [
{axis:"Inflation",value:"10.27839376"},
{axis:"Deposit Interest Rate",value:"8.252651937"},
{axis:"Lending Interest Rate",value:"14.98213468"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.566595648"},
{axis:"Unemployment",value:"2.5"}]
    },
{className:"Uganda",
axes: [
{axis:"Inflation",value:"12.05085555"},
{axis:"Deposit Interest Rate",value:"10.67053623"},
{axis:"Lending Interest Rate",value:"20.4500661"},
{axis:"Central Government Debt",value:"33.19319989"},
{axis:"GDP",value:"8.708751901"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Ukraine",
axes: [
{axis:"Inflation",value:"25.23191095"},
{axis:"Deposit Interest Rate",value:"9.948791667"},
{axis:"Lending Interest Rate",value:"17.4925"},
{axis:"Central Government Debt",value:"13.82670433"},
{axis:"GDP",value:"2.299999986"},
{axis:"Unemployment",value:"6.400000095"}]
    },
{className:"Uruguay",
axes: [
{axis:"Inflation",value:"7.860951729"},
{axis:"Deposit Interest Rate",value:"3.23125725"},
{axis:"Lending Interest Rate",value:"12.4476125"},
{axis:"Central Government Debt",value:"57.25268252"},
{axis:"GDP",value:"7.176144661"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"United States",
axes: [
{axis:"Inflation",value:"3.839100297"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"5.0875"},
{axis:"Central Government Debt",value:"64.03177718"},
{axis:"GDP",value:"-0.291621459"},
{axis:"Unemployment",value:"5.900000095"}]
    },
{className:"Uzbekistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9"},
{axis:"Unemployment",value:"11"}]
    },
{className:"St Vincent and the Grenadines",
axes: [
{axis:"Inflation",value:"10.06624182"},
{axis:"Deposit Interest Rate",value:"2.791566564"},
{axis:"Lending Interest Rate",value:"9.524416092"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.7319684"},
{axis:"Unemployment",value:""}]
    },
{className:"Venezuela",
axes: [
{axis:"Inflation",value:"31.44059869"},
{axis:"Deposit Interest Rate",value:"16.15333333"},
{axis:"Lending Interest Rate",value:"22.37083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.277854124"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Vietnam",
axes: [
{axis:"Inflation",value:"23.11631629"},
{axis:"Deposit Interest Rate",value:"12.73041667"},
{axis:"Lending Interest Rate",value:"15.78357143"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.661771208"},
{axis:"Unemployment",value:"2.400000095"}]
    },
{className:"Vanuatu",
axes: [
{axis:"Inflation",value:"4.827285892"},
{axis:"Deposit Interest Rate",value:"1.25"},
{axis:"Lending Interest Rate",value:"5.291666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.448521358"},
{axis:"Unemployment",value:""}]
    },
{className:"West Bank and Gaza",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.805"},
{axis:"Lending Interest Rate",value:"7.1875"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-8.590175873"},
{axis:"Unemployment",value:"26"}]
    },
{className:"World",
axes: [
{axis:"Inflation",value:"8.949953354"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.849668037"},
{axis:"Unemployment",value:"5.692450066"}]
    },
{className:"Samoa",
axes: [
{axis:"Inflation",value:"11.56590684"},
{axis:"Deposit Interest Rate",value:"6.060833333"},
{axis:"Lending Interest Rate",value:"12.66083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.009086658"},
{axis:"Unemployment",value:""}]
    },
{className:"Yemen",
axes: [
{axis:"Inflation",value:"18.97625743"},
{axis:"Deposit Interest Rate",value:"13"},
{axis:"Lending Interest Rate",value:"18"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.014388868"},
{axis:"Unemployment",value:"15"}]
    },
{className:"South Africa",
axes: [
{axis:"Inflation",value:"11.53645077"},
{axis:"Deposit Interest Rate",value:"11.6125"},
{axis:"Lending Interest Rate",value:"15.125"},
{axis:"Central Government Debt",value:"26.01847126"},
{axis:"GDP",value:"3.191043888"},
{axis:"Unemployment",value:"22.70000076"}]
    },
{className:"Democratic Republic of the Congo",
axes: [
{axis:"Inflation",value:"17.30138457"},
{axis:"Deposit Interest Rate",value:"7.7975"},
{axis:"Lending Interest Rate",value:"43.15416667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.225900286"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Zambia",
axes: [
{axis:"Inflation",value:"12.44557935"},
{axis:"Deposit Interest Rate",value:"6.550705128"},
{axis:"Lending Interest Rate",value:"19.06318716"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.773895812"},
{axis:"Unemployment",value:"15.60000038"}]
    },
{className:"Zimbabwe",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-17.6689466"},
{axis:"Unemployment",value:"5.699999809"}]
    }
],
["2009",
{className:"Aruba",
axes: [
{axis:"Inflation",value:"-2.136371573"},
{axis:"Deposit Interest Rate",value:"3.35"},
{axis:"Lending Interest Rate",value:"10.76666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.653502086"},
{axis:"Unemployment",value:""}]
    },
{className:"Andorra",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.817986024"},
{axis:"Unemployment",value:""}]
    },
{className:"Afghanistan",
axes: [
{axis:"Inflation",value:"-8.283078395"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"15"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"21.02064874"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Angola",
axes: [
{axis:"Inflation",value:"13.73145114"},
{axis:"Deposit Interest Rate",value:"7.589366608"},
{axis:"Lending Interest Rate",value:"15.68207424"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.412869693"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Albania",
axes: [
{axis:"Inflation",value:"2.280502222"},
{axis:"Deposit Interest Rate",value:"6.772436227"},
{axis:"Lending Interest Rate",value:"12.66093515"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.350000009"},
{axis:"Unemployment",value:"13.80000019"}]
    },
{className:"United Arab Emirates",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.242921906"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Argentina",
axes: [
{axis:"Inflation",value:"6.282774315"},
{axis:"Deposit Interest Rate",value:"11.60403511"},
{axis:"Lending Interest Rate",value:"15.655"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-6.013355331"},
{axis:"Unemployment",value:"8.600000381"}]
    },
{className:"Armenia",
axes: [
{axis:"Inflation",value:"3.406766827"},
{axis:"Deposit Interest Rate",value:"8.652928631"},
{axis:"Lending Interest Rate",value:"18.76447059"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-14.14998864"},
{axis:"Unemployment",value:"18.70000076"}]
    },
{className:"Antigua and Barbuda",
axes: [
{axis:"Inflation",value:"-0.550159996"},
{axis:"Deposit Interest Rate",value:"3.483578868"},
{axis:"Lending Interest Rate",value:"10.06537009"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-12.03601506"},
{axis:"Unemployment",value:""}]
    },
{className:"Australia",
axes: [
{axis:"Inflation",value:"1.82011224"},
{axis:"Deposit Interest Rate",value:"3.079166667"},
{axis:"Lending Interest Rate",value:"6.020833333"},
{axis:"Central Government Debt",value:"24.00189297"},
{axis:"GDP",value:"1.819678261"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Austria",
axes: [
{axis:"Inflation",value:"0.506312509"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.799075048"},
{axis:"Unemployment",value:"4.800000191"}]
    },
{className:"Azerbaijan",
axes: [
{axis:"Inflation",value:"1.401056148"},
{axis:"Deposit Interest Rate",value:"12.19583333"},
{axis:"Lending Interest Rate",value:"20.02916667"},
{axis:"Central Government Debt",value:"6.295012401"},
{axis:"GDP",value:"9.410653764"},
{axis:"Unemployment",value:"5.699999809"}]
    },
{className:"Burundi",
axes: [
{axis:"Inflation",value:"10.98146877"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"14.07583333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.468425425"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Belgium",
axes: [
{axis:"Inflation",value:"-0.053145674"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"9.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.284879004"},
{axis:"Unemployment",value:"7.900000095"}]
    },
{className:"Benin",
axes: [
{axis:"Inflation",value:"2.156829962"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.319226924"},
{axis:"Unemployment",value:"1.200000048"}]
    },
{className:"Burkina Faso",
axes: [
{axis:"Inflation",value:"2.608176664"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.962014371"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Bangladesh",
axes: [
{axis:"Inflation",value:"5.423472362"},
{axis:"Deposit Interest Rate",value:"7.814166667"},
{axis:"Lending Interest Rate",value:"13.32666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.045124794"},
{axis:"Unemployment",value:"5"}]
    },
{className:"Bulgaria",
axes: [
{axis:"Inflation",value:"2.753172487"},
{axis:"Deposit Interest Rate",value:"6.1775"},
{axis:"Lending Interest Rate",value:"11.335"},
{axis:"Central Government Debt",value:"12.96336221"},
{axis:"GDP",value:"-4.219727062"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Bahrain",
axes: [
{axis:"Inflation",value:"2.795512836"},
{axis:"Deposit Interest Rate",value:"1.581666667"},
{axis:"Lending Interest Rate",value:"7.941428571"},
{axis:"Central Government Debt",value:"15.62940229"},
{axis:"GDP",value:"2.539772469"},
{axis:"Unemployment",value:"4"}]
    },
{className:"The Bahamas",
axes: [
{axis:"Inflation",value:"2.062734735"},
{axis:"Deposit Interest Rate",value:"3.7825"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.175259175"},
{axis:"Unemployment",value:"14.19999981"}]
    },
{className:"Bosnia and Herzegovina",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"3.6"},
{axis:"Lending Interest Rate",value:"7.9325"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.86988112"},
{axis:"Unemployment",value:"24.10000038"}]
    },
{className:"Belarus",
axes: [
{axis:"Inflation",value:"12.94565634"},
{axis:"Deposit Interest Rate",value:"10.68333333"},
{axis:"Lending Interest Rate",value:"11.675"},
{axis:"Central Government Debt",value:"19.18518401"},
{axis:"GDP",value:"0.2"},
{axis:"Unemployment",value:"6.099999905"}]
    },
{className:"Belize",
axes: [
{axis:"Inflation",value:"-1.080019637"},
{axis:"Deposit Interest Rate",value:"8.3725"},
{axis:"Lending Interest Rate",value:"14.08166667"},
{axis:"Central Government Debt",value:"82.00437972"},
{axis:"GDP",value:"0.799202009"},
{axis:"Unemployment",value:"11.19999981"}]
    },
{className:"Bermuda",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.284177149"},
{axis:"Unemployment",value:""}]
    },
{className:"Bolivia",
axes: [
{axis:"Inflation",value:"3.349369826"},
{axis:"Deposit Interest Rate",value:"3.439283333"},
{axis:"Lending Interest Rate",value:"12.359625"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.357001259"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"Brazil",
axes: [
{axis:"Inflation",value:"4.886408444"},
{axis:"Deposit Interest Rate",value:"9.278831768"},
{axis:"Lending Interest Rate",value:"44.65"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.126147415"},
{axis:"Unemployment",value:"8.300000191"}]
    },
{className:"Barbados",
axes: [
{axis:"Inflation",value:"3.643861893"},
{axis:"Deposit Interest Rate",value:"2.865833333"},
{axis:"Lending Interest Rate",value:"9.204166667"},
{axis:"Central Government Debt",value:"84.30279148"},
{axis:"GDP",value:"-4.031551271"},
{axis:"Unemployment",value:"10"}]
    },
{className:"Brunei Darussalam",
axes: [
{axis:"Inflation",value:"1.035717743"},
{axis:"Deposit Interest Rate",value:"0.699921292"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.764535725"},
{axis:"Unemployment",value:"3.5"}]
    },
{className:"Bhutan",
axes: [
{axis:"Inflation",value:"4.361122191"},
{axis:"Deposit Interest Rate",value:"2"},
{axis:"Lending Interest Rate",value:"13.75"},
{axis:"Central Government Debt",value:"56.77631368"},
{axis:"GDP",value:"6.657223796"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Botswana",
axes: [
{axis:"Inflation",value:"8.027297031"},
{axis:"Deposit Interest Rate",value:"7.469520833"},
{axis:"Lending Interest Rate",value:"13.755625"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-7.652310203"},
{axis:"Unemployment",value:"18.39999962"}]
    },
{className:"Central African Republic",
axes: [
{axis:"Inflation",value:"3.5199021"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.709220967"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Canada",
axes: [
{axis:"Inflation",value:"0.299466803"},
{axis:"Deposit Interest Rate",value:"0.095833333"},
{axis:"Lending Interest Rate",value:"2.395833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.949587643"},
{axis:"Unemployment",value:"8.300000191"}]
    },
{className:"Central Europe and the Baltics",
axes: [
{axis:"Inflation",value:"2.753172487"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"39.68029465"},
{axis:"GDP",value:"-3.751650797"},
{axis:"Unemployment",value:"8.498345253"}]
    },
{className:"Switzerland",
axes: [
{axis:"Inflation",value:"-0.48057991"},
{axis:"Deposit Interest Rate",value:"0.08"},
{axis:"Lending Interest Rate",value:"2.750833333"},
{axis:"Central Government Debt",value:"24.41534244"},
{axis:"GDP",value:"-2.129618511"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Chile",
axes: [
{axis:"Inflation",value:"0.071761556"},
{axis:"Deposit Interest Rate",value:"2.047606685"},
{axis:"Lending Interest Rate",value:"7.250634769"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.036431779"},
{axis:"Unemployment",value:"9.699999809"}]
    },
{className:"China",
axes: [
{axis:"Inflation",value:"-0.702949137"},
{axis:"Deposit Interest Rate",value:"2.25"},
{axis:"Lending Interest Rate",value:"5.31"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.233551095"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Cote dIvoire",
axes: [
{axis:"Inflation",value:"1.019504577"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.251453719"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Cameroon",
axes: [
{axis:"Inflation",value:"3.043618479"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.931850591"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Republic of Congo",
axes: [
{axis:"Inflation",value:"5.299319915"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.468878032"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Colombia",
axes: [
{axis:"Inflation",value:"4.202933108"},
{axis:"Deposit Interest Rate",value:"6.145783423"},
{axis:"Lending Interest Rate",value:"13.0080746"},
{axis:"Central Government Debt",value:"68.57884245"},
{axis:"GDP",value:"1.651549245"},
{axis:"Unemployment",value:"11.80000019"}]
    },
{className:"Comoros",
axes: [
{axis:"Inflation",value:"4.362348293"},
{axis:"Deposit Interest Rate",value:"1.875"},
{axis:"Lending Interest Rate",value:"10.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.949999978"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Cabo Verde",
axes: [
{axis:"Inflation",value:"0.983222786"},
{axis:"Deposit Interest Rate",value:"2.884593535"},
{axis:"Lending Interest Rate",value:"10.97664503"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.270403675"},
{axis:"Unemployment",value:"9.399999619"}]
    },
{className:"Costa Rica",
axes: [
{axis:"Inflation",value:"7.843825841"},
{axis:"Deposit Interest Rate",value:"6.959166667"},
{axis:"Lending Interest Rate",value:"19.72333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.015718862"},
{axis:"Unemployment",value:"7.800000191"}]
    },
{className:"Caribbean small states",
axes: [
{axis:"Inflation",value:"0.421539126"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.567806371"},
{axis:"Unemployment",value:"9.959163051"}]
    },
{className:"Cuba",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.449116717"},
{axis:"Unemployment",value:"1.700000048"}]
    },
{className:"Cyprus",
axes: [
{axis:"Inflation",value:"0.374079976"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.028977871"},
{axis:"Unemployment",value:"5.400000095"}]
    },
{className:"Czech Republic",
axes: [
{axis:"Inflation",value:"1.044811886"},
{axis:"Deposit Interest Rate",value:"1.265016667"},
{axis:"Lending Interest Rate",value:"5.989958333"},
{axis:"Central Government Debt",value:"29.58988247"},
{axis:"GDP",value:"-4.841785296"},
{axis:"Unemployment",value:"6.699999809"}]
    },
{className:"Germany",
axes: [
{axis:"Inflation",value:"0.312737723"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.618860435"},
{axis:"Unemployment",value:"7.699999809"}]
    },
{className:"Djibouti",
axes: [
{axis:"Inflation",value:"1.675495873"},
{axis:"Deposit Interest Rate",value:"1.6675"},
{axis:"Lending Interest Rate",value:"11.445"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.032627058"},
{axis:"Unemployment",value:""}]
    },
{className:"Dominica",
axes: [
{axis:"Inflation",value:"0.029933034"},
{axis:"Deposit Interest Rate",value:"3.203233839"},
{axis:"Lending Interest Rate",value:"10.01929406"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.166666667"},
{axis:"Unemployment",value:""}]
    },
{className:"Denmark",
axes: [
{axis:"Inflation",value:"1.326372231"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.087936061"},
{axis:"Unemployment",value:"6"}]
    },
{className:"Dominican Republic",
axes: [
{axis:"Inflation",value:"1.442151318"},
{axis:"Deposit Interest Rate",value:"7.8125"},
{axis:"Lending Interest Rate",value:"18.13583333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.935781292"},
{axis:"Unemployment",value:"14.89999962"}]
    },
{className:"Algeria",
axes: [
{axis:"Inflation",value:"5.734333414"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.6"},
{axis:"Unemployment",value:"10.19999981"}]
    },
{className:"East Asia and Pacific (excluding high income)",
axes: [
{axis:"Inflation",value:"3.214695752"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.549292177"},
{axis:"Unemployment",value:"4.620959263"}]
    },
{className:"East Asia and Pacific",
axes: [
{axis:"Inflation",value:"1.472343114"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.322244921"},
{axis:"Unemployment",value:"4.633815167"}]
    },
{className:"Europe and Central Asia (excluding high income)",
axes: [
{axis:"Inflation",value:"5.587663497"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-6.123475798"},
{axis:"Unemployment",value:"9.675103776"}]
    },
{className:"Europe and Central Asia",
axes: [
{axis:"Inflation",value:"1.615104641"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.501359154"},
{axis:"Unemployment",value:"9.250267252"}]
    },
{className:"Ecuador",
axes: [
{axis:"Inflation",value:"5.157924"},
{axis:"Deposit Interest Rate",value:"4.78"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.566491592"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Egypt",
axes: [
{axis:"Inflation",value:"11.76349544"},
{axis:"Deposit Interest Rate",value:"6.491666667"},
{axis:"Lending Interest Rate",value:"11.975"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.685445188"},
{axis:"Unemployment",value:"9.399999619"}]
    },
{className:"Eritrea",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.87650156"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"Spain",
axes: [
{axis:"Inflation",value:"-0.287977653"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"46.08056765"},
{axis:"GDP",value:"-3.57381203"},
{axis:"Unemployment",value:"18.10000038"}]
    },
{className:"Estonia",
axes: [
{axis:"Inflation",value:"-0.084776494"},
{axis:"Deposit Interest Rate",value:"4.818867049"},
{axis:"Lending Interest Rate",value:"9.385771895"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-14.72440239"},
{axis:"Unemployment",value:"13.80000019"}]
    },
{className:"Ethiopia",
axes: [
{axis:"Inflation",value:"8.468335788"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.802553202"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"European Union",
axes: [
{axis:"Inflation",value:"0.950366"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.390684954"},
{axis:"Unemployment",value:"8.955942541"}]
    },
{className:"Finland",
axes: [
{axis:"Inflation",value:"0.00061529"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-8.269036558"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Fiji",
axes: [
{axis:"Inflation",value:"3.214695752"},
{axis:"Deposit Interest Rate",value:"4.91284765"},
{axis:"Lending Interest Rate",value:"7.853416015"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.386037503"},
{axis:"Unemployment",value:"8.699999809"}]
    },
{className:"France",
axes: [
{axis:"Inflation",value:"0.088084169"},
{axis:"Deposit Interest Rate",value:"1.916666667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.941341055"},
{axis:"Unemployment",value:"9.100000381"}]
    },
{className:"Federal States of Micronesia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"1.285833333"},
{axis:"Lending Interest Rate",value:"15.38"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.961955354"},
{axis:"Unemployment",value:""}]
    },
{className:"Gabon",
axes: [
{axis:"Inflation",value:"1.885707546"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.13033112"},
{axis:"Unemployment",value:"21.29999924"}]
    },
{className:"United Kingdom",
axes: [
{axis:"Inflation",value:"2.166231372"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"0.644866667"},
{axis:"Central Government Debt",value:"71.42362131"},
{axis:"GDP",value:"-4.19194486"},
{axis:"Unemployment",value:"7.800000191"}]
    },
{className:"Georgia",
axes: [
{axis:"Inflation",value:"1.727540364"},
{axis:"Deposit Interest Rate",value:"10.81032344"},
{axis:"Lending Interest Rate",value:"17.86631667"},
{axis:"Central Government Debt",value:"34.61145176"},
{axis:"GDP",value:"-3.775774557"},
{axis:"Unemployment",value:"16.89999962"}]
    },
{className:"Ghana",
axes: [
{axis:"Inflation",value:"19.25071443"},
{axis:"Deposit Interest Rate",value:"17.06416667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.845756132"},
{axis:"Unemployment",value:"2.200000048"}]
    },
{className:"Guinea",
axes: [
{axis:"Inflation",value:"4.68438869"},
{axis:"Deposit Interest Rate",value:"17.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.280192286"},
{axis:"Unemployment",value:"1.600000024"}]
    },
{className:"Gambia",
axes: [
{axis:"Inflation",value:"4.561581547"},
{axis:"Deposit Interest Rate",value:"15.5"},
{axis:"Lending Interest Rate",value:"27"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.449695858"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Guinea-Bissau",
axes: [
{axis:"Inflation",value:"-1.651397336"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.314407697"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Equatorial Guinea",
axes: [
{axis:"Inflation",value:"4.691065677"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.534718957"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Greece",
axes: [
{axis:"Inflation",value:"1.210073956"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.300733667"},
{axis:"Unemployment",value:"9.5"}]
    },
{className:"Grenada",
axes: [
{axis:"Inflation",value:"-0.309006161"},
{axis:"Deposit Interest Rate",value:"3.273379996"},
{axis:"Lending Interest Rate",value:"10.99305348"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-6.613908956"},
{axis:"Unemployment",value:""}]
    },
{className:"Greenland",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.411986294"},
{axis:"Unemployment",value:""}]
    },
{className:"Guatemala",
axes: [
{axis:"Inflation",value:"1.859102547"},
{axis:"Deposit Interest Rate",value:"5.576666667"},
{axis:"Lending Interest Rate",value:"13.84916667"},
{axis:"Central Government Debt",value:"23.01723398"},
{axis:"GDP",value:"0.526043018"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Guyana",
axes: [
{axis:"Inflation",value:"2.913358428"},
{axis:"Deposit Interest Rate",value:"2.323908333"},
{axis:"Lending Interest Rate",value:"14.54140833"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.31862417"},
{axis:"Unemployment",value:"11.5"}]
    },
{className:"Hong Kong",
axes: [
{axis:"Inflation",value:"0.613496933"},
{axis:"Deposit Interest Rate",value:"0.010833333"},
{axis:"Lending Interest Rate",value:"5"},
{axis:"Central Government Debt",value:"33.22197616"},
{axis:"GDP",value:"-2.45911375"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"Honduras",
axes: [
{axis:"Inflation",value:"5.492025278"},
{axis:"Deposit Interest Rate",value:"10.81666667"},
{axis:"Lending Interest Rate",value:"19.445"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.43162788"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Croatia",
axes: [
{axis:"Inflation",value:"2.378528459"},
{axis:"Deposit Interest Rate",value:"3.203333333"},
{axis:"Lending Interest Rate",value:"11.55416667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-7.383783"},
{axis:"Unemployment",value:"9.100000381"}]
    },
{className:"Haiti",
axes: [
{axis:"Inflation",value:"-0.014636278"},
{axis:"Deposit Interest Rate",value:"1.131666667"},
{axis:"Lending Interest Rate",value:"17.32916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.083247688"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Hungary",
axes: [
{axis:"Inflation",value:"4.209189843"},
{axis:"Deposit Interest Rate",value:"5.822303704"},
{axis:"Lending Interest Rate",value:"11.03686222"},
{axis:"Central Government Debt",value:"80.98148229"},
{axis:"GDP",value:"-6.55907806"},
{axis:"Unemployment",value:"10"}]
    },
{className:"Indonesia",
axes: [
{axis:"Inflation",value:"4.813524326"},
{axis:"Deposit Interest Rate",value:"9.278333333"},
{axis:"Lending Interest Rate",value:"14.49833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.628871183"},
{axis:"Unemployment",value:"7.900000095"}]
    },
{className:"India",
axes: [
{axis:"Inflation",value:"10.87739112"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"12.1875"},
{axis:"Central Government Debt",value:"54.30595399"},
{axis:"GDP",value:"8.479786622"},
{axis:"Unemployment",value:"3.900000095"}]
    },

{className:"Ireland",
axes: [
{axis:"Inflation",value:"-4.47993767"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"66.97448582"},
{axis:"GDP",value:"-5.63836661"},
{axis:"Unemployment",value:"12"}]
    },
{className:"Iran",
axes: [
{axis:"Inflation",value:"13.50026182"},
{axis:"Deposit Interest Rate",value:"13.14"},
{axis:"Lending Interest Rate",value:"12"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.314710619"},
{axis:"Unemployment",value:"12"}]
    },
{className:"Iraq",
axes: [
{axis:"Inflation",value:"6.873615472"},
{axis:"Deposit Interest Rate",value:"7.819166667"},
{axis:"Lending Interest Rate",value:"15.62833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.379299094"},
{axis:"Unemployment",value:"15.19999981"}]
    },
{className:"Iceland",
axes: [
{axis:"Inflation",value:"12.00581173"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"18.98765872"},
{axis:"Central Government Debt",value:"99.2564791"},
{axis:"GDP",value:"-4.681171587"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Israel",
axes: [
{axis:"Inflation",value:"3.325"},
{axis:"Deposit Interest Rate",value:"1.1067697"},
{axis:"Lending Interest Rate",value:"4.3758469"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.268661904"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Italy",
axes: [
{axis:"Inflation",value:"0.750149177"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"4.756666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.482053957"},
{axis:"Unemployment",value:"7.800000191"}]
    },
{className:"Jamaica",
axes: [
{axis:"Inflation",value:"9.573787278"},
{axis:"Deposit Interest Rate",value:"6.966103684"},
{axis:"Lending Interest Rate",value:"16.4320116"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.425210552"},
{axis:"Unemployment",value:"11.39999962"}]
    },
{className:"Jordan",
axes: [
{axis:"Inflation",value:"-0.678178129"},
{axis:"Deposit Interest Rate",value:"4.944166667"},
{axis:"Lending Interest Rate",value:"9.246666667"},
{axis:"Central Government Debt",value:"61.01055127"},
{axis:"GDP",value:"5.47658105"},
{axis:"Unemployment",value:"12.89999962"}]
    },
{className:"Japan",
axes: [
{axis:"Inflation",value:"-1.346718903"},
{axis:"Deposit Interest Rate",value:"0.434916667"},
{axis:"Lending Interest Rate",value:"1.723333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.526976489"},
{axis:"Unemployment",value:"5"}]
    },
{className:"Kazakhstan",
axes: [
{axis:"Inflation",value:"7.30635449"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.199999999"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"Kenya",
axes: [
{axis:"Inflation",value:"9.234125924"},
{axis:"Deposit Interest Rate",value:"5.96701675"},
{axis:"Lending Interest Rate",value:"14.80454124"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.306939815"},
{axis:"Unemployment",value:"9.399999619"}]
    },
{className:"Kyrgyz Republic",
axes: [
{axis:"Inflation",value:"6.898629424"},
{axis:"Deposit Interest Rate",value:"3.169807069"},
{axis:"Lending Interest Rate",value:"26.35514834"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.8862947"},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"Cambodia",
axes: [
{axis:"Inflation",value:"-0.661307602"},
{axis:"Deposit Interest Rate",value:"1.663333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.086696959"},
{axis:"Unemployment",value:"0.100000001"}]
    },
{className:"St Kitts and Nevis",
axes: [
{axis:"Inflation",value:"2.034306199"},
{axis:"Deposit Interest Rate",value:"4.59065451"},
{axis:"Lending Interest Rate",value:"8.752311613"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.598328101"},
{axis:"Unemployment",value:""}]
    },
{className:"South Korea",
axes: [
{axis:"Inflation",value:"2.757000942"},
{axis:"Deposit Interest Rate",value:"3.4825"},
{axis:"Lending Interest Rate",value:"5.649166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.707518483"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Kosovo",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"3.9776"},
{axis:"Lending Interest Rate",value:"14.0869"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.341665533"},
{axis:"Unemployment",value:""}]
    },
{className:"Kuwait",
axes: [
{axis:"Inflation",value:"4.609595484"},
{axis:"Deposit Interest Rate",value:"2.830541667"},
{axis:"Lending Interest Rate",value:"6.157775"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-7.076102616"},
{axis:"Unemployment",value:"1.600000024"}]
    },
{className:"Latin America and Caribbean (excluding high income)",
axes: [
{axis:"Inflation",value:"2.913358428"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.767408506"},
{axis:"Unemployment",value:"7.422705285"}]
    },
{className:"Lao PDR",
axes: [
{axis:"Inflation",value:"0.035294368"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:"24.775"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.501774913"},
{axis:"Unemployment",value:"1.399999976"}]
    },
{className:"Lebanon",
axes: [
{axis:"Inflation",value:"1.187649453"},
{axis:"Deposit Interest Rate",value:"7.3175"},
{axis:"Lending Interest Rate",value:"9.568333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.30091265"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"Liberia",
axes: [
{axis:"Inflation",value:"7.42755575"},
{axis:"Deposit Interest Rate",value:"4.108333333"},
{axis:"Lending Interest Rate",value:"14.18666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.300099075"},
{axis:"Unemployment",value:"4.599999905"}]
    },
{className:"Libya",
axes: [
{axis:"Inflation",value:"2.459900256"},
{axis:"Deposit Interest Rate",value:"2.5"},
{axis:"Lending Interest Rate",value:"6"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.790141832"},
{axis:"Unemployment",value:"18.60000038"}]
    },
{className:"St Lucia",
axes: [
{axis:"Inflation",value:"-1.672072072"},
{axis:"Deposit Interest Rate",value:"3.251291552"},
{axis:"Lending Interest Rate",value:"10.58201112"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.453633259"},
{axis:"Unemployment",value:""}]
    },
{className:"Latin America and Caribbean",
axes: [
{axis:"Inflation",value:"2.591946734"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.728114166"},
{axis:"Unemployment",value:"7.522937498"}]
    },
{className:"Liechtenstein",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.157481822"},
{axis:"Unemployment",value:""}]
    },
{className:"Sri Lanka",
axes: [
{axis:"Inflation",value:"3.464963221"},
{axis:"Deposit Interest Rate",value:"10.5"},
{axis:"Lending Interest Rate",value:"10.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.538912053"},
{axis:"Unemployment",value:"5.900000095"}]
    },
{className:"Lesotho",
axes: [
{axis:"Inflation",value:"7.379439352"},
{axis:"Deposit Interest Rate",value:"4.85"},
{axis:"Lending Interest Rate",value:"13"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.357932789"},
{axis:"Unemployment",value:"28.5"}]
    },
{className:"Lithuania",
axes: [
{axis:"Inflation",value:"4.436017285"},
{axis:"Deposit Interest Rate",value:"4.81"},
{axis:"Lending Interest Rate",value:"8.393333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-14.81416332"},
{axis:"Unemployment",value:"13.69999981"}]
    },
{className:"Luxembourg",
axes: [
{axis:"Inflation",value:"0.369816243"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"13.23077049"},
{axis:"GDP",value:"-5.376988795"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Latvia",
axes: [
{axis:"Inflation",value:"3.471196455"},
{axis:"Deposit Interest Rate",value:"8.043333333"},
{axis:"Lending Interest Rate",value:"16.23"},
{axis:"Central Government Debt",value:"41.73014371"},
{axis:"GDP",value:"-14.34892637"},
{axis:"Unemployment",value:"17.10000038"}]
    },
{className:"Macau",
axes: [
{axis:"Inflation",value:"1.175862515"},
{axis:"Deposit Interest Rate",value:"0.028546051"},
{axis:"Lending Interest Rate",value:"5.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.321117614"},
{axis:"Unemployment",value:"3.5"}]
    },
{className:"Morocco",
axes: [
{axis:"Inflation",value:"0.994825964"},
{axis:"Deposit Interest Rate",value:"3.809166667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"47.50362928"},
{axis:"GDP",value:"4.243757321"},
{axis:"Unemployment",value:"9.100000381"}]
    },
{className:"Monaco",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Moldova",
axes: [
{axis:"Inflation",value:"-0.058686761"},
{axis:"Deposit Interest Rate",value:"14.9425"},
{axis:"Lending Interest Rate",value:"20.54416667"},
{axis:"Central Government Debt",value:"27.63222644"},
{axis:"GDP",value:"-5.989579853"},
{axis:"Unemployment",value:"6.400000095"}]
    },
{className:"Madagascar",
axes: [
{axis:"Inflation",value:"8.956741087"},
{axis:"Deposit Interest Rate",value:"11.5"},
{axis:"Lending Interest Rate",value:"45"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.013860583"},
{axis:"Unemployment",value:"4.800000191"}]
    },
{className:"Maldives",
axes: [
{axis:"Inflation",value:"3.982836778"},
{axis:"Deposit Interest Rate",value:"6.5"},
{axis:"Lending Interest Rate",value:"13"},
{axis:"Central Government Debt",value:"50.00968949"},
{axis:"GDP",value:"-5.511438552"},
{axis:"Unemployment",value:"12.19999981"}]
    },
{className:"Middle East and North Africa",
axes: [
{axis:"Inflation",value:"3.325"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.578322168"},
{axis:"Unemployment",value:"10.09862993"}]
    },
{className:"Mexico",
axes: [
{axis:"Inflation",value:"5.297357127"},
{axis:"Deposit Interest Rate",value:"2.010833333"},
{axis:"Lending Interest Rate",value:"7.074166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.700338863"},
{axis:"Unemployment",value:"5.199999809"}]
    },

{className:"Middle income",
axes: [
{axis:"Inflation",value:"4.210981814"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.278192212"},
{axis:"Unemployment",value:"5.849120192"}]
    },
{className:"Macedonia",
axes: [
{axis:"Inflation",value:"-0.739633963"},
{axis:"Deposit Interest Rate",value:"7.045846836"},
{axis:"Lending Interest Rate",value:"10.07338086"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.358615842"},
{axis:"Unemployment",value:"32.20000076"}]
    },
{className:"Mali",
axes: [
{axis:"Inflation",value:"2.463751886"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.7464878"},
{axis:"Unemployment",value:"8.5"}]
    },
{className:"Malta",
axes: [
{axis:"Inflation",value:"2.085357332"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"4.470833333"},
{axis:"Central Government Debt",value:"81.93561388"},
{axis:"GDP",value:"-2.8"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Myanmar",
axes: [
{axis:"Inflation",value:"1.472343114"},
{axis:"Deposit Interest Rate",value:"12"},
{axis:"Lending Interest Rate",value:"17"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"3.5"}]
    },
{className:"Montenegro",
axes: [
{axis:"Inflation",value:"3.466723732"},
{axis:"Deposit Interest Rate",value:"3.811666667"},
{axis:"Lending Interest Rate",value:"9.359166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.656917491"},
{axis:"Unemployment",value:"19.10000038"}]
    },
{className:"Mongolia",
axes: [
{axis:"Inflation",value:"6.279232928"},
{axis:"Deposit Interest Rate",value:"13.28211918"},
{axis:"Lending Interest Rate",value:"21.66696335"},
{axis:"Central Government Debt",value:"59.50711514"},
{axis:"GDP",value:"-1.268598941"},
{axis:"Unemployment",value:"5.900000095"}]
    },

{className:"Mozambique",
axes: [
{axis:"Inflation",value:"3.251692719"},
{axis:"Deposit Interest Rate",value:"9.522995982"},
{axis:"Lending Interest Rate",value:"15.67566667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.351461683"},
{axis:"Unemployment",value:"22.60000038"}]
    },
{className:"Mauritania",
axes: [
{axis:"Inflation",value:"2.220920324"},
{axis:"Deposit Interest Rate",value:"8"},
{axis:"Lending Interest Rate",value:"19.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.042081704"},
{axis:"Unemployment",value:"31.10000038"}]
    },
{className:"Mauritius",
axes: [
{axis:"Inflation",value:"2.549811288"},
{axis:"Deposit Interest Rate",value:"8.445833333"},
{axis:"Lending Interest Rate",value:"9.25"},
{axis:"Central Government Debt",value:"37.77375318"},
{axis:"GDP",value:"3.048982486"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"Malawi",
axes: [
{axis:"Inflation",value:"8.422044277"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:"25.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.328110276"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Malaysia",
axes: [
{axis:"Inflation",value:"0.583308406"},
{axis:"Deposit Interest Rate",value:"2.081666667"},
{axis:"Lending Interest Rate",value:"5.084166667"},
{axis:"Central Government Debt",value:"50.83575538"},
{axis:"GDP",value:"-1.51368508"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"North America",
axes: [
{axis:"Inflation",value:"-0.028039732"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"76.31527224"},
{axis:"GDP",value:"-2.793343088"},
{axis:"Unemployment",value:"9.283459476"}]
    },
{className:"Namibia",
axes: [
{axis:"Inflation",value:"9.451726515"},
{axis:"Deposit Interest Rate",value:"6.241666667"},
{axis:"Lending Interest Rate",value:"11.11833333"},
{axis:"Central Government Debt",value:"23.85751574"},
{axis:"GDP",value:"0.295971028"},
{axis:"Unemployment",value:"29.70000076"}]
    },

{className:"Niger",
axes: [
{axis:"Inflation",value:"0.582906591"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.712671174"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Nigeria",
axes: [
{axis:"Inflation",value:"11.53767275"},
{axis:"Deposit Interest Rate",value:"13.29666667"},
{axis:"Lending Interest Rate",value:"18.36166667"},
{axis:"Central Government Debt",value:"15.13073182"},
{axis:"GDP",value:"6.934416004"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Nicaragua",
axes: [
{axis:"Inflation",value:"3.687001605"},
{axis:"Deposit Interest Rate",value:"6.008009698"},
{axis:"Lending Interest Rate",value:"14.04467463"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.759210147"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Netherlands",
axes: [
{axis:"Inflation",value:"1.189904616"},
{axis:"Deposit Interest Rate",value:"2.597516667"},
{axis:"Lending Interest Rate",value:"1.983333333"},
{axis:"Central Government Debt",value:"55.12533355"},
{axis:"GDP",value:"-3.767583537"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"Norway",
axes: [
{axis:"Inflation",value:"2.166847237"},
{axis:"Deposit Interest Rate",value:"2.28"},
{axis:"Lending Interest Rate",value:"4.28"},
{axis:"Central Government Debt",value:"35.26874652"},
{axis:"GDP",value:"-1.622533265"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Nepal",
axes: [
{axis:"Inflation",value:"11.07764508"},
{axis:"Deposit Interest Rate",value:"2.5"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.53307872"},
{axis:"Unemployment",value:"2.700000048"}]
    },
{className:"New Zealand",
axes: [
{axis:"Inflation",value:"2.115655853"},
{axis:"Deposit Interest Rate",value:"4.0398"},
{axis:"Lending Interest Rate",value:"6.656759796"},
{axis:"Central Government Debt",value:"47.18888305"},
{axis:"GDP",value:"-0.537631643"},
{axis:"Unemployment",value:"6.099999905"}]
    },
{className:"Oman",
axes: [
{axis:"Inflation",value:"3.9351759"},
{axis:"Deposit Interest Rate",value:"4.141"},
{axis:"Lending Interest Rate",value:"7.442"},
{axis:"Central Government Debt",value:"5.615604156"},
{axis:"GDP",value:"6.112453761"},
{axis:"Unemployment",value:"7.699999809"}]
    },
{className:"Pakistan",
axes: [
{axis:"Inflation",value:"13.64776506"},
{axis:"Deposit Interest Rate",value:"8.680833333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.831658519"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"Panama",
axes: [
{axis:"Inflation",value:"2.409053041"},
{axis:"Deposit Interest Rate",value:"3.488934597"},
{axis:"Lending Interest Rate",value:"8.247740085"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.598358809"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"Peru",
axes: [
{axis:"Inflation",value:"2.936231536"},
{axis:"Deposit Interest Rate",value:"2.828289167"},
{axis:"Lending Interest Rate",value:"21.04192333"},
{axis:"Central Government Debt",value:"26.32040661"},
{axis:"GDP",value:"1.049232382"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Philippines",
axes: [
{axis:"Inflation",value:"4.219030521"},
{axis:"Deposit Interest Rate",value:"2.741"},
{axis:"Lending Interest Rate",value:"8.566166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.148330408"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Palau",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-9.075535513"},
{axis:"Unemployment",value:""}]
    },
{className:"Papua New Guinea",
axes: [
{axis:"Inflation",value:"6.918325326"},
{axis:"Deposit Interest Rate",value:"2.323333333"},
{axis:"Lending Interest Rate",value:"10.09416667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.14148229"},
{axis:"Unemployment",value:"2.5"}]
    },
{className:"Poland",
axes: [
{axis:"Inflation",value:"3.825977877"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"47.43025857"},
{axis:"GDP",value:"2.634181356"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Puerto Rico",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.361113517"},
{axis:"Unemployment",value:"15.10000038"}]
    },
{className:"Portugal",
axes: [
{axis:"Inflation",value:"-0.835530022"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.978104284"},
{axis:"Unemployment",value:"9.5"}]
    },
{className:"Paraguay",
axes: [
{axis:"Inflation",value:"2.591946734"},
{axis:"Deposit Interest Rate",value:"1.455833333"},
{axis:"Lending Interest Rate",value:"28.25720343"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.965695886"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Qatar",
axes: [
{axis:"Inflation",value:"-4.863278016"},
{axis:"Deposit Interest Rate",value:"4.236666667"},
{axis:"Lending Interest Rate",value:"7.044166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.95656114"},
{axis:"Unemployment",value:"0.300000012"}]
    },
{className:"Romania",
axes: [
{axis:"Inflation",value:"5.587663497"},
{axis:"Deposit Interest Rate",value:"11.98666667"},
{axis:"Lending Interest Rate",value:"17.275"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-7.06682807"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Russian Federation",
axes: [
{axis:"Inflation",value:"11.66972477"},
{axis:"Deposit Interest Rate",value:"8.583333333"},
{axis:"Lending Interest Rate",value:"15.30833333"},
{axis:"Central Government Debt",value:"8.697866233"},
{axis:"GDP",value:"-7.820885027"},
{axis:"Unemployment",value:"8.300000191"}]
    },
{className:"Rwanda",
axes: [
{axis:"Inflation",value:"10.3941857"},
{axis:"Deposit Interest Rate",value:"8.54"},
{axis:"Lending Interest Rate",value:"15.77"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.267988487"},
{axis:"Unemployment",value:"0.600000024"}]
    },
{className:"South Asia",
axes: [
{axis:"Inflation",value:"4.892297276"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.634751001"},
{axis:"Unemployment",value:"4.189908677"}]
    },
{className:"Saudi Arabia",
axes: [
{axis:"Inflation",value:"5.066632331"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.829176099"},
{axis:"Unemployment",value:"5.400000095"}]
    },
{className:"Sudan",
axes: [
{axis:"Inflation",value:"11.24854637"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.241847572"},
{axis:"Unemployment",value:"14.60000038"}]
    },
{className:"Senegal",
axes: [
{axis:"Inflation",value:"-2.248021479"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.423175917"},
{axis:"Unemployment",value:"9.899999619"}]
    },
{className:"Singapore",
axes: [
{axis:"Inflation",value:"0.60362173"},
{axis:"Deposit Interest Rate",value:"0.2925"},
{axis:"Lending Interest Rate",value:"5.38"},
{axis:"Central Government Debt",value:"107.3365778"},
{axis:"GDP",value:"-0.603388298"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Solomon Islands",
axes: [
{axis:"Inflation",value:"7.092717169"},
{axis:"Deposit Interest Rate",value:"4.146666667"},
{axis:"Lending Interest Rate",value:"15.26333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.727872457"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Sierra Leone",
axes: [
{axis:"Inflation",value:"9.252279781"},
{axis:"Deposit Interest Rate",value:"9.7225"},
{axis:"Lending Interest Rate",value:"22.16666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.649512913"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"El Salvador",
axes: [
{axis:"Inflation",value:"1.055950297"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"49.5368091"},
{axis:"GDP",value:"-3.133046282"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"San Marino",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.9625"},
{axis:"Lending Interest Rate",value:"5.7425"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Somalia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Serbia",
axes: [
{axis:"Inflation",value:"8.116950922"},
{axis:"Deposit Interest Rate",value:"5.06"},
{axis:"Lending Interest Rate",value:"11.78"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.115971692"},
{axis:"Unemployment",value:"16.60000038"}]
    },
{className:"Sao Tome and Principe",
axes: [
{axis:"Inflation",value:"16.9574758"},
{axis:"Deposit Interest Rate",value:"11.92083333"},
{axis:"Lending Interest Rate",value:"31.10833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.015820883"},
{axis:"Unemployment",value:""}]
    },
{className:"Suriname",
axes: [
{axis:"Inflation",value:"-0.162987837"},
{axis:"Deposit Interest Rate",value:"6.375"},
{axis:"Lending Interest Rate",value:"11.65"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.01369863"},
{axis:"Unemployment",value:"9"}]
    },
{className:"Slovak Republic",
axes: [
{axis:"Inflation",value:"1.615104641"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"37.63044559"},
{axis:"GDP",value:"-5.491361008"},
{axis:"Unemployment",value:"12.10000038"}]
    },
{className:"Slovenia",
axes: [
{axis:"Inflation",value:"0.855920114"},
{axis:"Deposit Interest Rate",value:"1.404444444"},
{axis:"Lending Interest Rate",value:"5.949166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-7.797360798"},
{axis:"Unemployment",value:"5.900000095"}]
    },
{className:"Sweden",
axes: [
{axis:"Inflation",value:"-0.494460544"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.18465903"},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"Swaziland",
axes: [
{axis:"Inflation",value:"7.448234234"},
{axis:"Deposit Interest Rate",value:"5.403333333"},
{axis:"Lending Interest Rate",value:"11.375"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.250350184"},
{axis:"Unemployment",value:"22.89999962"}]
    },
{className:"Seychelles",
axes: [
{axis:"Inflation",value:"31.75444077"},
{axis:"Deposit Interest Rate",value:"9.767464007"},
{axis:"Lending Interest Rate",value:"15.34725161"},
{axis:"Central Government Debt",value:"100.3426973"},
{axis:"GDP",value:"-1.105245793"},
{axis:"Unemployment",value:""}]
    },
{className:"Syrian Arab Republic",
axes: [
{axis:"Inflation",value:"2.920897118"},
{axis:"Deposit Interest Rate",value:"6.34768317"},
{axis:"Lending Interest Rate",value:"10.00577761"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Chad",
axes: [
{axis:"Inflation",value:"9.952422907"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.217695552"},
{axis:"Unemployment",value:"7"}]
    },
{className:"East Asia and Pacific (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.214695752"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.549292177"},
{axis:"Unemployment",value:"4.623976481"}]
    },
{className:"Europe and Central Asia (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.825977877"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.05185433"},
{axis:"Unemployment",value:"9.542095952"}]
    },
{className:"Togo",
axes: [
{axis:"Inflation",value:"3.313390805"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.510296675"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Thailand",
axes: [
{axis:"Inflation",value:"-0.845716092"},
{axis:"Deposit Interest Rate",value:"1.041666667"},
{axis:"Lending Interest Rate",value:"5.9625"},
{axis:"Central Government Debt",value:"26.7920961"},
{axis:"GDP",value:"-0.738279789"},
{axis:"Unemployment",value:"1.5"}]
    },
{className:"Tajikistan",
axes: [
{axis:"Inflation",value:"6.448234811"},
{axis:"Deposit Interest Rate",value:"7.580630466"},
{axis:"Lending Interest Rate",value:"22.61583333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.800000992"},
{axis:"Unemployment",value:"11.5"}]
    },
{className:"Turkmenistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.100000115"},
{axis:"Unemployment",value:"10.80000019"}]
    },
{className:"Latin America and the Caribbean (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"2.752652581"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.748518749"},
{axis:"Unemployment",value:"7.590302404"}]
    },
{className:"Middle East and North Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.222855461"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.033362882"},
{axis:"Unemployment",value:"11.10727976"}]
    },
{className:"Timor-Leste",
axes: [
{axis:"Inflation",value:"0.669681186"},
{axis:"Deposit Interest Rate",value:"0.830792132"},
{axis:"Lending Interest Rate",value:"11.16530138"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"12.96296296"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"Tonga",
axes: [
{axis:"Inflation",value:"1.419647927"},
{axis:"Deposit Interest Rate",value:"5.258888889"},
{axis:"Lending Interest Rate",value:"12.46618846"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.099573953"},
{axis:"Unemployment",value:""}]
    },
{className:"South Asia (IDA and IBRD)",
axes: [
{axis:"Inflation",value:"4.892297276"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.634751001"},
{axis:"Unemployment",value:"4.189908677"}]
    },
{className:"Sub-Saharan Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"7.13"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.844088332"},
{axis:"Unemployment",value:"8.099240621"}]
    },
{className:"Trinidad and Tobago",
axes: [
{axis:"Inflation",value:"6.971370604"},
{axis:"Deposit Interest Rate",value:"3.418333333"},
{axis:"Lending Interest Rate",value:"11.9375"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.390592479"},
{axis:"Unemployment",value:"5.300000191"}]
    },
{className:"Tunisia",
axes: [
{axis:"Inflation",value:"3.524813804"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"42.92979215"},
{axis:"GDP",value:"3.043448955"},
{axis:"Unemployment",value:"13.30000019"}]
    },
{className:"Turkey",
axes: [
{axis:"Inflation",value:"6.250976631"},
{axis:"Deposit Interest Rate",value:"17.64916667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"52.94404205"},
{axis:"GDP",value:"-4.825875699"},
{axis:"Unemployment",value:"14"}]
    },
{className:"Tuvalu",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.432851394"},
{axis:"Unemployment",value:""}]
    },
{className:"Tanzania",
axes: [
{axis:"Inflation",value:"12.14222787"},
{axis:"Deposit Interest Rate",value:"7.971802261"},
{axis:"Lending Interest Rate",value:"15.03048182"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.382346168"},
{axis:"Unemployment",value:"2.5"}]
    },
{className:"Uganda",
axes: [
{axis:"Inflation",value:"13.01725619"},
{axis:"Deposit Interest Rate",value:"9.752509389"},
{axis:"Lending Interest Rate",value:"20.95516578"},
{axis:"Central Government Debt",value:"28.9163956"},
{axis:"GDP",value:"7.251045316"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Ukraine",
axes: [
{axis:"Inflation",value:"15.89456869"},
{axis:"Deposit Interest Rate",value:"13.76086667"},
{axis:"Lending Interest Rate",value:"20.86333333"},
{axis:"Central Government Debt",value:"24.87512386"},
{axis:"GDP",value:"-14.80000001"},
{axis:"Unemployment",value:"8.800000191"}]
    },
{className:"Uruguay",
axes: [
{axis:"Inflation",value:"7.099167396"},
{axis:"Deposit Interest Rate",value:"4.400583737"},
{axis:"Lending Interest Rate",value:"15.28484239"},
{axis:"Central Government Debt",value:"49.27332921"},
{axis:"GDP",value:"4.243494195"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"United States",
axes: [
{axis:"Inflation",value:"-0.355546266"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"3.25"},
{axis:"Central Government Debt",value:"76.31527224"},
{axis:"GDP",value:"-2.775529574"},
{axis:"Unemployment",value:"9.399999619"}]
    },
{className:"Uzbekistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.1"},
{axis:"Unemployment",value:"11"}]
    },
{className:"St Vincent and the Grenadines",
axes: [
{axis:"Inflation",value:"0.421539126"},
{axis:"Deposit Interest Rate",value:"2.93935814"},
{axis:"Lending Interest Rate",value:"9.186560754"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.099061259"},
{axis:"Unemployment",value:""}]
    },
{className:"Venezuela",
axes: [
{axis:"Inflation",value:"27.08094145"},
{axis:"Deposit Interest Rate",value:"16.40916667"},
{axis:"Lending Interest Rate",value:"19.89333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.202302657"},
{axis:"Unemployment",value:"7.800000191"}]
    },
{className:"Vietnam",
axes: [
{axis:"Inflation",value:"7.054558499"},
{axis:"Deposit Interest Rate",value:"7.91"},
{axis:"Lending Interest Rate",value:"10.069"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.397897543"},
{axis:"Unemployment",value:"2.599999905"}]
    },
{className:"Vanuatu",
axes: [
{axis:"Inflation",value:"4.250500962"},
{axis:"Deposit Interest Rate",value:"1.25"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.312815802"},
{axis:"Unemployment",value:""}]
    },
{className:"West Bank and Gaza",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.4"},
{axis:"Lending Interest Rate",value:"6.19"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"20.94078783"},
{axis:"Unemployment",value:"24.5"}]
    },
{className:"World",
axes: [
{axis:"Inflation",value:"3.043618479"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.71811506"},
{axis:"Unemployment",value:"6.254371599"}]
    },
{className:"Samoa",
axes: [
{axis:"Inflation",value:"6.324953362"},
{axis:"Deposit Interest Rate",value:"4.805833333"},
{axis:"Lending Interest Rate",value:"12.0825"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.8082722"},
{axis:"Unemployment",value:""}]
    },
{className:"Yemen",
axes: [
{axis:"Inflation",value:"5.407760981"},
{axis:"Deposit Interest Rate",value:"10.66666667"},
{axis:"Lending Interest Rate",value:"18"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.134837953"},
{axis:"Unemployment",value:"14.60000038"}]
    },
{className:"South Africa",
axes: [
{axis:"Inflation",value:"7.13"},
{axis:"Deposit Interest Rate",value:"8.536666667"},
{axis:"Lending Interest Rate",value:"11.70833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.538089135"},
{axis:"Unemployment",value:"23.70000076"}]
    },
{className:"Republic o",
axes: [
{axis:"Inflation",value:"2.8"},
{axis:"Deposit Interest Rate",value:"16.075"},
{axis:"Lending Interest Rate",value:"65.4175"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.855060107"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Zambia",
axes: [
{axis:"Inflation",value:"13.39525463"},
{axis:"Deposit Interest Rate",value:"7.090128205"},
{axis:"Lending Interest Rate",value:"22.06312207"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.220348444"},
{axis:"Unemployment",value:"14.80000019"}]
    },
{className:"Zimbabwe",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.984390754"},
{axis:"Unemployment",value:"6.400000095"}]
    }
],
["2010",
{className:"Aruba",
axes: [
{axis:"Inflation",value:"2.07773902"},
{axis:"Deposit Interest Rate",value:"2.575"},
{axis:"Lending Interest Rate",value:"10.65"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Andorra",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.347977181"},
{axis:"Unemployment",value:""}]
    },
{className:"Afghanistan",
axes: [
{axis:"Inflation",value:"0.892536936"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"15.69"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.433290482"},
{axis:"Unemployment",value:"8.699999809"}]
    },
{className:"Angola",
axes: [
{axis:"Inflation",value:"14.4705412"},
{axis:"Deposit Interest Rate",value:"12.75629919"},
{axis:"Lending Interest Rate",value:"22.54357202"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.407654794"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Albania",
axes: [
{axis:"Inflation",value:"3.552267388"},
{axis:"Deposit Interest Rate",value:"6.417543373"},
{axis:"Lending Interest Rate",value:"12.82232989"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.709999994"},
{axis:"Unemployment",value:"14.19999981"}]
    },
{className:"United Arab Emirates",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.635449055"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Argentina",
axes: [
{axis:"Inflation",value:"10.78011543"},
{axis:"Deposit Interest Rate",value:"9.166842067"},
{axis:"Lending Interest Rate",value:"10.5575"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.35356745"},
{axis:"Unemployment",value:"7.699999809"}]
    },
{className:"Armenia",
axes: [
{axis:"Inflation",value:"8.181575544"},
{axis:"Deposit Interest Rate",value:"8.950258925"},
{axis:"Lending Interest Rate",value:"19.20042831"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.199999999"},
{axis:"Unemployment",value:"19"}]
    },
{className:"Antigua and Barbuda",
axes: [
{axis:"Inflation",value:"3.370025402"},
{axis:"Deposit Interest Rate",value:"3.370306872"},
{axis:"Lending Interest Rate",value:"10.99934751"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-7.142991335"},
{axis:"Unemployment",value:""}]
    },
{className:"Australia",
axes: [
{axis:"Inflation",value:"2.845225682"},
{axis:"Deposit Interest Rate",value:"4.2125"},
{axis:"Lending Interest Rate",value:"7.279166667"},
{axis:"Central Government Debt",value:"29.2400245"},
{axis:"GDP",value:"2.018182144"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"Austria",
axes: [
{axis:"Inflation",value:"1.813535031"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"79.40830371"},
{axis:"GDP",value:"1.928673056"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Azerbaijan",
axes: [
{axis:"Inflation",value:"5.667923129"},
{axis:"Deposit Interest Rate",value:"11.64"},
{axis:"Lending Interest Rate",value:"20.7"},
{axis:"Central Government Debt",value:"6.385575792"},
{axis:"GDP",value:"4.854339324"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Burundi",
axes: [
{axis:"Inflation",value:"6.401249024"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"12.42"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.785902543"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Belgium",
axes: [
{axis:"Inflation",value:"2.189299204"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"92.31364265"},
{axis:"GDP",value:"2.694825538"},
{axis:"Unemployment",value:"8.300000191"}]
    },
{className:"Benin",
axes: [
{axis:"Inflation",value:"2.307356822"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.116850127"},
{axis:"Unemployment",value:"1"}]
    },
{className:"Burkina Faso",
axes: [
{axis:"Inflation",value:"-0.764230735"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.446325183"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Bangladesh",
axes: [
{axis:"Inflation",value:"8.126676392"},
{axis:"Deposit Interest Rate",value:"7.210833333"},
{axis:"Lending Interest Rate",value:"12.21916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.571802274"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Bulgaria",
axes: [
{axis:"Inflation",value:"2.438990605"},
{axis:"Deposit Interest Rate",value:"4.076075"},
{axis:"Lending Interest Rate",value:"11.14436667"},
{axis:"Central Government Debt",value:"14.27699525"},
{axis:"GDP",value:"0.054557983"},
{axis:"Unemployment",value:"10.19999981"}]
    },
{className:"Bahrain",
axes: [
{axis:"Inflation",value:"1.961884683"},
{axis:"Deposit Interest Rate",value:"1.225"},
{axis:"Lending Interest Rate",value:"7.2475"},
{axis:"Central Government Debt",value:"30.30678959"},
{axis:"GDP",value:"4.334407088"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"The Bahamas",
axes: [
{axis:"Inflation",value:"1.344027384"},
{axis:"Deposit Interest Rate",value:"3.440833333"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.538778853"},
{axis:"Unemployment",value:"14.69999981"}]
    },
{className:"Bosnia and Herzegovina",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"3.159166667"},
{axis:"Lending Interest Rate",value:"7.888333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.767254045"},
{axis:"Unemployment",value:"27.20000076"}]
    },
{className:"Belarus",
axes: [
{axis:"Inflation",value:"7.735748043"},
{axis:"Deposit Interest Rate",value:"9.091666667"},
{axis:"Lending Interest Rate",value:"9.216666667"},
{axis:"Central Government Debt",value:"19.59371506"},
{axis:"GDP",value:"7.740781216"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"Belize",
axes: [
{axis:"Inflation",value:"5.576823837"},
{axis:"Deposit Interest Rate",value:"7.760833333"},
{axis:"Lending Interest Rate",value:"13.88333333"},
{axis:"Central Government Debt",value:"80.16789903"},
{axis:"GDP",value:"3.321036866"},
{axis:"Unemployment",value:"10.80000019"}]
    },
{className:"Bermuda",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.094113534"},
{axis:"Unemployment",value:""}]
    },
{className:"Bolivia",
axes: [
{axis:"Inflation",value:"2.501767027"},
{axis:"Deposit Interest Rate",value:"1.046668515"},
{axis:"Lending Interest Rate",value:"9.909927149"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.126722565"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Brazil",
axes: [
{axis:"Inflation",value:"5.038316946"},
{axis:"Deposit Interest Rate",value:"8.870439317"},
{axis:"Lending Interest Rate",value:"39.99166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.528797381"},
{axis:"Unemployment",value:"7.900000095"}]
    },
{className:"Barbados",
axes: [
{axis:"Inflation",value:"5.824218533"},
{axis:"Deposit Interest Rate",value:"2.665833333"},
{axis:"Lending Interest Rate",value:"8.7"},
{axis:"Central Government Debt",value:"97.54417577"},
{axis:"GDP",value:"0.273972603"},
{axis:"Unemployment",value:"10.80000019"}]
    },
{className:"Brunei Darussalam",
axes: [
{axis:"Inflation",value:"0.356869132"},
{axis:"Deposit Interest Rate",value:"0.47054075"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.598965911"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Bhutan",
axes: [
{axis:"Inflation",value:"7.036383161"},
{axis:"Deposit Interest Rate",value:"2"},
{axis:"Lending Interest Rate",value:"14"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.73085436"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Botswana",
axes: [
{axis:"Inflation",value:"6.948876587"},
{axis:"Deposit Interest Rate",value:"5.597883333"},
{axis:"Lending Interest Rate",value:"11.45833333"},
{axis:"Central Government Debt",value:"21.63044533"},
{axis:"GDP",value:"8.563631748"},
{axis:"Unemployment",value:"17.89999962"}]
    },
{className:"Central African Republic",
axes: [
{axis:"Inflation",value:"1.493233784"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.046656852"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Canada",
axes: [
{axis:"Inflation",value:"1.776871541"},
{axis:"Deposit Interest Rate",value:"0.2"},
{axis:"Lending Interest Rate",value:"2.604166667"},
{axis:"Central Government Debt",value:"51.31177988"},
{axis:"GDP",value:"3.08351422"},
{axis:"Unemployment",value:"8"}]
    },
{className:"Central Europe and the Baltics",
axes: [
{axis:"Inflation",value:"1.840965347"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"40.63814613"},
{axis:"GDP",value:"1.973125806"},
{axis:"Unemployment",value:"9.944501737"}]
    },
{className:"Switzerland",
axes: [
{axis:"Inflation",value:"0.698510114"},
{axis:"Deposit Interest Rate",value:"0.08"},
{axis:"Lending Interest Rate",value:"2.733333333"},
{axis:"Central Government Debt",value:"23.72830694"},
{axis:"GDP",value:"2.953816768"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Chile",
axes: [
{axis:"Inflation",value:"1.409964751"},
{axis:"Deposit Interest Rate",value:"1.751187382"},
{axis:"Lending Interest Rate",value:"4.754826805"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.753708909"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"China",
axes: [
{axis:"Inflation",value:"3.314545929"},
{axis:"Deposit Interest Rate",value:"2.75"},
{axis:"Lending Interest Rate",value:"5.81"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.63170823"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Cote dIvoire",
axes: [
{axis:"Inflation",value:"1.226456121"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.017638592"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Cameroon",
axes: [
{axis:"Inflation",value:"1.275380462"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.268648874"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Republic of Congo",
axes: [
{axis:"Inflation",value:"4.998504884"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.751655799"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Colombia",
axes: [
{axis:"Inflation",value:"2.278220158"},
{axis:"Deposit Interest Rate",value:"3.66186033"},
{axis:"Lending Interest Rate",value:"9.381489937"},
{axis:"Central Government Debt",value:"72.33779261"},
{axis:"GDP",value:"3.971800705"},
{axis:"Unemployment",value:"12"}]
    },
{className:"Comoros",
axes: [
{axis:"Inflation",value:"3.354757703"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"10.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.199999982"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Cabo Verde",
axes: [
{axis:"Inflation",value:"2.078664709"},
{axis:"Deposit Interest Rate",value:"3.114278881"},
{axis:"Lending Interest Rate",value:"11.03989876"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.466912709"},
{axis:"Unemployment",value:"9.300000191"}]
    },
{className:"Costa Rica",
axes: [
{axis:"Inflation",value:"5.660230651"},
{axis:"Deposit Interest Rate",value:"5.323333333"},
{axis:"Lending Interest Rate",value:"17.09083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.954320527"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"Caribbean small states",
axes: [
{axis:"Inflation",value:"3.370025402"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.185160332"},
{axis:"Unemployment",value:"10.46228902"}]
    },
{className:"Cuba",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.388332912"},
{axis:"Unemployment",value:"2.5"}]
    },
{className:"Cyprus",
axes: [
{axis:"Inflation",value:"2.381258363"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"93.83862091"},
{axis:"GDP",value:"1.364184191"},
{axis:"Unemployment",value:"6.300000191"}]
    },
{className:"Czech Republic",
axes: [
{axis:"Inflation",value:"1.408717924"},
{axis:"Deposit Interest Rate",value:"1.081583333"},
{axis:"Lending Interest Rate",value:"5.887833333"},
{axis:"Central Government Debt",value:"33.556452"},
{axis:"GDP",value:"2.295089687"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"Germany",
axes: [
{axis:"Inflation",value:"1.103808561"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"53.84797253"},
{axis:"GDP",value:"4.079933305"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Djibouti",
axes: [
{axis:"Inflation",value:"3.950078759"},
{axis:"Deposit Interest Rate",value:"1.718277778"},
{axis:"Lending Interest Rate",value:"10.443"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.486917489"},
{axis:"Unemployment",value:""}]
    },
{className:"Dominica",
axes: [
{axis:"Inflation",value:"3.20744344"},
{axis:"Deposit Interest Rate",value:"3.260465021"},
{axis:"Lending Interest Rate",value:"9.455013989"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.674536256"},
{axis:"Unemployment",value:""}]
    },
{className:"Denmark",
axes: [
{axis:"Inflation",value:"2.297730121"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"43.03151977"},
{axis:"GDP",value:"1.625132918"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Dominican Republic",
axes: [
{axis:"Inflation",value:"6.329932201"},
{axis:"Deposit Interest Rate",value:"4.855833333"},
{axis:"Lending Interest Rate",value:"12.13666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.302152802"},
{axis:"Unemployment",value:"12.39999962"}]
    },
{className:"Algeria",
axes: [
{axis:"Inflation",value:"3.913043478"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.6"},
{axis:"Unemployment",value:"10"}]
    },
{className:"East Asia and Pacific (excluding high income)",
axes: [
{axis:"Inflation",value:"3.789836348"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.772136875"},
{axis:"Unemployment",value:"4.365480023"}]
    },
{className:"East Asia and Pacific",
axes: [
{axis:"Inflation",value:"3.272220008"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.265423023"},
{axis:"Unemployment",value:"4.39523548"}]
    },
{className:"Europe and Central Asia (excluding high income)",
axes: [
{axis:"Inflation",value:"6.835359842"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.371778751"},
{axis:"Unemployment",value:"9.040442145"}]
    },
{className:"Europe and Central Asia",
axes: [
{axis:"Inflation",value:"2.381258363"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"46.81079637"},
{axis:"GDP",value:"2.568246402"},
{axis:"Unemployment",value:"9.329338247"}]
    },
{className:"Ecuador",
axes: [
{axis:"Inflation",value:"3.556123806"},
{axis:"Deposit Interest Rate",value:"3.9025"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.525298669"},
{axis:"Unemployment",value:"5"}]
    },
{className:"Egypt",
axes: [
{axis:"Inflation",value:"11.26518827"},
{axis:"Deposit Interest Rate",value:"6.233333332"},
{axis:"Lending Interest Rate",value:"11.00833325"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.139126087"},
{axis:"Unemployment",value:"9"}]
    },
{className:"Eritrea",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.194190545"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"Spain",
axes: [
{axis:"Inflation",value:"1.799740168"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"53.61449071"},
{axis:"GDP",value:"0.013786544"},
{axis:"Unemployment",value:"20.20000076"}]
    },
{className:"Estonia",
axes: [
{axis:"Inflation",value:"2.975580329"},
{axis:"Deposit Interest Rate",value:"1.10602655"},
{axis:"Lending Interest Rate",value:"7.760177765"},
{axis:"Central Government Debt",value:"0.519205856"},
{axis:"GDP",value:"2.462773326"},
{axis:"Unemployment",value:"16.89999962"}]
    },
{className:"Ethiopia",
axes: [
{axis:"Inflation",value:"8.136941131"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"12.55053834"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"European Union",
axes: [
{axis:"Inflation",value:"1.66981678"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"53.73123162"},
{axis:"GDP",value:"2.079835338"},
{axis:"Unemployment",value:"9.635087014"}]
    },
{className:"Finland",
axes: [
{axis:"Inflation",value:"1.210357625"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"46.81079637"},
{axis:"GDP",value:"2.992337502"},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"Fiji",
axes: [
{axis:"Inflation",value:"3.680014831"},
{axis:"Deposit Interest Rate",value:"5.414825028"},
{axis:"Lending Interest Rate",value:"7.489647346"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.954673156"},
{axis:"Unemployment",value:"8.5"}]
    },
{className:"France",
axes: [
{axis:"Inflation",value:"1.529639382"},
{axis:"Deposit Interest Rate",value:"1.458333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"76.27848351"},
{axis:"GDP",value:"1.965657375"},
{axis:"Unemployment",value:"9.300000191"}]
    },
{className:"Federal States of Micronesia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.910833333"},
{axis:"Lending Interest Rate",value:"15.13"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.530578819"},
{axis:"Unemployment",value:""}]
    },
{className:"Gabon",
axes: [
{axis:"Inflation",value:"1.461544027"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.089887315"},
{axis:"Unemployment",value:"20.39999962"}]
    },
{className:"United Kingdom",
axes: [
{axis:"Inflation",value:"3.285714286"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"0.5"},
{axis:"Central Government Debt",value:"84.19476609"},
{axis:"GDP",value:"1.54017665"},
{axis:"Unemployment",value:"7.900000095"}]
    },
{className:"Georgia",
axes: [
{axis:"Inflation",value:"7.110178975"},
{axis:"Deposit Interest Rate",value:"10.06215155"},
{axis:"Lending Interest Rate",value:"15.845075"},
{axis:"Central Government Debt",value:"36.79972009"},
{axis:"GDP",value:"6.253028626"},
{axis:"Unemployment",value:"16.29999924"}]
    },
{className:"Ghana",
axes: [
{axis:"Inflation",value:"10.70756812"},
{axis:"Deposit Interest Rate",value:"12.87833333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.899740293"},
{axis:"Unemployment",value:"5.300000191"}]
    },
{className:"Guinea",
axes: [
{axis:"Inflation",value:"15.46198107"},
{axis:"Deposit Interest Rate",value:"17.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.936217423"},
{axis:"Unemployment",value:"1.600000024"}]
    },
{className:"Gambia",
axes: [
{axis:"Inflation",value:"5.048936576"},
{axis:"Deposit Interest Rate",value:"14.625"},
{axis:"Lending Interest Rate",value:"27"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.524632607"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Guinea-Bissau",
axes: [
{axis:"Inflation",value:"2.517851402"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.432021672"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Equatorial Guinea",
axes: [
{axis:"Inflation",value:"7.78916548"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.825021882"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Greece",
axes: [
{axis:"Inflation",value:"4.712981576"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"132.4187425"},
{axis:"GDP",value:"-5.479037108"},
{axis:"Unemployment",value:"12.5"}]
    },
{className:"Grenada",
axes: [
{axis:"Inflation",value:"3.436509059"},
{axis:"Deposit Interest Rate",value:"3.079152915"},
{axis:"Lending Interest Rate",value:"10.57501309"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.511266454"},
{axis:"Unemployment",value:""}]
    },
{className:"Greenland",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Guatemala",
axes: [
{axis:"Inflation",value:"3.859509098"},
{axis:"Deposit Interest Rate",value:"5.4525"},
{axis:"Lending Interest Rate",value:"13.34166667"},
{axis:"Central Government Debt",value:"24.41978694"},
{axis:"GDP",value:"2.869487737"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Guyana",
axes: [
{axis:"Inflation",value:"2.086666667"},
{axis:"Deposit Interest Rate",value:"2.268083333"},
{axis:"Lending Interest Rate",value:"14.5417"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.370869417"},
{axis:"Unemployment",value:"11.30000019"}]
    },
{className:"Hong Kong",
axes: [
{axis:"Inflation",value:"2.337398374"},
{axis:"Deposit Interest Rate",value:"0.01"},
{axis:"Lending Interest Rate",value:"5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.767610559"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Honduras",
axes: [
{axis:"Inflation",value:"4.700549929"},
{axis:"Deposit Interest Rate",value:"9.813689167"},
{axis:"Lending Interest Rate",value:"18.86466417"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.731140344"},
{axis:"Unemployment",value:"4.800000191"}]
    },
{className:"Croatia",
axes: [
{axis:"Inflation",value:"1.030555053"},
{axis:"Deposit Interest Rate",value:"1.7575"},
{axis:"Lending Interest Rate",value:"10.37666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.701249763"},
{axis:"Unemployment",value:"11.80000019"}]
    },
{className:"Haiti",
axes: [
{axis:"Inflation",value:"5.696511023"},
{axis:"Deposit Interest Rate",value:"0.735833333"},
{axis:"Lending Interest Rate",value:"17.48166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.497792337"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Hungary",
axes: [
{axis:"Inflation",value:"4.881345076"},
{axis:"Deposit Interest Rate",value:"4.917692681"},
{axis:"Lending Interest Rate",value:"7.586925113"},
{axis:"Central Government Debt",value:"81.65024779"},
{axis:"GDP",value:"0.743197936"},
{axis:"Unemployment",value:"11.19999981"}]
    },
{className:"Indonesia",
axes: [
{axis:"Inflation",value:"5.1327549"},
{axis:"Deposit Interest Rate",value:"7.016666667"},
{axis:"Lending Interest Rate",value:"13.25166667"},
{axis:"Central Government Debt",value:"26.16613305"},
{axis:"GDP",value:"6.223854181"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"India",
axes: [
{axis:"Inflation",value:"11.99229692"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"8.33335"},
{axis:"Central Government Debt",value:"50.60012925"},
{axis:"GDP",value:"10.25996299"},
{axis:"Unemployment",value:"3.5"}]
    },

{className:"Ireland",
axes: [
{axis:"Inflation",value:"-0.946166395"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"83.68026006"},
{axis:"GDP",value:"0.398613832"},
{axis:"Unemployment",value:"13.89999962"}]
    },
{className:"Iran",
axes: [
{axis:"Inflation",value:"10.13714717"},
{axis:"Deposit Interest Rate",value:"11.94"},
{axis:"Lending Interest Rate",value:"12"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.577374352"},
{axis:"Unemployment",value:"13.5"}]
    },
{className:"Iraq",
axes: [
{axis:"Inflation",value:"2.877747253"},
{axis:"Deposit Interest Rate",value:"6.0575"},
{axis:"Lending Interest Rate",value:"13.32583333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.402564845"},
{axis:"Unemployment",value:"15.19999981"}]
    },
{className:"Iceland",
axes: [
{axis:"Inflation",value:"5.393595958"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"10.2570287"},
{axis:"Central Government Debt",value:"104.6941383"},
{axis:"GDP",value:"-3.588668391"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Israel",
axes: [
{axis:"Inflation",value:"2.69295911"},
{axis:"Deposit Interest Rate",value:"1.8509347"},
{axis:"Lending Interest Rate",value:"5.2510299"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.517022935"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"Italy",
axes: [
{axis:"Inflation",value:"1.539893392"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"4.031666667"},
{axis:"Central Government Debt",value:"114.6817294"},
{axis:"GDP",value:"1.686523279"},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"Jamaica",
axes: [
{axis:"Inflation",value:"12.60950824"},
{axis:"Deposit Interest Rate",value:"6.347642183"},
{axis:"Lending Interest Rate",value:"20.4544536"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.488944185"},
{axis:"Unemployment",value:"12.39999962"}]
    },
{className:"Jordan",
axes: [
{axis:"Inflation",value:"5.013941643"},
{axis:"Deposit Interest Rate",value:"3.5275"},
{axis:"Lending Interest Rate",value:"9.024166667"},
{axis:"Central Government Debt",value:"61.37345749"},
{axis:"GDP",value:"2.336830301"},
{axis:"Unemployment",value:"12.5"}]
    },
{className:"Japan",
axes: [
{axis:"Inflation",value:"-0.719781584"},
{axis:"Deposit Interest Rate",value:"0.500083333"},
{axis:"Lending Interest Rate",value:"1.598333333"},
{axis:"Central Government Debt",value:"174.6449851"},
{axis:"GDP",value:"4.711386136"},
{axis:"Unemployment",value:"5"}]
    },
{className:"Kazakhstan",
axes: [
{axis:"Inflation",value:"7.115813597"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.3"},
{axis:"Unemployment",value:"5.800000191"}]
    },
{className:"Kenya",
axes: [
{axis:"Inflation",value:"3.961388891"},
{axis:"Deposit Interest Rate",value:"4.557366667"},
{axis:"Lending Interest Rate",value:"14.3715"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.402277064"},
{axis:"Unemployment",value:"9.300000191"}]
    },
{className:"Kyrgyz Republic",
axes: [
{axis:"Inflation",value:"7.967722256"},
{axis:"Deposit Interest Rate",value:"2.00449594"},
{axis:"Lending Interest Rate",value:"23.10862148"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.471566848"},
{axis:"Unemployment",value:"8.600000381"}]
    },
{className:"Cambodia",
axes: [
{axis:"Inflation",value:"3.99623008"},
{axis:"Deposit Interest Rate",value:"1.264591667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.963078575"},
{axis:"Unemployment",value:"0.400000006"}]
    },
{className:"St Kitts and Nevis",
axes: [
{axis:"Inflation",value:"0.50550031"},
{axis:"Deposit Interest Rate",value:"4.593379404"},
{axis:"Lending Interest Rate",value:"8.61681004"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.227010925"},
{axis:"Unemployment",value:""}]
    },
{className:"South Korea",
axes: [
{axis:"Inflation",value:"2.955862822"},
{axis:"Deposit Interest Rate",value:"3.856666667"},
{axis:"Lending Interest Rate",value:"5.511666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.496785169"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Kosovo",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"3.379339085"},
{axis:"Lending Interest Rate",value:"13.97"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.309574839"},
{axis:"Unemployment",value:""}]
    },
{className:"Kuwait",
axes: [
{axis:"Inflation",value:"4.496402878"},
{axis:"Deposit Interest Rate",value:"2.336733333"},
{axis:"Lending Interest Rate",value:"4.911641667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.367061944"},
{axis:"Unemployment",value:"1.799999952"}]
    },
{className:"Latin America and Caribbean (excluding high income)",
axes: [
{axis:"Inflation",value:"4.156727837"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.996628054"},
{axis:"Unemployment",value:"7.205331222"}]
    },
{className:"Lao PDR",
axes: [
{axis:"Inflation",value:"5.982317351"},
{axis:"Deposit Interest Rate",value:"3"},
{axis:"Lending Interest Rate",value:"22.6125"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.526905517"},
{axis:"Unemployment",value:"1.399999976"}]
    },
{className:"Lebanon",
axes: [
{axis:"Inflation",value:"3.989841464"},
{axis:"Deposit Interest Rate",value:"6.1975"},
{axis:"Lending Interest Rate",value:"8.336666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.996086279"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"Liberia",
axes: [
{axis:"Inflation",value:"7.291036635"},
{axis:"Deposit Interest Rate",value:"3.541666667"},
{axis:"Lending Interest Rate",value:"14.2425"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.099944692"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Libya",
axes: [
{axis:"Inflation",value:"2.799895001"},
{axis:"Deposit Interest Rate",value:"2.5"},
{axis:"Lending Interest Rate",value:"6"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.021289739"},
{axis:"Unemployment",value:"18.5"}]
    },
{className:"St Lucia",
axes: [
{axis:"Inflation",value:"3.250344092"},
{axis:"Deposit Interest Rate",value:"3.323950586"},
{axis:"Lending Interest Rate",value:"10.61653886"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.716769987"},
{axis:"Unemployment",value:""}]
    },
{className:"Latin America and Caribbean",
axes: [
{axis:"Inflation",value:"3.859509098"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.785136279"},
{axis:"Unemployment",value:"7.27585528"}]
    },
{className:"Liechtenstein",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Sri Lanka",
axes: [
{axis:"Inflation",value:"6.217648893"},
{axis:"Deposit Interest Rate",value:"9.5"},
{axis:"Lending Interest Rate",value:"9.5"},
{axis:"Central Government Debt",value:"71.58532372"},
{axis:"GDP",value:"8.015959407"},
{axis:"Unemployment",value:"4.900000095"}]
    },
{className:"Lesotho",
axes: [
{axis:"Inflation",value:"3.597811021"},
{axis:"Deposit Interest Rate",value:"3.683333333"},
{axis:"Lending Interest Rate",value:"11.2225"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.891144168"},
{axis:"Unemployment",value:"28.29999924"}]
    },
{className:"Lithuania",
axes: [
{axis:"Inflation",value:"1.334234082"},
{axis:"Deposit Interest Rate",value:"1.71"},
{axis:"Lending Interest Rate",value:"5.989166667"},
{axis:"Central Government Debt",value:"40.63814613"},
{axis:"GDP",value:"1.639819649"},
{axis:"Unemployment",value:"17.79999924"}]
    },
{className:"Luxembourg",
axes: [
{axis:"Inflation",value:"2.273404833"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"18.1877015"},
{axis:"GDP",value:"5.676656248"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Latvia",
axes: [
{axis:"Inflation",value:"-1.070663812"},
{axis:"Deposit Interest Rate",value:"1.865"},
{axis:"Lending Interest Rate",value:"9.558333333"},
{axis:"Central Government Debt",value:"50.43995596"},
{axis:"GDP",value:"-3.78028072"},
{axis:"Unemployment",value:"18.70000076"}]
    },
{className:"Macau",
axes: [
{axis:"Inflation",value:"2.809706258"},
{axis:"Deposit Interest Rate",value:"0.017564605"},
{axis:"Lending Interest Rate",value:"5.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"25.26386197"},
{axis:"Unemployment",value:"2.799999952"}]
    },
{className:"Morocco",
axes: [
{axis:"Inflation",value:"0.987355331"},
{axis:"Deposit Interest Rate",value:"3.694166667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"50.96249924"},
{axis:"GDP",value:"3.815717917"},
{axis:"Unemployment",value:"9.100000381"}]
    },
{className:"Monaco",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Moldova",
axes: [
{axis:"Inflation",value:"7.352251206"},
{axis:"Deposit Interest Rate",value:"7.669166667"},
{axis:"Lending Interest Rate",value:"16.36"},
{axis:"Central Government Debt",value:"26.32298147"},
{axis:"GDP",value:"7.094071762"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Madagascar",
axes: [
{axis:"Inflation",value:"9.246717346"},
{axis:"Deposit Interest Rate",value:"10.5"},
{axis:"Lending Interest Rate",value:"49"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.263110856"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Maldives",
axes: [
{axis:"Inflation",value:"6.609167484"},
{axis:"Deposit Interest Rate",value:"4.049425"},
{axis:"Lending Interest Rate",value:"10.37605"},
{axis:"Central Government Debt",value:"61.14014699"},
{axis:"GDP",value:"5.96267316"},
{axis:"Unemployment",value:"11.69999981"}]
    },
{className:"Middle East and North Africa",
axes: [
{axis:"Inflation",value:"3.950078759"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.0588554"},
{axis:"Unemployment",value:"10.38387727"}]
    },
{className:"Mexico",
axes: [
{axis:"Inflation",value:"4.156727837"},
{axis:"Deposit Interest Rate",value:"1.2125"},
{axis:"Lending Interest Rate",value:"5.286666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.11019849"},
{axis:"Unemployment",value:"5.199999809"}]
    },

{className:"Macedonia",
axes: [
{axis:"Inflation",value:"1.50997522"},
{axis:"Deposit Interest Rate",value:"7.066666667"},
{axis:"Lending Interest Rate",value:"9.483333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.358760114"},
{axis:"Unemployment",value:"32"}]
    },
{className:"Mali",
axes: [
{axis:"Inflation",value:"1.108926907"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.8690858"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Malta",
axes: [
{axis:"Inflation",value:"1.516833766"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"4.6"},
{axis:"Central Government Debt",value:"82.94168669"},
{axis:"GDP",value:"4.3"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Myanmar",
axes: [
{axis:"Inflation",value:"7.718381959"},
{axis:"Deposit Interest Rate",value:"12"},
{axis:"Lending Interest Rate",value:"17"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"Montenegro",
axes: [
{axis:"Inflation",value:"0.65494657"},
{axis:"Deposit Interest Rate",value:"3.699525"},
{axis:"Lending Interest Rate",value:"9.53"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.46373268"},
{axis:"Unemployment",value:"19.70000076"}]
    },
{className:"Mongolia",
axes: [
{axis:"Inflation",value:"10.14963142"},
{axis:"Deposit Interest Rate",value:"11.85897858"},
{axis:"Lending Interest Rate",value:"20.06878016"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.365161685"},
{axis:"Unemployment",value:"6.5"}]
    },

{className:"Mozambique",
axes: [
{axis:"Inflation",value:"12.70123982"},
{axis:"Deposit Interest Rate",value:"9.684442134"},
{axis:"Lending Interest Rate",value:"16.26266667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.687731849"},
{axis:"Unemployment",value:"22.60000038"}]
    },
{className:"Mauritania",
axes: [
{axis:"Inflation",value:"6.283540874"},
{axis:"Deposit Interest Rate",value:"8"},
{axis:"Lending Interest Rate",value:"17"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.773697175"},
{axis:"Unemployment",value:"31.10000038"}]
    },
{className:"Mauritius",
axes: [
{axis:"Inflation",value:"2.892968717"},
{axis:"Deposit Interest Rate",value:"8.35"},
{axis:"Lending Interest Rate",value:"8.875"},
{axis:"Central Government Debt",value:"50.45840158"},
{axis:"GDP",value:"4.100201815"},
{axis:"Unemployment",value:"7.699999809"}]
    },
{className:"Malawi",
axes: [
{axis:"Inflation",value:"7.411590929"},
{axis:"Deposit Interest Rate",value:"3.604166667"},
{axis:"Lending Interest Rate",value:"24.625"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.874065635"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Malaysia",
axes: [
{axis:"Inflation",value:"1.710037175"},
{axis:"Deposit Interest Rate",value:"2.5025"},
{axis:"Lending Interest Rate",value:"5"},
{axis:"Central Government Debt",value:"49.55976273"},
{axis:"GDP",value:"7.425970491"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"North America",
axes: [
{axis:"Inflation",value:"1.708457492"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"68.45668706"},
{axis:"GDP",value:"2.583645786"},
{axis:"Unemployment",value:"9.517847992"}]
    },
{className:"Namibia",
axes: [
{axis:"Inflation",value:"4.874919876"},
{axis:"Deposit Interest Rate",value:"4.996666667"},
{axis:"Lending Interest Rate",value:"9.72"},
{axis:"Central Government Debt",value:"32.13539441"},
{axis:"GDP",value:"6.03924941"},
{axis:"Unemployment",value:"22.10000038"}]
    },
{className:"Niger",
axes: [
{axis:"Inflation",value:"0.804073081"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.369239798"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Nigeria",
axes: [
{axis:"Inflation",value:"13.72020184"},
{axis:"Deposit Interest Rate",value:"6.520833333"},
{axis:"Lending Interest Rate",value:"17.585"},
{axis:"Central Government Debt",value:"9.449542805"},
{axis:"GDP",value:"7.839739477"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Nicaragua",
axes: [
{axis:"Inflation",value:"5.454855462"},
{axis:"Deposit Interest Rate",value:"2.991328292"},
{axis:"Lending Interest Rate",value:"13.31996686"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.191298766"},
{axis:"Unemployment",value:"8"}]
    },
{className:"Netherlands",
axes: [
{axis:"Inflation",value:"1.275552568"},
{axis:"Deposit Interest Rate",value:"2.347175"},
{axis:"Lending Interest Rate",value:"1.75"},
{axis:"Central Government Debt",value:"58.62786455"},
{axis:"GDP",value:"1.402662177"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Norway",
axes: [
{axis:"Inflation",value:"2.399257688"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"35.1377887"},
{axis:"GDP",value:"0.60193444"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Nepal",
axes: [
{axis:"Inflation",value:"9.324000504"},
{axis:"Deposit Interest Rate",value:"3.625"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:"33.86252123"},
{axis:"GDP",value:"4.81641465"},
{axis:"Unemployment",value:"2.700000048"}]
    },
{className:"New Zealand",
axes: [
{axis:"Inflation",value:"2.302025783"},
{axis:"Deposit Interest Rate",value:"4.583250809"},
{axis:"Lending Interest Rate",value:"6.255454248"},
{axis:"Central Government Debt",value:"49.2045015"},
{axis:"GDP",value:"1.37039191"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Oman",
axes: [
{axis:"Inflation",value:"3.203396372"},
{axis:"Deposit Interest Rate",value:"3.366"},
{axis:"Lending Interest Rate",value:"6.835"},
{axis:"Central Government Debt",value:"5.039117245"},
{axis:"GDP",value:"4.802852057"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Pakistan",
axes: [
{axis:"Inflation",value:"13.88113926"},
{axis:"Deposit Interest Rate",value:"8.145"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.606691959"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Panama",
axes: [
{axis:"Inflation",value:"3.491288726"},
{axis:"Deposit Interest Rate",value:"3.043333333"},
{axis:"Lending Interest Rate",value:"7.735"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.767349873"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Peru",
axes: [
{axis:"Inflation",value:"1.528320597"},
{axis:"Deposit Interest Rate",value:"1.543218417"},
{axis:"Lending Interest Rate",value:"18.97686833"},
{axis:"Central Government Debt",value:"23.5176493"},
{axis:"GDP",value:"8.450746875"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Philippines",
axes: [
{axis:"Inflation",value:"3.789836348"},
{axis:"Deposit Interest Rate",value:"3.219666667"},
{axis:"Lending Interest Rate",value:"7.672666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.632263916"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"Palau",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.285802852"},
{axis:"Unemployment",value:""}]
    },
{className:"Papua New Guinea",
axes: [
{axis:"Inflation",value:"6.013608936"},
{axis:"Deposit Interest Rate",value:"1.383333333"},
{axis:"Lending Interest Rate",value:"10.44583333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.674331651"},
{axis:"Unemployment",value:"2.5"}]
    },
{className:"Poland",
axes: [
{axis:"Inflation",value:"2.707452359"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"50.98148174"},
{axis:"GDP",value:"3.698867548"},
{axis:"Unemployment",value:"9.600000381"}]
    },
{className:"Puerto Rico",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.612530288"},
{axis:"Unemployment",value:"16.20000076"}]
    },
{className:"Portugal",
axes: [
{axis:"Inflation",value:"1.402572899"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"100.248368"},
{axis:"GDP",value:"1.898691753"},
{axis:"Unemployment",value:"10.80000019"}]
    },
{className:"Paraguay",
axes: [
{axis:"Inflation",value:"4.651162791"},
{axis:"Deposit Interest Rate",value:"1.2125"},
{axis:"Lending Interest Rate",value:"26.0357468"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"13.09300368"},
{axis:"Unemployment",value:"5.699999809"}]
    },
{className:"Qatar",
axes: [
{axis:"Inflation",value:"-2.425256752"},
{axis:"Deposit Interest Rate",value:"2.898541918"},
{axis:"Lending Interest Rate",value:"7.271447981"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"19.59233153"},
{axis:"Unemployment",value:"0.400000006"}]
    },
{className:"Romania",
axes: [
{axis:"Inflation",value:"6.094215787"},
{axis:"Deposit Interest Rate",value:"7.313333333"},
{axis:"Lending Interest Rate",value:"14.0725"},
{axis:"Central Government Debt",value:"34.59767353"},
{axis:"GDP",value:"-0.798465536"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"Russian Federation",
axes: [
{axis:"Inflation",value:"6.835359842"},
{axis:"Deposit Interest Rate",value:"6.008333333"},
{axis:"Lending Interest Rate",value:"10.81666667"},
{axis:"Central Government Debt",value:"9.089899815"},
{axis:"GDP",value:"4.503725626"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"Rwanda",
axes: [
{axis:"Inflation",value:"2.309146191"},
{axis:"Deposit Interest Rate",value:"7.1"},
{axis:"Lending Interest Rate",value:"16.94"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.312669275"},
{axis:"Unemployment",value:"0.600000024"}]
    },
{className:"South Asia",
axes: [
{axis:"Inflation",value:"7.581529776"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"50.60012925"},
{axis:"GDP",value:"9.083569986"},
{axis:"Unemployment",value:"3.823739458"}]
    },
{className:"Saudi Arabia",
axes: [
{axis:"Inflation",value:"5.343137255"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.761882035"},
{axis:"Unemployment",value:"5.400000095"}]
    },
{className:"Sudan",
axes: [
{axis:"Inflation",value:"13.24539414"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.469335093"},
{axis:"Unemployment",value:"14.60000038"}]
    },
{className:"Senegal",
axes: [
{axis:"Inflation",value:"1.228681197"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.179363063"},
{axis:"Unemployment",value:"9.100000381"}]
    },
{className:"Singapore",
axes: [
{axis:"Inflation",value:"2.8"},
{axis:"Deposit Interest Rate",value:"0.205833333"},
{axis:"Lending Interest Rate",value:"5.38"},
{axis:"Central Government Debt",value:"102.903421"},
{axis:"GDP",value:"15.24037704"},
{axis:"Unemployment",value:"3.099999905"}]
    },
{className:"Solomon Islands",
axes: [
{axis:"Inflation",value:"1.051481633"},
{axis:"Deposit Interest Rate",value:"3.288149231"},
{axis:"Lending Interest Rate",value:"14.43365833"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.895556838"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Sierra Leone",
axes: [
{axis:"Inflation",value:"16.63522383"},
{axis:"Deposit Interest Rate",value:"9.466666667"},
{axis:"Lending Interest Rate",value:"21.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.365143208"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"El Salvador",
axes: [
{axis:"Inflation",value:"0.907806937"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"49.52073694"},
{axis:"GDP",value:"1.364783667"},
{axis:"Unemployment",value:"7"}]
    },
{className:"San Marino",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.7075"},
{axis:"Lending Interest Rate",value:"5.3825"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Somalia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Serbia",
axes: [
{axis:"Inflation",value:"6.142553602"},
{axis:"Deposit Interest Rate",value:"11.33"},
{axis:"Lending Interest Rate",value:"17.3"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.584478088"},
{axis:"Unemployment",value:"19.20000076"}]
    },
{className:"Sao Tome and Principe",
axes: [
{axis:"Inflation",value:"13.34005235"},
{axis:"Deposit Interest Rate",value:"11.115"},
{axis:"Lending Interest Rate",value:"28.87497222"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.480038922"},
{axis:"Unemployment",value:""}]
    },
{className:"Suriname",
axes: [
{axis:"Inflation",value:"6.944787295"},
{axis:"Deposit Interest Rate",value:"6.166434651"},
{axis:"Lending Interest Rate",value:"11.59054306"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.157261795"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Slovak Republic",
axes: [
{axis:"Inflation",value:"0.957018133"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"44.59620698"},
{axis:"GDP",value:"5.081851666"},
{axis:"Unemployment",value:"14.39999962"}]
    },
{className:"Slovenia",
axes: [
{axis:"Inflation",value:"1.840965347"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.237670766"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Sweden",
axes: [
{axis:"Inflation",value:"1.157988027"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"42.28350957"},
{axis:"GDP",value:"5.988926547"},
{axis:"Unemployment",value:"8.699999809"}]
    },
{className:"Swaziland",
axes: [
{axis:"Inflation",value:"4.509236918"},
{axis:"Deposit Interest Rate",value:"3.853333333"},
{axis:"Lending Interest Rate",value:"9.75"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.68081685"},
{axis:"Unemployment",value:"22.79999924"}]
    },
{className:"Seychelles",
axes: [
{axis:"Inflation",value:"-2.404638751"},
{axis:"Deposit Interest Rate",value:"2.859946582"},
{axis:"Lending Interest Rate",value:"12.70264981"},
{axis:"Central Government Debt",value:"75.54200413"},
{axis:"GDP",value:"5.954962469"},
{axis:"Unemployment",value:""}]
    },
{className:"Syrian Arab Republic",
axes: [
{axis:"Inflation",value:"4.397413832"},
{axis:"Deposit Interest Rate",value:"6.2159"},
{axis:"Lending Interest Rate",value:"9.9009"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"Chad",
axes: [
{axis:"Inflation",value:"-2.077865746"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"13.55010086"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"East Asia and Pacific (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.789836348"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.772136875"},
{axis:"Unemployment",value:"4.369108784"}]
    },
{className:"Europe and Central Asia (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"6.419565094"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.020234215"},
{axis:"Unemployment",value:"9.114785208"}]
    },
{className:"Togo",
axes: [
{axis:"Inflation",value:"1.834169331"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.99567877"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Thailand",
axes: [
{axis:"Inflation",value:"3.272220008"},
{axis:"Deposit Interest Rate",value:"1.0125"},
{axis:"Lending Interest Rate",value:"5.935"},
{axis:"Central Government Debt",value:"26.91514714"},
{axis:"GDP",value:"7.506710715"},
{axis:"Unemployment",value:"1"}]
    },
{className:"Tajikistan",
axes: [
{axis:"Inflation",value:"6.419565094"},
{axis:"Deposit Interest Rate",value:"8.647640114"},
{axis:"Lending Interest Rate",value:"23.39962361"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.500000353"},
{axis:"Unemployment",value:"11.60000038"}]
    },
{className:"Turkmenistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.199999988"},
{axis:"Unemployment",value:"10.89999962"}]
    },
{className:"Latin America and the Caribbean (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"4.008118468"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.015872856"},
{axis:"Unemployment",value:"7.317144803"}]
    },
{className:"Middle East and North Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"4.193627648"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.409080212"},
{axis:"Unemployment",value:"11.5430824"}]
    },
{className:"Timor-Leste",
axes: [
{axis:"Inflation",value:"6.765976802"},
{axis:"Deposit Interest Rate",value:"0.813286263"},
{axis:"Lending Interest Rate",value:"11.02887753"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.367681499"},
{axis:"Unemployment",value:"3.900000095"}]
    },
{className:"Tonga",
axes: [
{axis:"Inflation",value:"3.553509298"},
{axis:"Deposit Interest Rate",value:"4.027788889"},
{axis:"Lending Interest Rate",value:"11.53560797"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.165690916"},
{axis:"Unemployment",value:""}]
    },
{className:"South Asia (IDA and IBRD)",
axes: [
{axis:"Inflation",value:"7.581529776"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"50.60012925"},
{axis:"GDP",value:"9.083569986"},
{axis:"Unemployment",value:"3.823739458"}]
    },
{className:"Sub-Saharan Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"4.385790234"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.535337881"},
{axis:"Unemployment",value:"8.102703032"}]
    },
{className:"Trinidad and Tobago",
axes: [
{axis:"Inflation",value:"10.54738949"},
{axis:"Deposit Interest Rate",value:"1.505"},
{axis:"Lending Interest Rate",value:"9.2825"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.092861903"},
{axis:"Unemployment",value:"5.900000095"}]
    },
{className:"Tunisia",
axes: [
{axis:"Inflation",value:"4.416268965"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"40.6626014"},
{axis:"GDP",value:"3.510608639"},
{axis:"Unemployment",value:"13"}]
    },
{className:"Turkey",
axes: [
{axis:"Inflation",value:"8.566444206"},
{axis:"Deposit Interest Rate",value:"15.26916667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"50.0749296"},
{axis:"GDP",value:"9.156954487"},
{axis:"Unemployment",value:"11.89999962"}]
    },
{className:"Tuvalu",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.729427912"},
{axis:"Unemployment",value:""}]
    },
{className:"Tanzania",
axes: [
{axis:"Inflation",value:"6.200155956"},
{axis:"Deposit Interest Rate",value:"6.565753852"},
{axis:"Lending Interest Rate",value:"14.5459147"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.358886081"},
{axis:"Unemployment",value:"3"}]
    },
{className:"Uganda",
axes: [
{axis:"Inflation",value:"3.976552885"},
{axis:"Deposit Interest Rate",value:"7.687276001"},
{axis:"Lending Interest Rate",value:"20.17463013"},
{axis:"Central Government Debt",value:"27.54933821"},
{axis:"GDP",value:"5.170342974"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Ukraine",
axes: [
{axis:"Inflation",value:"9.378589479"},
{axis:"Deposit Interest Rate",value:"10.55570833"},
{axis:"Lending Interest Rate",value:"15.86839167"},
{axis:"Central Government Debt",value:"29.88033095"},
{axis:"GDP",value:"4.200000016"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Uruguay",
axes: [
{axis:"Inflation",value:"6.676386868"},
{axis:"Deposit Interest Rate",value:"4.165799862"},
{axis:"Lending Interest Rate",value:"10.32622218"},
{axis:"Central Government Debt",value:"44.22270175"},
{axis:"GDP",value:"7.803409655"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"United States",
axes: [
{axis:"Inflation",value:"1.640043442"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"3.25"},
{axis:"Central Government Debt",value:"85.60159424"},
{axis:"GDP",value:"2.531920616"},
{axis:"Unemployment",value:"9.699999809"}]
    },
{className:"Uzbekistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.5"},
{axis:"Unemployment",value:"10.89999962"}]
    },
{className:"St Vincent and the Grenadines",
axes: [
{axis:"Inflation",value:"1.480573011"},
{axis:"Deposit Interest Rate",value:"2.859590539"},
{axis:"Lending Interest Rate",value:"9.171837676"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.365116682"},
{axis:"Unemployment",value:""}]
    },
{className:"Venezuela",
axes: [
{axis:"Inflation",value:"28.18746471"},
{axis:"Deposit Interest Rate",value:"14.80083333"},
{axis:"Lending Interest Rate",value:"18.3475"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.488791251"},
{axis:"Unemployment",value:"8.600000381"}]
    },
{className:"Vietnam",
axes: [
{axis:"Inflation",value:"8.861600361"},
{axis:"Deposit Interest Rate",value:"11.19375"},
{axis:"Lending Interest Rate",value:"13.13525"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.423238217"},
{axis:"Unemployment",value:"2.599999905"}]
    },
{className:"Vanuatu",
axes: [
{axis:"Inflation",value:"2.809293259"},
{axis:"Deposit Interest Rate",value:"1.583333333"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.629081596"},
{axis:"Unemployment",value:""}]
    },
{className:"West Bank and Gaza",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.29"},
{axis:"Lending Interest Rate",value:"6.235"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.337462352"},
{axis:"Unemployment",value:"23.70000076"}]
    },
{className:"World",
axes: [
{axis:"Inflation",value:"3.554816552"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.350096248"},
{axis:"Unemployment",value:"6.113656184"}]
    },
{className:"Samoa",
axes: [
{axis:"Inflation",value:"0.777007269"},
{axis:"Deposit Interest Rate",value:"2.700833333"},
{axis:"Lending Interest Rate",value:"10.72"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.479158713"},
{axis:"Unemployment",value:""}]
    },
{className:"Yemen",
axes: [
{axis:"Inflation",value:"11.17483386"},
{axis:"Deposit Interest Rate",value:"18.66666667"},
{axis:"Lending Interest Rate",value:"23.83333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.317465196"},
{axis:"Unemployment",value:"17.79999924"}]
    },
{className:"South Africa",
axes: [
{axis:"Inflation",value:"4.26234355"},
{axis:"Deposit Interest Rate",value:"6.465"},
{axis:"Lending Interest Rate",value:"9.833333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.039747085"},
{axis:"Unemployment",value:"24.70000076"}]
    },
{className:"Democratic Republic of the Congo",
axes: [
{axis:"Inflation",value:"7.1"},
{axis:"Deposit Interest Rate",value:"16.77333333"},
{axis:"Lending Interest Rate",value:"56.51833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.078889424"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Zambia",
axes: [
{axis:"Inflation",value:"8.501761334"},
{axis:"Deposit Interest Rate",value:"7.4"},
{axis:"Lending Interest Rate",value:"20.9163168"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.29820581"},
{axis:"Unemployment",value:"13.19999981"}]
    },
{className:"Zimbabwe",
axes: [
{axis:"Inflation",value:"3.034478884"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.37592123"},
{axis:"Unemployment",value:"5.5"}]
    }
],
["2011",
{className:"Aruba",
axes: [
{axis:"Inflation",value:"4.374595795"},
{axis:"Deposit Interest Rate",value:"1.675"},
{axis:"Lending Interest Rate",value:"9.658333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Andorra",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.802675037"},
{axis:"Unemployment",value:""}]
    },
{className:"Afghanistan",
axes: [
{axis:"Inflation",value:"10.20166014"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"15.14583333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.113685169"},
{axis:"Unemployment",value:"8.899999619"}]
    },
{className:"Angola",
axes: [
{axis:"Inflation",value:"13.46701535"},
{axis:"Deposit Interest Rate",value:"6.30923166"},
{axis:"Lending Interest Rate",value:"18.75724054"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.918596986"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Albania",
axes: [
{axis:"Inflation",value:"3.450347153"},
{axis:"Deposit Interest Rate",value:"5.861752642"},
{axis:"Lending Interest Rate",value:"12.4320986"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.550000005"},
{axis:"Unemployment",value:"14"}]
    },
{className:"United Arab Emirates",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.207798911"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Argentina",
axes: [
{axis:"Inflation",value:"9.465686275"},
{axis:"Deposit Interest Rate",value:"10.67917176"},
{axis:"Lending Interest Rate",value:"14.0875"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.14748634"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Armenia",
axes: [
{axis:"Inflation",value:"7.651233638"},
{axis:"Deposit Interest Rate",value:"9.248043314"},
{axis:"Lending Interest Rate",value:"17.75447379"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.699999999"},
{axis:"Unemployment",value:"18.39999962"}]
    },
{className:"Antigua and Barbuda",
axes: [
{axis:"Inflation",value:"3.456749672"},
{axis:"Deposit Interest Rate",value:"3.375376901"},
{axis:"Lending Interest Rate",value:"10.91445252"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.793435604"},
{axis:"Unemployment",value:""}]
    },
{className:"Australia",
axes: [
{axis:"Inflation",value:"3.303850156"},
{axis:"Deposit Interest Rate",value:"4.3375"},
{axis:"Lending Interest Rate",value:"7.7375"},
{axis:"Central Government Debt",value:"30.513578"},
{axis:"GDP",value:"2.379561336"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Austria",
axes: [
{axis:"Inflation",value:"3.266938912"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"80.14872034"},
{axis:"GDP",value:"2.807999932"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Azerbaijan",
axes: [
{axis:"Inflation",value:"7.850450579"},
{axis:"Deposit Interest Rate",value:"10.87416667"},
{axis:"Lending Interest Rate",value:"18.98833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.065922768"},
{axis:"Unemployment",value:"5.400000095"}]
    },
{className:"Burundi",
axes: [
{axis:"Inflation",value:"9.735019199"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"13.2325"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.191625681"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Belgium",
axes: [
{axis:"Inflation",value:"3.532082107"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"94.91447928"},
{axis:"GDP",value:"1.796837889"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Benin",
axes: [
{axis:"Inflation",value:"2.71280052"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.962750351"},
{axis:"Unemployment",value:"1"}]
    },
{className:"Burkina Faso",
axes: [
{axis:"Inflation",value:"2.759767249"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.521769448"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Bangladesh",
axes: [
{axis:"Inflation",value:"10.7048046"},
{axis:"Deposit Interest Rate",value:"8.8375"},
{axis:"Lending Interest Rate",value:"13.32166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.46438388"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Bulgaria",
axes: [
{axis:"Inflation",value:"4.219903466"},
{axis:"Deposit Interest Rate",value:"3.368266667"},
{axis:"Lending Interest Rate",value:"10.62945833"},
{axis:"Central Government Debt",value:"14.52212183"},
{axis:"GDP",value:"1.583973961"},
{axis:"Unemployment",value:"11.30000019"}]
    },
{className:"Bahrain",
axes: [
{axis:"Inflation",value:"-0.36444775"},
{axis:"Deposit Interest Rate",value:"1.0225"},
{axis:"Lending Interest Rate",value:"6.790833333"},
{axis:"Central Government Debt",value:"35.60515501"},
{axis:"GDP",value:"2.100184109"},
{axis:"Unemployment",value:"4"}]
    },
{className:"The Bahamas",
axes: [
{axis:"Inflation",value:"3.198781417"},
{axis:"Deposit Interest Rate",value:"2.63369187"},
{axis:"Lending Interest Rate",value:"5.0625"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.612902596"},
{axis:"Unemployment",value:"13.69999981"}]
    },
{className:"Bosnia and Herzegovina",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.795833333"},
{axis:"Lending Interest Rate",value:"7.431666667"},
{axis:"Central Government Debt",value:"43.13173752"},
{axis:"GDP",value:"0.908247974"},
{axis:"Unemployment",value:"27.60000038"}]
    },
{className:"Belarus",
axes: [
{axis:"Inflation",value:"53.22869831"},
{axis:"Deposit Interest Rate",value:"13.30833333"},
{axis:"Lending Interest Rate",value:"13.575"},
{axis:"Central Government Debt",value:"40.75485188"},
{axis:"GDP",value:"5.543711461"},
{axis:"Unemployment",value:"6.099999905"}]
    },
{className:"Belize",
axes: [
{axis:"Inflation",value:"-3.648143303"},
{axis:"Deposit Interest Rate",value:"6.440833333"},
{axis:"Lending Interest Rate",value:"13.36333333"},
{axis:"Central Government Debt",value:"76.88938875"},
{axis:"GDP",value:"2.102218515"},
{axis:"Unemployment",value:"12.30000019"}]
    },
{className:"Bermuda",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.33949441"},
{axis:"Unemployment",value:""}]
    },
{className:"Bolivia",
axes: [
{axis:"Inflation",value:"9.812689841"},
{axis:"Deposit Interest Rate",value:"1.403036155"},
{axis:"Lending Interest Rate",value:"10.91539234"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.204092718"},
{axis:"Unemployment",value:"2.700000048"}]
    },
{className:"Brazil",
axes: [
{axis:"Inflation",value:"6.636198657"},
{axis:"Deposit Interest Rate",value:"10.99236482"},
{axis:"Lending Interest Rate",value:"43.88333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.910255348"},
{axis:"Unemployment",value:"6.699999809"}]
    },
{className:"Barbados",
axes: [
{axis:"Inflation",value:"9.432202402"},
{axis:"Deposit Interest Rate",value:"2.676666667"},
{axis:"Lending Interest Rate",value:"8.7"},
{axis:"Central Government Debt",value:"107.1401625"},
{axis:"GDP",value:"0.72859745"},
{axis:"Unemployment",value:"11.19999981"}]
    },
{className:"Brunei Darussalam",
axes: [
{axis:"Inflation",value:"2.015934385"},
{axis:"Deposit Interest Rate",value:"0.395703333"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.429818477"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Bhutan",
axes: [
{axis:"Inflation",value:"8.848985699"},
{axis:"Deposit Interest Rate",value:"4.5"},
{axis:"Lending Interest Rate",value:"14"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.890913893"},
{axis:"Unemployment",value:"3.099999905"}]
    },
{className:"Botswana",
axes: [
{axis:"Inflation",value:"8.458165875"},
{axis:"Deposit Interest Rate",value:"5.1477375"},
{axis:"Lending Interest Rate",value:"11"},
{axis:"Central Government Debt",value:"19.85777622"},
{axis:"GDP",value:"6.048316367"},
{axis:"Unemployment",value:"17.79999924"}]
    },
{className:"Central African Republic",
axes: [
{axis:"Inflation",value:"1.300569969"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.300739707"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Canada",
axes: [
{axis:"Inflation",value:"2.912135089"},
{axis:"Deposit Interest Rate",value:"0.475"},
{axis:"Lending Interest Rate",value:"3"},
{axis:"Central Government Debt",value:"51.89013979"},
{axis:"GDP",value:"3.141219001"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Central Europe and the Baltics",
axes: [
{axis:"Inflation",value:"4.133333333"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"40.75319834"},
{axis:"GDP",value:"3.111007686"},
{axis:"Unemployment",value:"9.787447908"}]
    },
{className:"Switzerland",
axes: [
{axis:"Inflation",value:"0.23134621"},
{axis:"Deposit Interest Rate",value:"0.03"},
{axis:"Lending Interest Rate",value:"2.718333333"},
{axis:"Central Government Debt",value:"24.1914956"},
{axis:"GDP",value:"1.804553915"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Chile",
axes: [
{axis:"Inflation",value:"3.340318008"},
{axis:"Deposit Interest Rate",value:"5.286838314"},
{axis:"Lending Interest Rate",value:"9.030152523"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.839640583"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"China",
axes: [
{axis:"Inflation",value:"5.410850058"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:"6.56"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.484506202"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Cote dIvoire",
axes: [
{axis:"Inflation",value:"4.912433951"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.387254788"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Cameroon",
axes: [
{axis:"Inflation",value:"2.939699463"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.140591847"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Republic of Congo",
axes: [
{axis:"Inflation",value:"1.325757664"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.42062127"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"Colombia",
axes: [
{axis:"Inflation",value:"3.411616121"},
{axis:"Deposit Interest Rate",value:"4.263884597"},
{axis:"Lending Interest Rate",value:"11.21991845"},
{axis:"Central Government Debt",value:"62.77181095"},
{axis:"GDP",value:"6.589511516"},
{axis:"Unemployment",value:"11.10000038"}]
    },
{className:"Comoros",
axes: [
{axis:"Inflation",value:"1.771363774"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"10.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.600000088"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Cabo Verde",
axes: [
{axis:"Inflation",value:"4.473883422"},
{axis:"Deposit Interest Rate",value:"3.351215666"},
{axis:"Lending Interest Rate",value:"9.810803815"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.968783812"},
{axis:"Unemployment",value:"9.199999809"}]
    },
{className:"Costa Rica",
axes: [
{axis:"Inflation",value:"4.883012481"},
{axis:"Deposit Interest Rate",value:"4.009166667"},
{axis:"Lending Interest Rate",value:"16.14583333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.517746474"},
{axis:"Unemployment",value:"7.699999809"}]
    },
{className:"Caribbean small states",
axes: [
{axis:"Inflation",value:"3.456749672"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.16565018"},
{axis:"Unemployment",value:"10.27148416"}]
    },
{className:"Cuba",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.802964336"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Cyprus",
axes: [
{axis:"Inflation",value:"3.289449396"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"104.1998816"},
{axis:"GDP",value:"0.404392546"},
{axis:"Unemployment",value:"7.900000095"}]
    },
{className:"Czech Republic",
axes: [
{axis:"Inflation",value:"1.936389149"},
{axis:"Deposit Interest Rate",value:"1.03825"},
{axis:"Lending Interest Rate",value:"5.717833333"},
{axis:"Central Government Debt",value:"36.36024581"},
{axis:"GDP",value:"1.966612632"},
{axis:"Unemployment",value:"6.699999809"}]
    },
{className:"Germany",
axes: [
{axis:"Inflation",value:"2.075172931"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"53.38423747"},
{axis:"GDP",value:"3.660000155"},
{axis:"Unemployment",value:"5.900000095"}]
    },
{className:"Djibouti",
axes: [
{axis:"Inflation",value:"5.068713948"},
{axis:"Deposit Interest Rate",value:"1.7775"},
{axis:"Lending Interest Rate",value:"11.48875"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.467514526"},
{axis:"Unemployment",value:""}]
    },
{className:"Dominica",
axes: [
{axis:"Inflation",value:"2.387630979"},
{axis:"Deposit Interest Rate",value:"3.20236001"},
{axis:"Lending Interest Rate",value:"8.840379655"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0"},
{axis:"Unemployment",value:""}]
    },
{className:"Denmark",
axes: [
{axis:"Inflation",value:"2.758682261"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"49.91518509"},
{axis:"GDP",value:"1.152142525"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Dominican Republic",
axes: [
{axis:"Inflation",value:"8.46016881"},
{axis:"Deposit Interest Rate",value:"7.874166667"},
{axis:"Lending Interest Rate",value:"15.55"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.820884489"},
{axis:"Unemployment",value:"14.69999981"}]
    },
{className:"Algeria",
axes: [
{axis:"Inflation",value:"4.521764663"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.9"},
{axis:"Unemployment",value:"10"}]
    },
{className:"East Asia and Pacific (excluding high income)",
axes: [
{axis:"Inflation",value:"5.410850058"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.441376602"},
{axis:"Unemployment",value:"4.330221796"}]
    },
{className:"East Asia and Pacific",
axes: [
{axis:"Inflation",value:"5.252918288"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.521181451"},
{axis:"Unemployment",value:"4.324924924"}]
    },
{className:"Europe and Central Asia (excluding high income)",
axes: [
{axis:"Inflation",value:"7.850450579"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.343055304"},
{axis:"Unemployment",value:"8.447494925"}]
    },
{className:"Europe and Central Asia",
axes: [
{axis:"Inflation",value:"3.904754221"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"47.05895267"},
{axis:"GDP",value:"2.277917313"},
{axis:"Unemployment",value:"9.032372465"}]
    },
{className:"Ecuador",
axes: [
{axis:"Inflation",value:"4.474553859"},
{axis:"Deposit Interest Rate",value:"3.844166667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.868140919"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Egypt",
axes: [
{axis:"Inflation",value:"10.0539169"},
{axis:"Deposit Interest Rate",value:"6.741666667"},
{axis:"Lending Interest Rate",value:"11.03333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.816646644"},
{axis:"Unemployment",value:"12"}]
    },
{className:"Eritrea",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.679799936"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Spain",
axes: [
{axis:"Inflation",value:"3.196242972"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"61.83202185"},
{axis:"GDP",value:"-1.000080488"},
{axis:"Unemployment",value:"21.70000076"}]
    },
{className:"Estonia",
axes: [
{axis:"Inflation",value:"4.977614784"},
{axis:"Deposit Interest Rate",value:"1.267589195"},
{axis:"Lending Interest Rate",value:"6.1170327"},
{axis:"Central Government Debt",value:"0.387819032"},
{axis:"GDP",value:"7.583125148"},
{axis:"Unemployment",value:"12.5"}]
    },
{className:"Ethiopia",
axes: [
{axis:"Inflation",value:"33.22421525"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.17829624"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"European Union",
axes: [
{axis:"Inflation",value:"3.309659785"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"57.60812966"},
{axis:"GDP",value:"1.761168014"},
{axis:"Unemployment",value:"9.611185016"}]
    },
{className:"Finland",
axes: [
{axis:"Inflation",value:"3.416809034"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"47.89123732"},
{axis:"GDP",value:"2.570817745"},
{axis:"Unemployment",value:"7.699999809"}]
    },
{className:"Fiji",
axes: [
{axis:"Inflation",value:"7.286544479"},
{axis:"Deposit Interest Rate",value:"3.746504108"},
{axis:"Lending Interest Rate",value:"7.466058192"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.050276112"},
{axis:"Unemployment",value:"8.5"}]
    },
{className:"France",
axes: [
{axis:"Inflation",value:"2.117486809"},
{axis:"Deposit Interest Rate",value:"2.083333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"79.48345153"},
{axis:"GDP",value:"2.079229175"},
{axis:"Unemployment",value:"9.199999809"}]
    },
{className:"Federal States of Micronesia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.589166667"},
{axis:"Lending Interest Rate",value:"14.35"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.050567151"},
{axis:"Unemployment",value:""}]
    },
{className:"Gabon",
axes: [
{axis:"Inflation",value:"1.269343222"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.091753343"},
{axis:"Unemployment",value:"20.39999962"}]
    },
{className:"United Kingdom",
axes: [
{axis:"Inflation",value:"4.484239645"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"0.5"},
{axis:"Central Government Debt",value:"97.50660706"},
{axis:"GDP",value:"1.972398563"},
{axis:"Unemployment",value:"7.800000191"}]
    },
{className:"Georgia",
axes: [
{axis:"Inflation",value:"8.542933333"},
{axis:"Deposit Interest Rate",value:"11.53779736"},
{axis:"Lending Interest Rate",value:"14.99516667"},
{axis:"Central Government Debt",value:"32.45976154"},
{axis:"GDP",value:"7.221523093"},
{axis:"Unemployment",value:"15.10000038"}]
    },
{className:"Ghana",
axes: [
{axis:"Inflation",value:"8.726836831"},
{axis:"Deposit Interest Rate",value:"8.908333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"14.04600263"},
{axis:"Unemployment",value:"4.599999905"}]
    },
{className:"Guinea",
axes: [
{axis:"Inflation",value:"21.35046642"},
{axis:"Deposit Interest Rate",value:"17.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.90876145"},
{axis:"Unemployment",value:"1.700000048"}]
    },
{className:"Gambia",
axes: [
{axis:"Inflation",value:"4.796484979"},
{axis:"Deposit Interest Rate",value:"11.75"},
{axis:"Lending Interest Rate",value:"28"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.328668868"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Guinea-Bissau",
axes: [
{axis:"Inflation",value:"5.046102263"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.334094819"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Equatorial Guinea",
axes: [
{axis:"Inflation",value:"2.475247525"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.975648557"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Greece",
axes: [
{axis:"Inflation",value:"3.329870174"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"111.1130028"},
{axis:"GDP",value:"-9.132494153"},
{axis:"Unemployment",value:"17.70000076"}]
    },
{className:"Grenada",
axes: [
{axis:"Inflation",value:"3.033472803"},
{axis:"Deposit Interest Rate",value:"3.112427855"},
{axis:"Lending Interest Rate",value:"10.68597901"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.764825341"},
{axis:"Unemployment",value:""}]
    },
{className:"Greenland",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Guatemala",
axes: [
{axis:"Inflation",value:"6.215341763"},
{axis:"Deposit Interest Rate",value:"5.244166667"},
{axis:"Lending Interest Rate",value:"13.43"},
{axis:"Central Government Debt",value:"24.16258981"},
{axis:"GDP",value:"4.162048946"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Guyana",
axes: [
{axis:"Inflation",value:"4.977735637"},
{axis:"Deposit Interest Rate",value:"1.940966667"},
{axis:"Lending Interest Rate",value:"14.45140278"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.437126058"},
{axis:"Unemployment",value:"11.10000038"}]
    },
{className:"Hong Kong",
axes: [
{axis:"Inflation",value:"5.263157895"},
{axis:"Deposit Interest Rate",value:"0.01"},
{axis:"Lending Interest Rate",value:"5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.814675724"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"Honduras",
axes: [
{axis:"Inflation",value:"6.762279573"},
{axis:"Deposit Interest Rate",value:"8.1821625"},
{axis:"Lending Interest Rate",value:"18.55753167"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.835690662"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Croatia",
axes: [
{axis:"Inflation",value:"2.272727273"},
{axis:"Deposit Interest Rate",value:"1.6975"},
{axis:"Lending Interest Rate",value:"9.684166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.281262662"},
{axis:"Unemployment",value:"13.39999962"}]
    },
{className:"Haiti",
axes: [
{axis:"Inflation",value:"8.411071041"},
{axis:"Deposit Interest Rate",value:"0.281666667"},
{axis:"Lending Interest Rate",value:"11.61"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.523737754"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Hungary",
axes: [
{axis:"Inflation",value:"3.920735315"},
{axis:"Deposit Interest Rate",value:"6.187064908"},
{axis:"Lending Interest Rate",value:"8.320381666"},
{axis:"Central Government Debt",value:"90.99908061"},
{axis:"GDP",value:"1.757501673"},
{axis:"Unemployment",value:"10.89999962"}]
    },
{className:"Indonesia",
axes: [
{axis:"Inflation",value:"5.357499604"},
{axis:"Deposit Interest Rate",value:"6.930833333"},
{axis:"Lending Interest Rate",value:"12.40333333"},
{axis:"Central Government Debt",value:"24.86518679"},
{axis:"GDP",value:"6.169784208"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"India",
axes: [
{axis:"Inflation",value:"8.857845297"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"10.16666667"},
{axis:"Central Government Debt",value:"45.08647368"},
{axis:"GDP",value:"6.63835345"},
{axis:"Unemployment",value:"3.5"}]
    },

{className:"Ireland",
axes: [
{axis:"Inflation",value:"2.578870455"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"109.9948371"},
{axis:"GDP",value:"2.588084299"},
{axis:"Unemployment",value:"14.60000038"}]
    },
{className:"Iran",
axes: [
{axis:"Inflation",value:"20.62833206"},
{axis:"Deposit Interest Rate",value:"11.1615765"},
{axis:"Lending Interest Rate",value:"11"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.749690486"},
{axis:"Unemployment",value:"13.30000019"}]
    },
{className:"Iraq",
axes: [
{axis:"Inflation",value:"5.801455371"},
{axis:"Deposit Interest Rate",value:"5.9125"},
{axis:"Lending Interest Rate",value:"13.60666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.5464712"},
{axis:"Unemployment",value:"15.19999981"}]
    },
{className:"Iceland",
axes: [
{axis:"Inflation",value:"3.990412645"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"7.698072473"},
{axis:"Central Government Debt",value:"112.937883"},
{axis:"GDP",value:"1.98812081"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Israel",
axes: [
{axis:"Inflation",value:"3.459195493"},
{axis:"Deposit Interest Rate",value:"2.4822892"},
{axis:"Lending Interest Rate",value:"5.9216952"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.030189584"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Italy",
axes: [
{axis:"Inflation",value:"2.741438213"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"4.599166667"},
{axis:"Central Government Debt",value:"108.3492614"},
{axis:"GDP",value:"0.57662466"},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"Jamaica",
axes: [
{axis:"Inflation",value:"7.529692443"},
{axis:"Deposit Interest Rate",value:"3.862708741"},
{axis:"Lending Interest Rate",value:"19.50927929"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.723211104"},
{axis:"Unemployment",value:"12.69999981"}]
    },
{className:"Jordan",
axes: [
{axis:"Inflation",value:"4.158333333"},
{axis:"Deposit Interest Rate",value:"3.395"},
{axis:"Lending Interest Rate",value:"8.713333333"},
{axis:"Central Government Debt",value:"61.85454637"},
{axis:"GDP",value:"2.560808799"},
{axis:"Unemployment",value:"12.89999962"}]
    },
{className:"Japan",
axes: [
{axis:"Inflation",value:"-0.283333333"},
{axis:"Deposit Interest Rate",value:"0.461583333"},
{axis:"Lending Interest Rate",value:"1.500916667"},
{axis:"Central Government Debt",value:"189.4197087"},
{axis:"GDP",value:"-0.454282297"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Kazakhstan",
axes: [
{axis:"Inflation",value:"8.348569186"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.2"},
{axis:"Unemployment",value:"5.400000095"}]
    },
{className:"Kenya",
axes: [
{axis:"Inflation",value:"14.0215499"},
{axis:"Deposit Interest Rate",value:"5.628563398"},
{axis:"Lending Interest Rate",value:"15.04675999"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.11161346"},
{axis:"Unemployment",value:"9.199999809"}]
    },
{className:"Kyrgyz Republic",
axes: [
{axis:"Inflation",value:"16.49588472"},
{axis:"Deposit Interest Rate",value:"2.250493871"},
{axis:"Lending Interest Rate",value:"25.27460672"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.956274377"},
{axis:"Unemployment",value:"8.5"}]
    },
{className:"Cambodia",
axes: [
{axis:"Inflation",value:"5.478587304"},
{axis:"Deposit Interest Rate",value:"1.3380375"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.069569946"},
{axis:"Unemployment",value:"0.300000012"}]
    },
{className:"St Kitts and Nevis",
axes: [
{axis:"Inflation",value:"5.835165196"},
{axis:"Deposit Interest Rate",value:"4.465355665"},
{axis:"Lending Interest Rate",value:"9.445087914"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.695115944"},
{axis:"Unemployment",value:""}]
    },
{className:"South Korea",
axes: [
{axis:"Inflation",value:"4"},
{axis:"Deposit Interest Rate",value:"4.1525"},
{axis:"Lending Interest Rate",value:"5.7575"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.681704667"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"Kosovo",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"3.618973386"},
{axis:"Lending Interest Rate",value:"13.3"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.619578328"},
{axis:"Unemployment",value:""}]
    },
{className:"Kuwait",
axes: [
{axis:"Inflation",value:"4.905335628"},
{axis:"Deposit Interest Rate",value:"2.161283333"},
{axis:"Lending Interest Rate",value:"5.193091667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.628436082"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Latin America and Caribbean (excluding high income)",
axes: [
{axis:"Inflation",value:"5.875802437"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.467668309"},
{axis:"Unemployment",value:"6.615623316"}]
    },
{className:"Lao PDR",
axes: [
{axis:"Inflation",value:"7.576924053"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.038652681"},
{axis:"Unemployment",value:"1.399999976"}]
    },
{className:"Lebanon",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"5.884166667"},
{axis:"Lending Interest Rate",value:"7.5275"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.004586309"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"Liberia",
axes: [
{axis:"Inflation",value:"8.486600465"},
{axis:"Deposit Interest Rate",value:"3.033333333"},
{axis:"Lending Interest Rate",value:"13.75083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.199998146"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Libya",
axes: [
{axis:"Inflation",value:"15.51848153"},
{axis:"Deposit Interest Rate",value:"2.5"},
{axis:"Lending Interest Rate",value:"6"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-62.07591958"},
{axis:"Unemployment",value:"17.70000076"}]
    },
{className:"St Lucia",
axes: [
{axis:"Inflation",value:"2.769407941"},
{axis:"Deposit Interest Rate",value:"3.494234067"},
{axis:"Lending Interest Rate",value:"10.00205043"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.701816462"},
{axis:"Unemployment",value:""}]
    },
{className:"Latin America and Caribbean",
axes: [
{axis:"Inflation",value:"5.128923767"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.383219802"},
{axis:"Unemployment",value:"6.670682104"}]
    },
{className:"Liechtenstein",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Sri Lanka",
axes: [
{axis:"Inflation",value:"6.716768436"},
{axis:"Deposit Interest Rate",value:"8.5"},
{axis:"Lending Interest Rate",value:"8.5"},
{axis:"Central Government Debt",value:"71.10805287"},
{axis:"GDP",value:"8.404738131"},
{axis:"Unemployment",value:"4.199999809"}]
    },

{className:"Lesotho",
axes: [
{axis:"Inflation",value:"5.024816566"},
{axis:"Deposit Interest Rate",value:"2.695"},
{axis:"Lending Interest Rate",value:"10.42916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.04854461"},
{axis:"Unemployment",value:"30.20000076"}]
    },
{className:"Lithuania",
axes: [
{axis:"Inflation",value:"4.133333333"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"40.75319834"},
{axis:"GDP",value:"6.044910029"},
{axis:"Unemployment",value:"15.30000019"}]
    },
{className:"Luxembourg",
axes: [
{axis:"Inflation",value:"3.409795876"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"16.99613565"},
{axis:"GDP",value:"2.565685444"},
{axis:"Unemployment",value:"4.900000095"}]
    },
{className:"Latvia",
axes: [
{axis:"Inflation",value:"4.401154401"},
{axis:"Deposit Interest Rate",value:"0.508333333"},
{axis:"Lending Interest Rate",value:"6.388333333"},
{axis:"Central Government Debt",value:"42.26558501"},
{axis:"GDP",value:"6.211500744"},
{axis:"Unemployment",value:"16.20000076"}]
    },
{className:"Macau",
axes: [
{axis:"Inflation",value:"5.801242236"},
{axis:"Deposit Interest Rate",value:"0.052698433"},
{axis:"Lending Interest Rate",value:"5.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"21.67259965"},
{axis:"Unemployment",value:"2.599999905"}]
    },
{className:"Morocco",
axes: [
{axis:"Inflation",value:"0.92236032"},
{axis:"Deposit Interest Rate",value:"3.756666667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"55.62772032"},
{axis:"GDP",value:"5.245697297"},
{axis:"Unemployment",value:"8.899999619"}]
    },
{className:"Monaco",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Moldova",
axes: [
{axis:"Inflation",value:"7.610607209"},
{axis:"Deposit Interest Rate",value:"7.572866801"},
{axis:"Lending Interest Rate",value:"14.43804379"},
{axis:"Central Government Debt",value:"23.70905587"},
{axis:"GDP",value:"6.414350738"},
{axis:"Unemployment",value:"6.699999809"}]
    },
{className:"Madagascar",
axes: [
{axis:"Inflation",value:"9.482540486"},
{axis:"Deposit Interest Rate",value:"10.65"},
{axis:"Lending Interest Rate",value:"52.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.454392168"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Maldives",
axes: [
{axis:"Inflation",value:"12.82983393"},
{axis:"Deposit Interest Rate",value:"4.173323546"},
{axis:"Lending Interest Rate",value:"10.19722195"},
{axis:"Central Government Debt",value:"64.89494844"},
{axis:"GDP",value:"8.70933893"},
{axis:"Unemployment",value:"11.60000038"}]
    },
{className:"Middle East and North Africa",
axes: [
{axis:"Inflation",value:"4.637464276"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.673683646"},
{axis:"Unemployment",value:"11.2162294"}]
    },
{className:"Mexico",
axes: [
{axis:"Inflation",value:"3.407379617"},
{axis:"Deposit Interest Rate",value:"0.955833333"},
{axis:"Lending Interest Rate",value:"4.915833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.044613879"},
{axis:"Unemployment",value:"5.300000191"}]
    },

{className:"Macedonia",
axes: [
{axis:"Inflation",value:"3.904754221"},
{axis:"Deposit Interest Rate",value:"5.911111739"},
{axis:"Lending Interest Rate",value:"8.868461255"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.339892284"},
{axis:"Unemployment",value:"31.39999962"}]
    },
{className:"Mali",
axes: [
{axis:"Inflation",value:"2.855534106"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.749889395"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Malta",
axes: [
{axis:"Inflation",value:"2.721905169"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"4.745833333"},
{axis:"Central Government Debt",value:"82.77014357"},
{axis:"GDP",value:"1.4"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Myanmar",
axes: [
{axis:"Inflation",value:"5.021460146"},
{axis:"Deposit Interest Rate",value:"11.33333333"},
{axis:"Lending Interest Rate",value:"16.33333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"Montenegro",
axes: [
{axis:"Inflation",value:"3.450143112"},
{axis:"Deposit Interest Rate",value:"3.132141667"},
{axis:"Lending Interest Rate",value:"9.686666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.228451021"},
{axis:"Unemployment",value:"19.70000076"}]
    },
{className:"Mongolia",
axes: [
{axis:"Inflation",value:"9.484093293"},
{axis:"Deposit Interest Rate",value:"10.47421065"},
{axis:"Lending Interest Rate",value:"16.60943645"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"17.29077735"},
{axis:"Unemployment",value:"4.800000191"}]
    },

{className:"Mozambique",
axes: [
{axis:"Inflation",value:"10.35113257"},
{axis:"Deposit Interest Rate",value:"12.98276515"},
{axis:"Lending Interest Rate",value:"19.09960595"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.117606632"},
{axis:"Unemployment",value:"22.60000038"}]
    },
{className:"Mauritania",
axes: [
{axis:"Inflation",value:"5.642433453"},
{axis:"Deposit Interest Rate",value:"8"},
{axis:"Lending Interest Rate",value:"17"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.704066531"},
{axis:"Unemployment",value:"31.10000038"}]
    },
{className:"Mauritius",
axes: [
{axis:"Inflation",value:"6.531353547"},
{axis:"Deposit Interest Rate",value:"7.108333333"},
{axis:"Lending Interest Rate",value:"8.916666667"},
{axis:"Central Government Debt",value:"50.8903412"},
{axis:"GDP",value:"3.889883083"},
{axis:"Unemployment",value:"7.900000095"}]
    },
{className:"Malawi",
axes: [
{axis:"Inflation",value:"7.622822628"},
{axis:"Deposit Interest Rate",value:"4.112847222"},
{axis:"Lending Interest Rate",value:"23.75"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.854055109"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Malaysia",
axes: [
{axis:"Inflation",value:"3.2"},
{axis:"Deposit Interest Rate",value:"2.910833333"},
{axis:"Lending Interest Rate",value:"4.915"},
{axis:"Central Government Debt",value:"50.02868164"},
{axis:"GDP",value:"5.293784657"},
{axis:"Unemployment",value:"3.099999905"}]
    },
{className:"North America",
axes: [
{axis:"Inflation",value:"3.034488329"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"71.02613292"},
{axis:"GDP",value:"1.749546391"},
{axis:"Unemployment",value:"8.827697734"}]
    },
{className:"Namibia",
axes: [
{axis:"Inflation",value:"5.005595181"},
{axis:"Deposit Interest Rate",value:"4.2825"},
{axis:"Lending Interest Rate",value:"8.73"},
{axis:"Central Government Debt",value:"35.53584057"},
{axis:"GDP",value:"5.091338198"},
{axis:"Unemployment",value:"19.79999924"}]
    },

{className:"Niger",
axes: [
{axis:"Inflation",value:"2.94238514"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.31140022"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Nigeria",
axes: [
{axis:"Inflation",value:"10.84079259"},
{axis:"Deposit Interest Rate",value:"5.699166667"},
{axis:"Lending Interest Rate",value:"16.01666667"},
{axis:"Central Government Debt",value:"10.23270482"},
{axis:"GDP",value:"4.887386611"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Nicaragua",
axes: [
{axis:"Inflation",value:"8.082672658"},
{axis:"Deposit Interest Rate",value:"1.846919177"},
{axis:"Lending Interest Rate",value:"10.53783509"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.231594567"},
{axis:"Unemployment",value:"7.800000191"}]
    },
{className:"Netherlands",
axes: [
{axis:"Inflation",value:"2.341070178"},
{axis:"Deposit Interest Rate",value:"2.606716667"},
{axis:"Lending Interest Rate",value:"2"},
{axis:"Central Government Debt",value:"62.42291139"},
{axis:"GDP",value:"1.663626344"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Norway",
axes: [
{axis:"Inflation",value:"1.300970874"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"20.27956574"},
{axis:"GDP",value:"0.96877971"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Nepal",
axes: [
{axis:"Inflation",value:"9.271714177"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.421828241"},
{axis:"Unemployment",value:"2.700000048"}]
    },
{className:"New Zealand",
axes: [
{axis:"Inflation",value:"4.432943294"},
{axis:"Deposit Interest Rate",value:"4.272055849"},
{axis:"Lending Interest Rate",value:"6.108832515"},
{axis:"Central Government Debt",value:"62.57318475"},
{axis:"GDP",value:"2.69189097"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Oman",
axes: [
{axis:"Inflation",value:"4.070057342"},
{axis:"Deposit Interest Rate",value:"2.799"},
{axis:"Lending Interest Rate",value:"6.189"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.091025209"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Pakistan",
axes: [
{axis:"Inflation",value:"11.91676947"},
{axis:"Deposit Interest Rate",value:"8.225833333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.74840255"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Panama",
axes: [
{axis:"Inflation",value:"5.875802437"},
{axis:"Deposit Interest Rate",value:"2.319166667"},
{axis:"Lending Interest Rate",value:"6.905833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.80806624"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Peru",
axes: [
{axis:"Inflation",value:"3.370685025"},
{axis:"Deposit Interest Rate",value:"2.328"},
{axis:"Lending Interest Rate",value:"18.677925"},
{axis:"Central Government Debt",value:"20.85979488"},
{axis:"GDP",value:"6.452216002"},
{axis:"Unemployment",value:"3.900000095"}]
    },
{className:"Philippines",
axes: [
{axis:"Inflation",value:"4.647302905"},
{axis:"Deposit Interest Rate",value:"3.387916667"},
{axis:"Lending Interest Rate",value:"6.66325"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.659755139"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Palau",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.042016807"},
{axis:"Unemployment",value:""}]
    },
{className:"Papua New Guinea",
axes: [
{axis:"Inflation",value:"4.44083401"},
{axis:"Deposit Interest Rate",value:"0.92"},
{axis:"Lending Interest Rate",value:"10.80833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.66932893"},
{axis:"Unemployment",value:"2.400000095"}]
    },
{className:"Poland",
axes: [
{axis:"Inflation",value:"4.258333333"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"51.57744021"},
{axis:"GDP",value:"5.008511757"},
{axis:"Unemployment",value:"9.600000381"}]
    },
{className:"Puerto Rico",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.890463033"},
{axis:"Unemployment",value:"15.80000019"}]
    },
{className:"Portugal",
axes: [
{axis:"Inflation",value:"3.653011004"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"102.4101745"},
{axis:"GDP",value:"-1.826852906"},
{axis:"Unemployment",value:"12.69999981"}]
    },
{className:"Paraguay",
axes: [
{axis:"Inflation",value:"8.253968254"},
{axis:"Deposit Interest Rate",value:"4.025"},
{axis:"Lending Interest Rate",value:"17.39805402"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.342407086"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Qatar",
axes: [
{axis:"Inflation",value:"1.916389889"},
{axis:"Deposit Interest Rate",value:"1.747837986"},
{axis:"Lending Interest Rate",value:"5.487058673"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"13.37517641"},
{axis:"Unemployment",value:"0.600000024"}]
    },
{className:"Romania",
axes: [
{axis:"Inflation",value:"5.78777738"},
{axis:"Deposit Interest Rate",value:"6.2975"},
{axis:"Lending Interest Rate",value:"12.1275"},
{axis:"Central Government Debt",value:"38.84623743"},
{axis:"GDP",value:"1.05629446"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Russian Federation",
axes: [
{axis:"Inflation",value:"8.428175946"},
{axis:"Deposit Interest Rate",value:"4.441666667"},
{axis:"Lending Interest Rate",value:"8.458333333"},
{axis:"Central Government Debt",value:"8.689386245"},
{axis:"GDP",value:"4.264176565"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Rwanda",
axes: [
{axis:"Inflation",value:"5.670682731"},
{axis:"Deposit Interest Rate",value:"7.96"},
{axis:"Lending Interest Rate",value:"16.73"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.851934941"},
{axis:"Unemployment",value:"0.600000024"}]
    },
{className:"South Asia",
axes: [
{axis:"Inflation",value:"9.736687159"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.321693763"},
{axis:"Unemployment",value:"3.821259793"}]
    },
{className:"Saudi Arabia",
axes: [
{axis:"Inflation",value:"5.823591056"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.95893281"},
{axis:"Unemployment",value:"5.800000191"}]
    },
{className:"Sudan",
axes: [
{axis:"Inflation",value:"22.11212074"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.967728979"},
{axis:"Unemployment",value:"14.60000038"}]
    },
{className:"Senegal",
axes: [
{axis:"Inflation",value:"3.403228298"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.761118048"},
{axis:"Unemployment",value:"10.39999962"}]
    },
{className:"Singapore",
axes: [
{axis:"Inflation",value:"5.252918288"},
{axis:"Deposit Interest Rate",value:"0.168333333"},
{axis:"Lending Interest Rate",value:"5.38"},
{axis:"Central Government Debt",value:"106.3576593"},
{axis:"GDP",value:"6.207448728"},
{axis:"Unemployment",value:"2.900000095"}]
    },
{className:"Solomon Islands",
axes: [
{axis:"Inflation",value:"7.34270706"},
{axis:"Deposit Interest Rate",value:"1.999815062"},
{axis:"Lending Interest Rate",value:"13.17238709"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"12.92847503"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Sierra Leone",
axes: [
{axis:"Inflation",value:"16.19180806"},
{axis:"Deposit Interest Rate",value:"10.31138889"},
{axis:"Lending Interest Rate",value:"21"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.268629628"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"El Salvador",
axes: [
{axis:"Inflation",value:"5.128923767"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"47.8298624"},
{axis:"GDP",value:"2.21683561"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"San Marino",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"1.0825"},
{axis:"Lending Interest Rate",value:"5.92"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Somalia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Serbia",
axes: [
{axis:"Inflation",value:"11.13739763"},
{axis:"Deposit Interest Rate",value:"9.76"},
{axis:"Lending Interest Rate",value:"17.17"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.401465736"},
{axis:"Unemployment",value:"23"}]
    },
{className:"Sao Tome and Principe",
axes: [
{axis:"Inflation",value:"14.32090217"},
{axis:"Deposit Interest Rate",value:"12.3575"},
{axis:"Lending Interest Rate",value:"26.95"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.828586114"},
{axis:"Unemployment",value:""}]
    },
{className:"Suriname",
axes: [
{axis:"Inflation",value:"17.71177964"},
{axis:"Deposit Interest Rate",value:"6.388802256"},
{axis:"Lending Interest Rate",value:"11.76110903"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.267209149"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Slovak Republic",
axes: [
{axis:"Inflation",value:"3.919285991"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"47.05895267"},
{axis:"GDP",value:"2.841938591"},
{axis:"Unemployment",value:"13.5"}]
    },
{className:"Slovenia",
axes: [
{axis:"Inflation",value:"1.810579921"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.64933632"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Sweden",
axes: [
{axis:"Inflation",value:"2.961150738"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"42.81646469"},
{axis:"GDP",value:"2.664407951"},
{axis:"Unemployment",value:"7.800000191"}]
    },
{className:"Swaziland",
axes: [
{axis:"Inflation",value:"6.105198202"},
{axis:"Deposit Interest Rate",value:"2.85"},
{axis:"Lending Interest Rate",value:"9"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.327171792"},
{axis:"Unemployment",value:"22.70000076"}]
    },
{className:"Seychelles",
axes: [
{axis:"Inflation",value:"2.559267722"},
{axis:"Deposit Interest Rate",value:"2.08331762"},
{axis:"Lending Interest Rate",value:"11.18993449"},
{axis:"Central Government Debt",value:"78.84131555"},
{axis:"GDP",value:"7.887279597"},
{axis:"Unemployment",value:""}]
    },
{className:"Syrian Arab Republic",
axes: [
{axis:"Inflation",value:"4.753163889"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"11.5"}]
    },
{className:"Chad",
axes: [
{axis:"Inflation",value:"-3.704295704"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.082869798"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"East Asia and Pacific (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"5.410850058"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.441376602"},
{axis:"Unemployment",value:"4.333355725"}]
    },
{className:"Europe and Central Asia (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"7.651233638"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.204993583"},
{axis:"Unemployment",value:"8.590843598"}]
    },
{className:"Togo",
axes: [
{axis:"Inflation",value:"3.572277228"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.883763946"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Thailand",
axes: [
{axis:"Inflation",value:"3.809820409"},
{axis:"Deposit Interest Rate",value:"2.2775"},
{axis:"Lending Interest Rate",value:"6.914166667"},
{axis:"Central Government Debt",value:"28.14796105"},
{axis:"GDP",value:"0.833682448"},
{axis:"Unemployment",value:"0.699999988"}]
    },
{className:"Tajikistan",
axes: [
{axis:"Inflation",value:"12.43154904"},
{axis:"Deposit Interest Rate",value:"8.23675339"},
{axis:"Lending Interest Rate",value:"22.46166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.399999383"},
{axis:"Unemployment",value:"11.39999962"}]
    },
{className:"Turkmenistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"14.69999993"},
{axis:"Unemployment",value:"11"}]
    },
{className:"Latin America and the Caribbean (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"5.482044481"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.53196387"},
{axis:"Unemployment",value:"6.687505198"}]
    },
{className:"Middle East and North Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"5.068713948"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.703180977"},
{axis:"Unemployment",value:"12.59767658"}]
    },
{className:"Timor-Leste",
axes: [
{axis:"Inflation",value:"13.49984024"},
{axis:"Deposit Interest Rate",value:"0.846122689"},
{axis:"Lending Interest Rate",value:"11.0429658"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.528907923"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Tonga",
axes: [
{axis:"Inflation",value:"6.261404365"},
{axis:"Deposit Interest Rate",value:"3.916666667"},
{axis:"Lending Interest Rate",value:"11.37193906"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.01912478"},
{axis:"Unemployment",value:""}]
    },
{className:"South Asia (IDA and IBRD)",
axes: [
{axis:"Inflation",value:"9.736687159"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.321693763"},
{axis:"Unemployment",value:"3.821259793"}]
    },
{className:"Sub-Saharan Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"5.656558092"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.302969722"},
{axis:"Unemployment",value:"8.118308838"}]
    },
{className:"Trinidad and Tobago",
axes: [
{axis:"Inflation",value:"5.099366154"},
{axis:"Deposit Interest Rate",value:"1.5"},
{axis:"Lending Interest Rate",value:"7.969166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.006985199"},
{axis:"Unemployment",value:"4.699999809"}]
    },
{className:"Tunisia",
axes: [
{axis:"Inflation",value:"3.544029353"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"44.62477633"},
{axis:"GDP",value:"-2.383918674"},
{axis:"Unemployment",value:"18.29999924"}]
    },
{className:"Turkey",
axes: [
{axis:"Inflation",value:"6.471879671"},
{axis:"Deposit Interest Rate",value:"14.21666667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"45.51868587"},
{axis:"GDP",value:"8.772746296"},
{axis:"Unemployment",value:"9.800000191"}]
    },
{className:"Tuvalu",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.453323926"},
{axis:"Unemployment",value:""}]
    },
{className:"Tanzania",
axes: [
{axis:"Inflation",value:"12.69096947"},
{axis:"Deposit Interest Rate",value:"6.777015037"},
{axis:"Lending Interest Rate",value:"14.96187317"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.904507572"},
{axis:"Unemployment",value:"3.5"}]
    },
{className:"Uganda",
axes: [
{axis:"Inflation",value:"18.69290448"},
{axis:"Deposit Interest Rate",value:"13.0184248"},
{axis:"Lending Interest Rate",value:"21.83318937"},
{axis:"Central Government Debt",value:"35.43992181"},
{axis:"GDP",value:"9.673224959"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Ukraine",
axes: [
{axis:"Inflation",value:"7.960094513"},
{axis:"Deposit Interest Rate",value:"7.898358333"},
{axis:"Lending Interest Rate",value:"15.947225"},
{axis:"Central Government Debt",value:"27.4827595"},
{axis:"GDP",value:"5.200000009"},
{axis:"Unemployment",value:"7.900000095"}]
    },
{className:"Uruguay",
axes: [
{axis:"Inflation",value:"8.093775202"},
{axis:"Deposit Interest Rate",value:"4.554631228"},
{axis:"Lending Interest Rate",value:"9.781820742"},
{axis:"Central Government Debt",value:"45.35145122"},
{axis:"GDP",value:"5.162133022"},
{axis:"Unemployment",value:"6.300000191"}]
    },
{className:"United States",
axes: [
{axis:"Inflation",value:"3.156841569"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"3.25"},
{axis:"Central Government Debt",value:"90.16212605"},
{axis:"GDP",value:"1.601454672"},
{axis:"Unemployment",value:"9"}]
    },
{className:"Uzbekistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.3"},
{axis:"Unemployment",value:"10.89999962"}]
    },
{className:"St Vincent and the Grenadines",
axes: [
{axis:"Inflation",value:"3.186031116"},
{axis:"Deposit Interest Rate",value:"2.99205474"},
{axis:"Lending Interest Rate",value:"9.136378053"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.423644081"},
{axis:"Unemployment",value:""}]
    },
{className:"Venezuela",
axes: [
{axis:"Inflation",value:"26.09021232"},
{axis:"Deposit Interest Rate",value:"14.59"},
{axis:"Lending Interest Rate",value:"17.15"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.176425359"},
{axis:"Unemployment",value:"8.300000191"}]
    },
{className:"Vietnam",
axes: [
{axis:"Inflation",value:"18.67747712"},
{axis:"Deposit Interest Rate",value:"13.9935"},
{axis:"Lending Interest Rate",value:"16.95383333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.240302749"},
{axis:"Unemployment",value:"2"}]
    },
{className:"Vanuatu",
axes: [
{axis:"Inflation",value:"0.862682908"},
{axis:"Deposit Interest Rate",value:"1.5"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.223225535"},
{axis:"Unemployment",value:""}]
    },
{className:"West Bank and Gaza",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.529070554"},
{axis:"Lending Interest Rate",value:"6.786607607"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.835718182"},
{axis:"Unemployment",value:"21"}]
    },
{className:"World",
axes: [
{axis:"Inflation",value:"4.995510185"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.112093489"},
{axis:"Unemployment",value:"5.9946901"}]
    },
{className:"Samoa",
axes: [
{axis:"Inflation",value:"5.198142928"},
{axis:"Deposit Interest Rate",value:"2.285"},
{axis:"Lending Interest Rate",value:"9.9625"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.778544297"},
{axis:"Unemployment",value:""}]
    },
{className:"Yemen",
axes: [
{axis:"Inflation",value:"19.54356171"},
{axis:"Deposit Interest Rate",value:"20"},
{axis:"Lending Interest Rate",value:"25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-15.08839309"},
{axis:"Unemployment",value:"17.60000038"}]
    },
{className:"South Africa",
axes: [
{axis:"Inflation",value:"4.995510185"},
{axis:"Deposit Interest Rate",value:"5.6725"},
{axis:"Lending Interest Rate",value:"9"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.212451755"},
{axis:"Unemployment",value:"24.70000076"}]
    },
{className:"Democratic Republic of the Congo",
axes: [
{axis:"Inflation",value:"15.31651591"},
{axis:"Deposit Interest Rate",value:"13.35666667"},
{axis:"Lending Interest Rate",value:"43.75340275"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.864630026"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Zambia",
axes: [
{axis:"Inflation",value:"6.429396811"},
{axis:"Deposit Interest Rate",value:"7.0234"},
{axis:"Lending Interest Rate",value:"18.8368243"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.615583296"},
{axis:"Unemployment",value:"13.19999981"}]
    },
{className:"Zimbabwe",
axes: [
{axis:"Inflation",value:"3.277509412"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.90540789"},
{axis:"Unemployment",value:"5.400000095"}]
    }
],
["2012",
{className:"Aruba",
axes: [
{axis:"Inflation",value:"0.571755528"},
{axis:"Deposit Interest Rate",value:"1.541666667"},
{axis:"Lending Interest Rate",value:"9.183333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Andorra",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.760010328"},
{axis:"Unemployment",value:""}]
    },
{className:"Afghanistan",
axes: [
{axis:"Inflation",value:"7.218257761"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"15"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"14.43474129"},
{axis:"Unemployment",value:"8.5"}]
    },
{className:"Angola",
axes: [
{axis:"Inflation",value:"10.29349433"},
{axis:"Deposit Interest Rate",value:"3.603640267"},
{axis:"Lending Interest Rate",value:"16.65640132"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.155440545"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Albania",
axes: [
{axis:"Inflation",value:"2.03159594"},
{axis:"Deposit Interest Rate",value:"5.424908481"},
{axis:"Lending Interest Rate",value:"10.88034654"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.419999998"},
{axis:"Unemployment",value:"13.89999962"}]
    },
{className:"United Arab Emirates",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.893595623"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Argentina",
axes: [
{axis:"Inflation",value:"10.03025902"},
{axis:"Deposit Interest Rate",value:"12.02349546"},
{axis:"Lending Interest Rate",value:"14.06083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.05287445"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Armenia",
axes: [
{axis:"Inflation",value:"2.5554709"},
{axis:"Deposit Interest Rate",value:"9.569110014"},
{axis:"Lending Interest Rate",value:"17.23006824"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.200000003"},
{axis:"Unemployment",value:"17.29999924"}]
    },
{className:"Antigua and Barbuda",
axes: [
{axis:"Inflation",value:"3.376880443"},
{axis:"Deposit Interest Rate",value:"3.160430616"},
{axis:"Lending Interest Rate",value:"10.15719664"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.019541839"},
{axis:"Unemployment",value:""}]
    },
{className:"Australia",
axes: [
{axis:"Inflation",value:"1.762780156"},
{axis:"Deposit Interest Rate",value:"3.916666667"},
{axis:"Lending Interest Rate",value:"6.975"},
{axis:"Central Government Debt",value:"40.40963051"},
{axis:"GDP",value:"3.632720303"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"Austria",
axes: [
{axis:"Inflation",value:"2.485675087"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"85.38330569"},
{axis:"GDP",value:"0.757314346"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Azerbaijan",
axes: [
{axis:"Inflation",value:"1.014109821"},
{axis:"Deposit Interest Rate",value:"10.215"},
{axis:"Lending Interest Rate",value:"18.34583333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.200000188"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"Burundi",
axes: [
{axis:"Inflation",value:"18.01281606"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"14.32"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.01936553"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Belgium",
axes: [
{axis:"Inflation",value:"2.839663434"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"103.8064183"},
{axis:"GDP",value:"0.158656858"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Benin",
axes: [
{axis:"Inflation",value:"6.753123517"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.643023076"},
{axis:"Unemployment",value:"1"}]
    },
{className:"Burkina Faso",
axes: [
{axis:"Inflation",value:"3.818152403"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.452674754"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Bangladesh",
axes: [
{axis:"Inflation",value:"6.21818237"},
{axis:"Deposit Interest Rate",value:"10.21583333"},
{axis:"Lending Interest Rate",value:"13.94416667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.521435078"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Bulgaria",
axes: [
{axis:"Inflation",value:"2.954568298"},
{axis:"Deposit Interest Rate",value:"3.084166667"},
{axis:"Lending Interest Rate",value:"9.714208333"},
{axis:"Central Government Debt",value:"17.20211519"},
{axis:"GDP",value:"0.23707389"},
{axis:"Unemployment",value:"12.30000019"}]
    },
{className:"Bahrain",
axes: [
{axis:"Inflation",value:"2.754553598"},
{axis:"Deposit Interest Rate",value:"1.084166667"},
{axis:"Lending Interest Rate",value:"6.035"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.588704571"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"The Bahamas",
axes: [
{axis:"Inflation",value:"1.984598107"},
{axis:"Deposit Interest Rate",value:"2.012083333"},
{axis:"Lending Interest Rate",value:"4.75"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.217312979"},
{axis:"Unemployment",value:"14"}]
    },
{className:"Bosnia and Herzegovina",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"3.177333333"},
{axis:"Lending Interest Rate",value:"7.328916667"},
{axis:"Central Government Debt",value:"47.78280607"},
{axis:"GDP",value:"-0.933187606"},
{axis:"Unemployment",value:"28.10000038"}]
    },
{className:"Belarus",
axes: [
{axis:"Inflation",value:"59.21973602"},
{axis:"Deposit Interest Rate",value:"22.3"},
{axis:"Lending Interest Rate",value:"19.49166667"},
{axis:"Central Government Debt",value:"25.22436458"},
{axis:"GDP",value:"1.731391223"},
{axis:"Unemployment",value:"5.900000095"}]
    },
{className:"Belize",
axes: [
{axis:"Inflation",value:"1.300606735"},
{axis:"Deposit Interest Rate",value:"4.4125"},
{axis:"Lending Interest Rate",value:"12.44083333"},
{axis:"Central Government Debt",value:"74.48290763"},
{axis:"GDP",value:"3.740823332"},
{axis:"Unemployment",value:"14.39999962"}]
    },
{className:"Bermuda",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.834540171"},
{axis:"Unemployment",value:""}]
    },
{className:"Bolivia",
axes: [
{axis:"Inflation",value:"4.586374696"},
{axis:"Deposit Interest Rate",value:"1.626153071"},
{axis:"Lending Interest Rate",value:"11.13494786"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.122274661"},
{axis:"Unemployment",value:"2.700000048"}]
    },
{className:"Brazil",
axes: [
{axis:"Inflation",value:"5.40196475"},
{axis:"Deposit Interest Rate",value:"7.907466502"},
{axis:"Lending Interest Rate",value:"36.63666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.915458623"},
{axis:"Unemployment",value:"6.099999905"}]
    },
{className:"Barbados",
axes: [
{axis:"Inflation",value:"4.533347539"},
{axis:"Deposit Interest Rate",value:"2.5625"},
{axis:"Lending Interest Rate",value:"8.7"},
{axis:"Central Government Debt",value:"120.5418985"},
{axis:"GDP",value:"0.27124774"},
{axis:"Unemployment",value:"11.60000038"}]
    },
{className:"Brunei Darussalam",
axes: [
{axis:"Inflation",value:"0.464102858"},
{axis:"Deposit Interest Rate",value:"0.231540741"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.948354662"},
{axis:"Unemployment",value:"3.799999952"}]
    },
{className:"Bhutan",
axes: [
{axis:"Inflation",value:"10.91965694"},
{axis:"Deposit Interest Rate",value:"5.5"},
{axis:"Lending Interest Rate",value:"14"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.071709815"},
{axis:"Unemployment",value:"2.099999905"}]
    },
{className:"Botswana",
axes: [
{axis:"Inflation",value:"7.540284094"},
{axis:"Deposit Interest Rate",value:"3.6075875"},
{axis:"Lending Interest Rate",value:"11"},
{axis:"Central Government Debt",value:"18.85035211"},
{axis:"GDP",value:"4.456466273"},
{axis:"Unemployment",value:"17.70000076"}]
    },
{className:"Central African Republic",
axes: [
{axis:"Inflation",value:"5.772250594"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.898540636"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Canada",
axes: [
{axis:"Inflation",value:"1.515678231"},
{axis:"Deposit Interest Rate",value:"0.483333333"},
{axis:"Lending Interest Rate",value:"3"},
{axis:"Central Government Debt",value:"52.34928747"},
{axis:"GDP",value:"1.745472283"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Central Europe and the Baltics",
axes: [
{axis:"Inflation",value:"3.333800252"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"41.59453671"},
{axis:"GDP",value:"0.541375878"},
{axis:"Unemployment",value:"9.988800216"}]
    },
{className:"Switzerland",
axes: [
{axis:"Inflation",value:"-0.692544621"},
{axis:"Deposit Interest Rate",value:"0.03"},
{axis:"Lending Interest Rate",value:"2.688333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.124629311"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Chile",
axes: [
{axis:"Inflation",value:"3.006520356"},
{axis:"Deposit Interest Rate",value:"5.788217689"},
{axis:"Lending Interest Rate",value:"10.05726244"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.45713061"},
{axis:"Unemployment",value:"6.400000095"}]
    },
{className:"China",
axes: [
{axis:"Inflation",value:"2.624920936"},
{axis:"Deposit Interest Rate",value:"3"},
{axis:"Lending Interest Rate",value:"6"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.750297593"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Cote dIvoire",
axes: [
{axis:"Inflation",value:"1.304511199"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.7065041"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Cameroon",
axes: [
{axis:"Inflation",value:"2.942510001"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.588738701"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Republic of Congo",
axes: [
{axis:"Inflation",value:"3.89014729"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.799995854"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"Colombia",
axes: [
{axis:"Inflation",value:"3.176934374"},
{axis:"Deposit Interest Rate",value:"5.355833839"},
{axis:"Lending Interest Rate",value:"12.5850402"},
{axis:"Central Government Debt",value:"65.45031298"},
{axis:"GDP",value:"4.043943806"},
{axis:"Unemployment",value:"10.60000038"}]
    },
{className:"Comoros",
axes: [
{axis:"Inflation",value:"1.768907098"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"10.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.999999972"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Cabo Verde",
axes: [
{axis:"Inflation",value:"2.543293964"},
{axis:"Deposit Interest Rate",value:"3.78753893"},
{axis:"Lending Interest Rate",value:"9.900358847"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.081918311"},
{axis:"Unemployment",value:"9.100000381"}]
    },
{className:"Costa Rica",
axes: [
{axis:"Inflation",value:"4.504067692"},
{axis:"Deposit Interest Rate",value:"4.738611111"},
{axis:"Lending Interest Rate",value:"18.2125"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.167582778"},
{axis:"Unemployment",value:"7.800000191"}]
    },
{className:"Caribbean small states",
axes: [
{axis:"Inflation",value:"2.598444141"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.195900394"},
{axis:"Unemployment",value:"10.89304275"}]
    },
{className:"Cuba",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.014390465"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Cyprus",
axes: [
{axis:"Inflation",value:"2.389768958"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"119.5609113"},
{axis:"GDP",value:"-2.448049655"},
{axis:"Unemployment",value:"11.80000019"}]
    },
{className:"Czech Republic",
axes: [
{axis:"Inflation",value:"3.299073139"},
{axis:"Deposit Interest Rate",value:"1.024302633"},
{axis:"Lending Interest Rate",value:"5.406723237"},
{axis:"Central Government Debt",value:"40.82348997"},
{axis:"GDP",value:"-0.900306692"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Germany",
axes: [
{axis:"Inflation",value:"2.008491182"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"55.22785187"},
{axis:"GDP",value:"0.405170675"},
{axis:"Unemployment",value:"5.400000095"}]
    },
{className:"Djibouti",
axes: [
{axis:"Inflation",value:"3.731209508"},
{axis:"Deposit Interest Rate",value:"2.3375"},
{axis:"Lending Interest Rate",value:"11.98875"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.842379573"},
{axis:"Unemployment",value:""}]
    },
{className:"Dominica",
axes: [
{axis:"Inflation",value:"1.356771478"},
{axis:"Deposit Interest Rate",value:"3.098115385"},
{axis:"Lending Interest Rate",value:"9.042981869"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.256281407"},
{axis:"Unemployment",value:""}]
    },
{className:"Denmark",
axes: [
{axis:"Inflation",value:"2.397914857"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"48.95558064"},
{axis:"GDP",value:"-0.073322003"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Dominican Republic",
axes: [
{axis:"Inflation",value:"3.694524905"},
{axis:"Deposit Interest Rate",value:"7.494166667"},
{axis:"Lending Interest Rate",value:"15.4825"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.629506212"},
{axis:"Unemployment",value:"14.69999981"}]
    },
{className:"Algeria",
axes: [
{axis:"Inflation",value:"8.894585294"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.4"},
{axis:"Unemployment",value:"11"}]
    },
{className:"East Asia and Pacific (excluding high income)",
axes: [
{axis:"Inflation",value:"3.172085646"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.42911771"},
{axis:"Unemployment",value:"4.407660581"}]
    },
{className:"East Asia and Pacific",
axes: [
{axis:"Inflation",value:"3.02"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.721651041"},
{axis:"Unemployment",value:"4.381289652"}]
    },
{className:"Europe and Central Asia (excluding high income)",
axes: [
{axis:"Inflation",value:"3.333800252"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.850857383"},
{axis:"Unemployment",value:"7.88744329"}]
    },
{className:"Europe and Central Asia",
axes: [
{axis:"Inflation",value:"2.808332326"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"50.71044111"},
{axis:"GDP",value:"0.127501391"},
{axis:"Unemployment",value:"9.295200017"}]
    },
{className:"Ecuador",
axes: [
{axis:"Inflation",value:"5.10065348"},
{axis:"Deposit Interest Rate",value:"3.89"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.641962067"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Egypt",
axes: [
{axis:"Inflation",value:"7.11815562"},
{axis:"Deposit Interest Rate",value:"7.641666667"},
{axis:"Lending Interest Rate",value:"12"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.193878354"},
{axis:"Unemployment",value:"12.69999981"}]
    },
{className:"Eritrea",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Spain",
axes: [
{axis:"Inflation",value:"2.445914628"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"83.45094621"},
{axis:"GDP",value:"-2.620308512"},
{axis:"Unemployment",value:"25.20000076"}]
    },
{className:"Estonia",
axes: [
{axis:"Inflation",value:"3.934921578"},
{axis:"Deposit Interest Rate",value:"0.674082106"},
{axis:"Lending Interest Rate",value:"5.747075316"},
{axis:"Central Government Debt",value:"0.625414512"},
{axis:"GDP",value:"5.182578141"},
{axis:"Unemployment",value:"10.10000038"}]
    },
{className:"Ethiopia",
axes: [
{axis:"Inflation",value:"22.77046088"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.647811635"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"European Union",
axes: [
{axis:"Inflation",value:"2.718769044"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"61.88211201"},
{axis:"GDP",value:"-0.47714182"},
{axis:"Unemployment",value:"10.5091318"}]
    },
{className:"Finland",
axes: [
{axis:"Inflation",value:"2.808332326"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"52.46530159"},
{axis:"GDP",value:"-1.42618936"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Fiji",
axes: [
{axis:"Inflation",value:"3.408333333"},
{axis:"Deposit Interest Rate",value:"2.420165169"},
{axis:"Lending Interest Rate",value:"6.968052878"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.634990386"},
{axis:"Unemployment",value:"8.5"}]
    },
{className:"France",
axes: [
{axis:"Inflation",value:"1.9556855"},
{axis:"Deposit Interest Rate",value:"2.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"88.92396435"},
{axis:"GDP",value:"0.182693034"},
{axis:"Unemployment",value:"9.899999619"}]
    },
{className:"Federal States of Micronesia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.415833333"},
{axis:"Lending Interest Rate",value:"14.32"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.564168715"},
{axis:"Unemployment",value:""}]
    },
{className:"Gabon",
axes: [
{axis:"Inflation",value:"2.661784381"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.251076918"},
{axis:"Unemployment",value:"20.29999924"}]
    },
{className:"United Kingdom",
axes: [
{axis:"Inflation",value:"2.821709747"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"0.5"},
{axis:"Central Government Debt",value:"101.9509216"},
{axis:"GDP",value:"1.179056123"},
{axis:"Unemployment",value:"8"}]
    },
{className:"Georgia",
axes: [
{axis:"Inflation",value:"-0.943658853"},
{axis:"Deposit Interest Rate",value:"10.70552012"},
{axis:"Lending Interest Rate",value:"14.80845"},
{axis:"Central Government Debt",value:"32.53069811"},
{axis:"GDP",value:"6.350481944"},
{axis:"Unemployment",value:"15"}]
    },
{className:"Ghana",
axes: [
{axis:"Inflation",value:"9.160778311"},
{axis:"Deposit Interest Rate",value:"10.05"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.292511869"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Guinea",
axes: [
{axis:"Inflation",value:"15.22455748"},
{axis:"Deposit Interest Rate",value:"16.73333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.944111989"},
{axis:"Unemployment",value:"1.700000048"}]
    },
{className:"Gambia",
axes: [
{axis:"Inflation",value:"4.254534775"},
{axis:"Deposit Interest Rate",value:"11.5"},
{axis:"Lending Interest Rate",value:"28"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.862230311"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Guinea-Bissau",
axes: [
{axis:"Inflation",value:"2.130545803"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.798000803"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Equatorial Guinea",
axes: [
{axis:"Inflation",value:"0.988828502"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.747235995"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Greece",
axes: [
{axis:"Inflation",value:"1.501519795"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"165.4777894"},
{axis:"GDP",value:"-7.300493935"},
{axis:"Unemployment",value:"24.20000076"}]
    },
{className:"Grenada",
axes: [
{axis:"Inflation",value:"2.41077704"},
{axis:"Deposit Interest Rate",value:"2.858128653"},
{axis:"Lending Interest Rate",value:"9.725900007"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.155295176"},
{axis:"Unemployment",value:""}]
    },
{className:"Greenland",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Guatemala",
axes: [
{axis:"Inflation",value:"3.78250024"},
{axis:"Deposit Interest Rate",value:"5.293333333"},
{axis:"Lending Interest Rate",value:"13.48666667"},
{axis:"Central Government Debt",value:"24.31127359"},
{axis:"GDP",value:"2.969857427"},
{axis:"Unemployment",value:"2.900000095"}]
    },
{className:"Guyana",
axes: [
{axis:"Inflation",value:"2.391935213"},
{axis:"Deposit Interest Rate",value:"1.523125"},
{axis:"Lending Interest Rate",value:"13.86111111"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.816458917"},
{axis:"Unemployment",value:"11.19999981"}]
    },
{className:"Hong Kong",
axes: [
{axis:"Inflation",value:"4.056603774"},
{axis:"Deposit Interest Rate",value:"0.01"},
{axis:"Lending Interest Rate",value:"5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.700302663"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Honduras",
axes: [
{axis:"Inflation",value:"5.196186155"},
{axis:"Deposit Interest Rate",value:"8.934915"},
{axis:"Lending Interest Rate",value:"18.45069917"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.128687749"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Croatia",
axes: [
{axis:"Inflation",value:"3.412073491"},
{axis:"Deposit Interest Rate",value:"1.881666667"},
{axis:"Lending Interest Rate",value:"9.480833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.187429172"},
{axis:"Unemployment",value:"15.80000019"}]
    },
{className:"Haiti",
axes: [
{axis:"Inflation",value:"6.279665496"},
{axis:"Deposit Interest Rate",value:"0.454166667"},
{axis:"Lending Interest Rate",value:"8.934166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.885096051"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Hungary",
axes: [
{axis:"Inflation",value:"5.667639606"},
{axis:"Deposit Interest Rate",value:"5.293175033"},
{axis:"Lending Interest Rate",value:"9.001544511"},
{axis:"Central Government Debt",value:"94.28021046"},
{axis:"GDP",value:"-1.688895103"},
{axis:"Unemployment",value:"10.89999962"}]
    },
{className:"Indonesia",
axes: [
{axis:"Inflation",value:"4.279511959"},
{axis:"Deposit Interest Rate",value:"5.946666667"},
{axis:"Lending Interest Rate",value:"11.795"},
{axis:"Central Government Debt",value:"25.03435411"},
{axis:"GDP",value:"6.030050653"},
{axis:"Unemployment",value:"6.099999905"}]
    },
{className:"India",
axes: [
{axis:"Inflation",value:"9.312445605"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"10.60416667"},
{axis:"Central Government Debt",value:"50.49941837"},
{axis:"GDP",value:"5.618562773"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Ireland",
axes: [
{axis:"Inflation",value:"1.692784715"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"130.4947733"},
{axis:"GDP",value:"0.151117554"},
{axis:"Unemployment",value:"14.69999981"}]
    },
{className:"Iran",
axes: [
{axis:"Inflation",value:"27.35738864"},
{axis:"Deposit Interest Rate",value:"14.81184302"},
{axis:"Lending Interest Rate",value:"11"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-6.608687255"},
{axis:"Unemployment",value:"13.10000038"}]
    },
{className:"Iraq",
axes: [
{axis:"Inflation",value:"6.089096416"},
{axis:"Deposit Interest Rate",value:"5.874166667"},
{axis:"Lending Interest Rate",value:"13.03416667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"13.93643017"},
{axis:"Unemployment",value:"15.19999981"}]
    },
{className:"Iceland",
axes: [
{axis:"Inflation",value:"5.1952906"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"8.324338772"},
{axis:"Central Government Debt",value:"112.5040316"},
{axis:"GDP",value:"1.182931611"},
{axis:"Unemployment",value:"6"}]
    },
{className:"Israel",
axes: [
{axis:"Inflation",value:"1.70761176"},
{axis:"Deposit Interest Rate",value:"1.922999"},
{axis:"Lending Interest Rate",value:"5.2274606"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.85774521"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Italy",
axes: [
{axis:"Inflation",value:"3.04136253"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"5.2225"},
{axis:"Central Government Debt",value:"127.0359206"},
{axis:"GDP",value:"-2.819019127"},
{axis:"Unemployment",value:"10.69999981"}]
    },
{className:"Jamaica",
axes: [
{axis:"Inflation",value:"6.898248186"},
{axis:"Deposit Interest Rate",value:"3.532718757"},
{axis:"Lending Interest Rate",value:"17.62827224"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.603505605"},
{axis:"Unemployment",value:"13.69999981"}]
    },
{className:"Jordan",
axes: [
{axis:"Inflation",value:"4.520361629"},
{axis:"Deposit Interest Rate",value:"3.771666667"},
{axis:"Lending Interest Rate",value:"8.780833333"},
{axis:"Central Government Debt",value:"66.82352774"},
{axis:"GDP",value:"2.651203349"},
{axis:"Unemployment",value:"12.19999981"}]
    },
{className:"Japan",
axes: [
{axis:"Inflation",value:"-0.033428046"},
{axis:"Deposit Interest Rate",value:"0.478"},
{axis:"Lending Interest Rate",value:"1.4075"},
{axis:"Central Government Debt",value:"195.4721303"},
{axis:"GDP",value:"1.742200425"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Kazakhstan",
axes: [
{axis:"Inflation",value:"5.113708884"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.6"},
{axis:"Unemployment",value:"5.300000191"}]
    },
{className:"Kenya",
axes: [
{axis:"Inflation",value:"9.378395851"},
{axis:"Deposit Interest Rate",value:"11.57214466"},
{axis:"Lending Interest Rate",value:"19.72340665"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.554942796"},
{axis:"Unemployment",value:"9.199999809"}]
    },
{className:"Kyrgyz Republic",
axes: [
{axis:"Inflation",value:"2.687027306"},
{axis:"Deposit Interest Rate",value:"2.552659372"},
{axis:"Lending Interest Rate",value:"23.89862506"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.088150193"},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"Cambodia",
axes: [
{axis:"Inflation",value:"2.932724618"},
{axis:"Deposit Interest Rate",value:"1.333796296"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.261322743"},
{axis:"Unemployment",value:"0.200000003"}]
    },
{className:"St Kitts and Nevis",
axes: [
{axis:"Inflation",value:"0.816089282"},
{axis:"Deposit Interest Rate",value:"4.274618507"},
{axis:"Lending Interest Rate",value:"8.733988854"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.225697239"},
{axis:"Unemployment",value:""}]
    },
{className:"South Korea",
axes: [
{axis:"Inflation",value:"2.192307692"},
{axis:"Deposit Interest Rate",value:"3.700833333"},
{axis:"Lending Interest Rate",value:"5.395833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.292382426"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Kosovo",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"3.72"},
{axis:"Lending Interest Rate",value:"12.24"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.808457654"},
{axis:"Unemployment",value:""}]
    },
{className:"Kuwait",
axes: [
{axis:"Inflation",value:"3.199343724"},
{axis:"Deposit Interest Rate",value:"2.0418"},
{axis:"Lending Interest Rate",value:"4.983791667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.626388081"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"Latin America and Caribbean (excluding high income)",
axes: [
{axis:"Inflation",value:"4.177635871"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.812391478"},
{axis:"Unemployment",value:"6.205162037"}]
    },
{className:"Lao PDR",
axes: [
{axis:"Inflation",value:"4.256942205"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.024211032"},
{axis:"Unemployment",value:"1.399999976"}]
    },
{className:"Lebanon",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"5.7725"},
{axis:"Lending Interest Rate",value:"7.249166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.199999964"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"Liberia",
axes: [
{axis:"Inflation",value:"6.834768221"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:"13.51833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.99445127"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Libya",
axes: [
{axis:"Inflation",value:"6.059803922"},
{axis:"Deposit Interest Rate",value:"2.5"},
{axis:"Lending Interest Rate",value:"6"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"104.4867889"},
{axis:"Unemployment",value:"19.20000076"}]
    },
{className:"St Lucia",
axes: [
{axis:"Inflation",value:"4.177635871"},
{axis:"Deposit Interest Rate",value:"3.058053834"},
{axis:"Lending Interest Rate",value:"9.50031902"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.056272321"},
{axis:"Unemployment",value:""}]
    },
{className:"Latin America and Caribbean",
axes: [
{axis:"Inflation",value:"4.111508546"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.821862931"},
{axis:"Unemployment",value:"6.253372163"}]
    },
{className:"Liechtenstein",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Sri Lanka",
axes: [
{axis:"Inflation",value:"7.542913732"},
{axis:"Deposit Interest Rate",value:"10.5"},
{axis:"Lending Interest Rate",value:"10.5"},
{axis:"Central Government Debt",value:"68.71042783"},
{axis:"GDP",value:"9.144579388"},
{axis:"Unemployment",value:"4"}]
    },

{className:"Lesotho",
axes: [
{axis:"Inflation",value:"6.1035928"},
{axis:"Deposit Interest Rate",value:"2.85"},
{axis:"Lending Interest Rate",value:"10.11916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.993621287"},
{axis:"Unemployment",value:"27.20000076"}]
    },
{className:"Lithuania",
axes: [
{axis:"Inflation",value:"3.086963828"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"46.99984111"},
{axis:"GDP",value:"3.835604582"},
{axis:"Unemployment",value:"13.19999981"}]
    },
{className:"Luxembourg",
axes: [
{axis:"Inflation",value:"2.664199548"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"20.14661994"},
{axis:"GDP",value:"-0.847072985"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Latvia",
axes: [
{axis:"Inflation",value:"2.211472011"},
{axis:"Deposit Interest Rate",value:"0.3675"},
{axis:"Lending Interest Rate",value:"5.5175"},
{axis:"Central Government Debt",value:"41.59453671"},
{axis:"GDP",value:"4.005234456"},
{axis:"Unemployment",value:"14.89999962"}]
    },
{className:"Macau",
axes: [
{axis:"Inflation",value:"6.105436186"},
{axis:"Deposit Interest Rate",value:"0.062807192"},
{axis:"Lending Interest Rate",value:"5.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.229711564"},
{axis:"Unemployment",value:"2"}]
    },
{className:"Morocco",
axes: [
{axis:"Inflation",value:"1.278741213"},
{axis:"Deposit Interest Rate",value:"3.834166667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"58.22479806"},
{axis:"GDP",value:"3.009961262"},
{axis:"Unemployment",value:"9"}]
    },
{className:"Monaco",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Moldova",
axes: [
{axis:"Inflation",value:"4.639518643"},
{axis:"Deposit Interest Rate",value:"7.631947966"},
{axis:"Lending Interest Rate",value:"13.41815434"},
{axis:"Central Government Debt",value:"24.3259057"},
{axis:"GDP",value:"-0.700000351"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Madagascar",
axes: [
{axis:"Inflation",value:"6.358698792"},
{axis:"Deposit Interest Rate",value:"10.5"},
{axis:"Lending Interest Rate",value:"60"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.027536044"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Maldives",
axes: [
{axis:"Inflation",value:"12.13071607"},
{axis:"Deposit Interest Rate",value:"3.730764005"},
{axis:"Lending Interest Rate",value:"10.4838045"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.496489996"},
{axis:"Unemployment",value:"11.69999981"}]
    },
{className:"Middle East and North Africa",
axes: [
{axis:"Inflation",value:"4.125785568"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.185923885"},
{axis:"Unemployment",value:"11.30023249"}]
    },
{className:"Mexico",
axes: [
{axis:"Inflation",value:"4.111508546"},
{axis:"Deposit Interest Rate",value:"1.081666667"},
{axis:"Lending Interest Rate",value:"4.730833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.018173869"},
{axis:"Unemployment",value:"4.900000095"}]
    },

{className:"Macedonia",
axes: [
{axis:"Inflation",value:"3.316055589"},
{axis:"Deposit Interest Rate",value:"5.089185277"},
{axis:"Lending Interest Rate",value:"8.495124184"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.456184412"},
{axis:"Unemployment",value:"31"}]
    },
{className:"Mali",
axes: [
{axis:"Inflation",value:"5.42738719"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.21561874"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Malta",
axes: [
{axis:"Inflation",value:"2.417624644"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"4.7025"},
{axis:"Central Government Debt",value:"87.13057629"},
{axis:"GDP",value:"1.1"},
{axis:"Unemployment",value:"6.400000095"}]
    },
{className:"Myanmar",
axes: [
{axis:"Inflation",value:"1.467583227"},
{axis:"Deposit Interest Rate",value:"8"},
{axis:"Lending Interest Rate",value:"13"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Montenegro",
axes: [
{axis:"Inflation",value:"4.14524725"},
{axis:"Deposit Interest Rate",value:"3.262583333"},
{axis:"Lending Interest Rate",value:"9.5625"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.723796788"},
{axis:"Unemployment",value:"19.60000038"}]
    },
{className:"Mongolia",
axes: [
{axis:"Inflation",value:"14.98449058"},
{axis:"Deposit Interest Rate",value:"11.27378269"},
{axis:"Lending Interest Rate",value:"18.11381443"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"12.31981973"},
{axis:"Unemployment",value:"5"}]
    },

{className:"Mozambique",
axes: [
{axis:"Inflation",value:"2.680855171"},
{axis:"Deposit Interest Rate",value:"11.4324746"},
{axis:"Lending Interest Rate",value:"16.81354167"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.198185826"},
{axis:"Unemployment",value:"22.60000038"}]
    },
{className:"Mauritania",
axes: [
{axis:"Inflation",value:"4.935879814"},
{axis:"Deposit Interest Rate",value:"5.81"},
{axis:"Lending Interest Rate",value:"17"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.795078172"},
{axis:"Unemployment",value:"31.10000038"}]
    },
{className:"Mauritius",
axes: [
{axis:"Inflation",value:"3.852160333"},
{axis:"Deposit Interest Rate",value:"6.233333333"},
{axis:"Lending Interest Rate",value:"8.666666667"},
{axis:"Central Government Debt",value:"50.11400178"},
{axis:"GDP",value:"3.221946714"},
{axis:"Unemployment",value:"8.699999809"}]
    },
{className:"Malawi",
axes: [
{axis:"Inflation",value:"21.271265"},
{axis:"Deposit Interest Rate",value:"11.07612374"},
{axis:"Lending Interest Rate",value:"32.32986111"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.885799507"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Malaysia",
axes: [
{axis:"Inflation",value:"1.655361757"},
{axis:"Deposit Interest Rate",value:"2.980833333"},
{axis:"Lending Interest Rate",value:"4.785833333"},
{axis:"Central Government Debt",value:"51.64648479"},
{axis:"GDP",value:"5.473454192"},
{axis:"Unemployment",value:"3"}]
    },
{className:"North America",
axes: [
{axis:"Inflation",value:"1.792507748"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"73.36212236"},
{axis:"GDP",value:"2.174512474"},
{axis:"Unemployment",value:"8.091994363"}]
    },
{className:"Namibia",
axes: [
{axis:"Inflation",value:"6.721997773"},
{axis:"Deposit Interest Rate",value:"4.20875"},
{axis:"Lending Interest Rate",value:"8.651875"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.061482274"},
{axis:"Unemployment",value:"16.70000076"}]
    },
{className:"Niger",
axes: [
{axis:"Inflation",value:"0.45508982"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.81366328"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Nigeria",
axes: [
{axis:"Inflation",value:"12.21700718"},
{axis:"Deposit Interest Rate",value:"8.4075"},
{axis:"Lending Interest Rate",value:"16.7925"},
{axis:"Central Government Debt",value:"10.41933685"},
{axis:"GDP",value:"4.279277314"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Nicaragua",
axes: [
{axis:"Inflation",value:"7.193613575"},
{axis:"Deposit Interest Rate",value:"0.995837711"},
{axis:"Lending Interest Rate",value:"11.99430816"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.590562193"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Netherlands",
axes: [
{axis:"Inflation",value:"2.455547653"},
{axis:"Deposit Interest Rate",value:"2.737041667"},
{axis:"Lending Interest Rate",value:"1.625"},
{axis:"Central Government Debt",value:"68.53637215"},
{axis:"GDP",value:"-1.057037404"},
{axis:"Unemployment",value:"5.300000191"}]
    },
{className:"Norway",
axes: [
{axis:"Inflation",value:"0.709219858"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"20.77493383"},
{axis:"GDP",value:"2.748768783"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Nepal",
axes: [
{axis:"Inflation",value:"9.454180743"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.781192258"},
{axis:"Unemployment",value:"2.700000048"}]
    },
{className:"New Zealand",
axes: [
{axis:"Inflation",value:"0.883430295"},
{axis:"Deposit Interest Rate",value:"4.108112301"},
{axis:"Lending Interest Rate",value:"5.82383752"},
{axis:"Central Government Debt",value:"66.98699556"},
{axis:"GDP",value:"2.736603777"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Oman",
axes: [
{axis:"Inflation",value:"2.910702521"},
{axis:"Deposit Interest Rate",value:"2.624"},
{axis:"Lending Interest Rate",value:"5.651"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.08065789"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Pakistan",
axes: [
{axis:"Inflation",value:"9.68505341"},
{axis:"Deposit Interest Rate",value:"7.979166667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.50703342"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Panama",
axes: [
{axis:"Inflation",value:"5.698199592"},
{axis:"Deposit Interest Rate",value:"2.143333333"},
{axis:"Lending Interest Rate",value:"6.91"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.229952302"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Peru",
axes: [
{axis:"Inflation",value:"3.653732359"},
{axis:"Deposit Interest Rate",value:"2.456633333"},
{axis:"Lending Interest Rate",value:"19.23690833"},
{axis:"Central Government Debt",value:"19.20928862"},
{axis:"GDP",value:"5.95034634"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Philippines",
axes: [
{axis:"Inflation",value:"3.172085646"},
{axis:"Deposit Interest Rate",value:"3.155916667"},
{axis:"Lending Interest Rate",value:"5.6795"},
{axis:"Central Government Debt",value:"51.48241815"},
{axis:"GDP",value:"6.683810237"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Palau",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.2"},
{axis:"Unemployment",value:""}]
    },
{className:"Papua New Guinea",
axes: [
{axis:"Inflation",value:"4.537205082"},
{axis:"Deposit Interest Rate",value:"0.485833333"},
{axis:"Lending Interest Rate",value:"10.815"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.087543144"},
{axis:"Unemployment",value:"2.5"}]
    },
{className:"Poland",
axes: [
{axis:"Inflation",value:"3.556869954"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"55.15502839"},
{axis:"GDP",value:"1.561706721"},
{axis:"Unemployment",value:"10.10000038"}]
    },
{className:"Puerto Rico",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.772499076"},
{axis:"Unemployment",value:"14.60000038"}]
    },
{className:"Portugal",
axes: [
{axis:"Inflation",value:"2.773338541"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"133.8816088"},
{axis:"GDP",value:"-4.028256714"},
{axis:"Unemployment",value:"15.60000038"}]
    },
{className:"Paraguay",
axes: [
{axis:"Inflation",value:"3.67591898"},
{axis:"Deposit Interest Rate",value:"3.915833333"},
{axis:"Lending Interest Rate",value:"17.15846732"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.238968506"},
{axis:"Unemployment",value:"4.900000095"}]
    },
{className:"Qatar",
axes: [
{axis:"Inflation",value:"1.866585067"},
{axis:"Deposit Interest Rate",value:"1.667210057"},
{axis:"Lending Interest Rate",value:"5.38110455"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.879570493"},
{axis:"Unemployment",value:"0.5"}]
    },
{className:"Romania",
axes: [
{axis:"Inflation",value:"3.333800252"},
{axis:"Deposit Interest Rate",value:"5.505"},
{axis:"Lending Interest Rate",value:"11.32916667"},
{axis:"Central Government Debt",value:"41.57752702"},
{axis:"GDP",value:"0.640965688"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Russian Federation",
axes: [
{axis:"Inflation",value:"5.078014184"},
{axis:"Deposit Interest Rate",value:"5.533333333"},
{axis:"Lending Interest Rate",value:"9.1"},
{axis:"Central Government Debt",value:"8.688588871"},
{axis:"GDP",value:"3.517941865"},
{axis:"Unemployment",value:"5.5"}]
    },
{className:"Rwanda",
axes: [
{axis:"Inflation",value:"6.27090301"},
{axis:"Deposit Interest Rate",value:"10.04"},
{axis:"Lending Interest Rate",value:"16.49"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.788351534"},
{axis:"Unemployment",value:"0.600000024"}]
    },
{className:"South Asia",
axes: [
{axis:"Inflation",value:"9.383313174"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.649628094"},
{axis:"Unemployment",value:"3.892546207"}]
    },
{className:"Saudi Arabia",
axes: [
{axis:"Inflation",value:"2.885962454"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.38446595"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Sudan",
axes: [
{axis:"Inflation",value:"37.39336493"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.214703192"},
{axis:"Unemployment",value:"14.60000038"}]
    },
{className:"Senegal",
axes: [
{axis:"Inflation",value:"1.421378457"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.411180285"},
{axis:"Unemployment",value:"10.30000019"}]
    },
{className:"Singapore",
axes: [
{axis:"Inflation",value:"4.528650647"},
{axis:"Deposit Interest Rate",value:"0.135833333"},
{axis:"Lending Interest Rate",value:"5.38"},
{axis:"Central Government Debt",value:"109.9970401"},
{axis:"GDP",value:"3.670136095"},
{axis:"Unemployment",value:"2.799999952"}]
    },
{className:"Solomon Islands",
axes: [
{axis:"Inflation",value:"5.912006025"},
{axis:"Deposit Interest Rate",value:"0.859194174"},
{axis:"Lending Interest Rate",value:"11.27888202"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.660611855"},
{axis:"Unemployment",value:"3.799999952"}]
    },
{className:"Sierra Leone",
axes: [
{axis:"Inflation",value:"12.87007632"},
{axis:"Deposit Interest Rate",value:"10.39"},
{axis:"Lending Interest Rate",value:"21"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"15.04611625"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"El Salvador",
axes: [
{axis:"Inflation",value:"1.729577995"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.880955461"},
{axis:"Unemployment",value:"6.099999905"}]
    },
{className:"San Marino",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Somalia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Serbia",
axes: [
{axis:"Inflation",value:"7.330385896"},
{axis:"Deposit Interest Rate",value:"10.57"},
{axis:"Lending Interest Rate",value:"18.2"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.015270388"},
{axis:"Unemployment",value:"23.89999962"}]
    },
{className:"Sao Tome and Principe",
axes: [
{axis:"Inflation",value:"10.63711959"},
{axis:"Deposit Interest Rate",value:"12.89"},
{axis:"Lending Interest Rate",value:"26.16805556"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.589145046"},
{axis:"Unemployment",value:""}]
    },
{className:"Suriname",
axes: [
{axis:"Inflation",value:"5.006863194"},
{axis:"Deposit Interest Rate",value:"6.791666667"},
{axis:"Lending Interest Rate",value:"11.74166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.071137574"},
{axis:"Unemployment",value:"6.300000191"}]
    },
{className:"Slovak Republic",
axes: [
{axis:"Inflation",value:"3.606102635"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"53.30985846"},
{axis:"GDP",value:"1.523328264"},
{axis:"Unemployment",value:"13.89999962"}]
    },
{className:"Slovenia",
axes: [
{axis:"Inflation",value:"2.598297643"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.718168813"},
{axis:"Unemployment",value:"8.800000191"}]
    },
{className:"Sweden",
axes: [
{axis:"Inflation",value:"0.888377507"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"42.02133087"},
{axis:"GDP",value:"-0.286320615"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Swaziland",
axes: [
{axis:"Inflation",value:"8.939609185"},
{axis:"Deposit Interest Rate",value:"2.465"},
{axis:"Lending Interest Rate",value:"8.75"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.027489393"},
{axis:"Unemployment",value:"22.5"}]
    },
{className:"Seychelles",
axes: [
{axis:"Inflation",value:"7.110370623"},
{axis:"Deposit Interest Rate",value:"3.298246264"},
{axis:"Lending Interest Rate",value:"12.19118576"},
{axis:"Central Government Debt",value:"72.99086464"},
{axis:"GDP",value:"6.610243689"},
{axis:"Unemployment",value:""}]
    },
{className:"Syrian Arab Republic",
axes: [
{axis:"Inflation",value:"36.70229534"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"11.39999962"}]
    },
{className:"Chad",
axes: [
{axis:"Inflation",value:"14.01820542"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.882576072"},
{axis:"Unemployment",value:"7"}]
    },
{className:"East Asia and Pacific (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.172085646"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.42911771"},
{axis:"Unemployment",value:"4.410486263"}]
    },
{className:"Europe and Central Asia (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.412073491"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.599872491"},
{axis:"Unemployment",value:"8.147809342"}]
    },
{className:"Togo",
axes: [
{axis:"Inflation",value:"2.630773937"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.820343516"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Thailand",
axes: [
{axis:"Inflation",value:"3.02"},
{axis:"Deposit Interest Rate",value:"2.795833333"},
{axis:"Lending Interest Rate",value:"7.0975"},
{axis:"Central Government Debt",value:"28.46387108"},
{axis:"GDP",value:"7.230959189"},
{axis:"Unemployment",value:"0.699999988"}]
    },
{className:"Tajikistan",
axes: [
{axis:"Inflation",value:"5.83116601"},
{axis:"Deposit Interest Rate",value:"7.674636132"},
{axis:"Lending Interest Rate",value:"21.09333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.499999169"},
{axis:"Unemployment",value:"11.10000038"}]
    },
{className:"Turkmenistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.09999996"},
{axis:"Unemployment",value:"10.80000019"}]
    },
{className:"Latin America and the Caribbean (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"4.144572208"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.922961675"},
{axis:"Unemployment",value:"6.26527238"}]
    },
{className:"Middle East and North Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"6.089096416"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.77387363"},
{axis:"Unemployment",value:"12.72113403"}]
    },
{className:"Timor-Leste",
axes: [
{axis:"Inflation",value:"11.80030967"},
{axis:"Deposit Interest Rate",value:"0.905304977"},
{axis:"Lending Interest Rate",value:"12.21026992"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.353861193"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Tonga",
axes: [
{axis:"Inflation",value:"1.212990573"},
{axis:"Deposit Interest Rate",value:"2.824000685"},
{axis:"Lending Interest Rate",value:"10.02569306"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.546957252"},
{axis:"Unemployment",value:""}]
    },
{className:"South Asia (IDA and IBRD)",
axes: [
{axis:"Inflation",value:"9.383313174"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.649628094"},
{axis:"Unemployment",value:"3.892546207"}]
    },
{className:"Sub-Saharan Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"6.46729925"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.645390608"},
{axis:"Unemployment",value:"8.091930356"}]
    },
{className:"Trinidad and Tobago",
axes: [
{axis:"Inflation",value:"9.268580239"},
{axis:"Deposit Interest Rate",value:"1.5"},
{axis:"Lending Interest Rate",value:"7.708333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.366074356"},
{axis:"Unemployment",value:"5"}]
    },
{className:"Tunisia",
axes: [
{axis:"Inflation",value:"5.138117098"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"44.65968772"},
{axis:"GDP",value:"3.700000026"},
{axis:"Unemployment",value:"14"}]
    },
{className:"Turkey",
axes: [
{axis:"Inflation",value:"8.891569965"},
{axis:"Deposit Interest Rate",value:"16.35166667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"43.52573812"},
{axis:"GDP",value:"2.127460709"},
{axis:"Unemployment",value:"9.199999809"}]
    },
{className:"Tuvalu",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.174458145"},
{axis:"Unemployment",value:""}]
    },
{className:"Tanzania",
axes: [
{axis:"Inflation",value:"16.00109385"},
{axis:"Deposit Interest Rate",value:"9.511822889"},
{axis:"Lending Interest Rate",value:"15.46046414"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.141013621"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Uganda",
axes: [
{axis:"Inflation",value:"14.01605656"},
{axis:"Deposit Interest Rate",value:"16.22835826"},
{axis:"Lending Interest Rate",value:"26.31136912"},
{axis:"Central Government Debt",value:"33.21179562"},
{axis:"GDP",value:"4.411259872"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Ukraine",
axes: [
{axis:"Inflation",value:"0.555555556"},
{axis:"Deposit Interest Rate",value:"12.96119167"},
{axis:"Lending Interest Rate",value:"18.39221667"},
{axis:"Central Government Debt",value:"33.70308592"},
{axis:"GDP",value:"0.199999998"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Uruguay",
axes: [
{axis:"Inflation",value:"8.097765806"},
{axis:"Deposit Interest Rate",value:"4.449826677"},
{axis:"Lending Interest Rate",value:"11.19919216"},
{axis:"Central Government Debt",value:"43.40345045"},
{axis:"GDP",value:"3.538178722"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"United States",
axes: [
{axis:"Inflation",value:"2.069337265"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"3.25"},
{axis:"Central Government Debt",value:"94.37495725"},
{axis:"GDP",value:"2.224030854"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Uzbekistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.2"},
{axis:"Unemployment",value:"10.80000019"}]
    },
{className:"St Vincent and the Grenadines",
axes: [
{axis:"Inflation",value:"2.598444141"},
{axis:"Deposit Interest Rate",value:"2.875881758"},
{axis:"Lending Interest Rate",value:"9.414408973"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.380494196"},
{axis:"Unemployment",value:""}]
    },
{className:"Venezuela",
axes: [
{axis:"Inflation",value:"21.06899563"},
{axis:"Deposit Interest Rate",value:"14.50916667"},
{axis:"Lending Interest Rate",value:"16.38"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.625956975"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Vietnam",
axes: [
{axis:"Inflation",value:"9.094216079"},
{axis:"Deposit Interest Rate",value:"10.50366667"},
{axis:"Lending Interest Rate",value:"13.47166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.247367156"},
{axis:"Unemployment",value:"1.799999952"}]
    },
{className:"Vanuatu",
axes: [
{axis:"Inflation",value:"1.363636364"},
{axis:"Deposit Interest Rate",value:"1.3125"},
{axis:"Lending Interest Rate",value:"6.05"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.754749927"},
{axis:"Unemployment",value:""}]
    },
{className:"West Bank and Gaza",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.4575"},
{axis:"Lending Interest Rate",value:"6.9675"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"14.53603506"},
{axis:"Unemployment",value:"23"}]
    },
{className:"World",
axes: [
{axis:"Inflation",value:"3.852160333"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.465177824"},
{axis:"Unemployment",value:"5.994816164"}]
    },
{className:"Samoa",
axes: [
{axis:"Inflation",value:"2.049018835"},
{axis:"Deposit Interest Rate",value:"2.469166667"},
{axis:"Lending Interest Rate",value:"9.86"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.402103619"},
{axis:"Unemployment",value:""}]
    },
{className:"Yemen",
axes: [
{axis:"Inflation",value:"9.885387145"},
{axis:"Deposit Interest Rate",value:"19.5"},
{axis:"Lending Interest Rate",value:"24.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.469878516"},
{axis:"Unemployment",value:"17.70000076"}]
    },
{className:"South Africa",
axes: [
{axis:"Inflation",value:"5.653583003"},
{axis:"Deposit Interest Rate",value:"5.436666667"},
{axis:"Lending Interest Rate",value:"8.75"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.219824006"},
{axis:"Unemployment",value:"25"}]
    },
{className:"Democratic Republic of the Congo",
axes: [
{axis:"Inflation",value:"9.721828063"},
{axis:"Deposit Interest Rate",value:"7.719166667"},
{axis:"Lending Interest Rate",value:"28.44666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.157859628"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Zambia",
axes: [
{axis:"Inflation",value:"6.575899708"},
{axis:"Deposit Interest Rate",value:"7"},
{axis:"Lending Interest Rate",value:"12.14976637"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.572564153"},
{axis:"Unemployment",value:"13.10000038"}]
    },
{className:"Zimbabwe",
axes: [
{axis:"Inflation",value:"3.922235339"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.56520427"},
{axis:"Unemployment",value:"5.300000191"}]
    }
],
["2013",
{className:"Aruba",
axes: [
{axis:"Inflation",value:"-2.37226328"},
{axis:"Deposit Interest Rate",value:"1.633333333"},
{axis:"Lending Interest Rate",value:"8.725"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Andorra",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.063514313"},
{axis:"Unemployment",value:""}]
    },
{className:"Afghanistan",
axes: [
{axis:"Inflation",value:"7.654316567"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"15.07916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.959122893"},
{axis:"Unemployment",value:"9.199999809"}]
    },
{className:"Angola",
axes: [
{axis:"Inflation",value:"8.776090933"},
{axis:"Deposit Interest Rate",value:"3.145070736"},
{axis:"Lending Interest Rate",value:"15.8086383"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.81358577"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Albania",
axes: [
{axis:"Inflation",value:"1.937617549"},
{axis:"Deposit Interest Rate",value:"4.16420494"},
{axis:"Lending Interest Rate",value:"9.826604344"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.109999993"},
{axis:"Unemployment",value:"16"}]
    },
{className:"United Arab Emirates",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"1.907644573"},
{axis:"GDP",value:"4.321360255"},
{axis:"Unemployment",value:"3.799999952"}]
    },
{className:"Argentina",
axes: [
{axis:"Inflation",value:"10.61943301"},
{axis:"Deposit Interest Rate",value:"14.85445459"},
{axis:"Lending Interest Rate",value:"17.14916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.302484158"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Armenia",
axes: [
{axis:"Inflation",value:"5.793787917"},
{axis:"Deposit Interest Rate",value:"10.16026529"},
{axis:"Lending Interest Rate",value:"15.99498737"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.300000002"},
{axis:"Unemployment",value:"16.20000076"}]
    },
{className:"Antigua and Barbuda",
axes: [
{axis:"Inflation",value:"1.059497824"},
{axis:"Deposit Interest Rate",value:"3.044349177"},
{axis:"Lending Interest Rate",value:"9.952353294"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.346259916"},
{axis:"Unemployment",value:""}]
    },
{className:"Australia",
axes: [
{axis:"Inflation",value:"2.449888641"},
{axis:"Deposit Interest Rate",value:"3.25"},
{axis:"Lending Interest Rate",value:"6.179166667"},
{axis:"Central Government Debt",value:"38.33918379"},
{axis:"GDP",value:"2.440049062"},
{axis:"Unemployment",value:"5.699999809"}]
    },
{className:"Austria",
axes: [
{axis:"Inflation",value:"2.000157493"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"83.41100192"},
{axis:"GDP",value:"0.321250822"},
{axis:"Unemployment",value:"4.900000095"}]
    },
{className:"Azerbaijan",
axes: [
{axis:"Inflation",value:"2.381443661"},
{axis:"Deposit Interest Rate",value:"9.891666667"},
{axis:"Lending Interest Rate",value:"18.21"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.796678396"},
{axis:"Unemployment",value:"5"}]
    },
{className:"Burundi",
axes: [
{axis:"Inflation",value:"7.950674328"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"15.1475"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.594054218"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Belgium",
axes: [
{axis:"Inflation",value:"1.113938556"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"101.5514179"},
{axis:"GDP",value:"0.003056057"},
{axis:"Unemployment",value:"8.399999619"}]
    },
{className:"Benin",
axes: [
{axis:"Inflation",value:"0.971851852"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.878995974"},
{axis:"Unemployment",value:"1"}]
    },
{className:"Burkina Faso",
axes: [
{axis:"Inflation",value:"0.533738507"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.649305084"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Bangladesh",
axes: [
{axis:"Inflation",value:"7.529972823"},
{axis:"Deposit Interest Rate",value:"11.72166667"},
{axis:"Lending Interest Rate",value:"13.59333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.013596067"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Bulgaria",
axes: [
{axis:"Inflation",value:"0.890093541"},
{axis:"Deposit Interest Rate",value:"2.413308333"},
{axis:"Lending Interest Rate",value:"9.050175"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.281885084"},
{axis:"Unemployment",value:"12.89999962"}]
    },
{className:"Bahrain",
axes: [
{axis:"Inflation",value:"3.305484926"},
{axis:"Deposit Interest Rate",value:"1.058333333"},
{axis:"Lending Interest Rate",value:"5.935"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.412938243"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"The Bahamas",
axes: [
{axis:"Inflation",value:"0.346878097"},
{axis:"Deposit Interest Rate",value:"1.68"},
{axis:"Lending Interest Rate",value:"4.75"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.022030197"},
{axis:"Unemployment",value:"16.20000076"}]
    },
{className:"Bosnia and Herzegovina",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"3.00616795"},
{axis:"Lending Interest Rate",value:"7.036048111"},
{axis:"Central Government Debt",value:"46.0035936"},
{axis:"GDP",value:"2.394191896"},
{axis:"Unemployment",value:"27.39999962"}]
    },
{className:"Belarus",
axes: [
{axis:"Inflation",value:"18.31226104"},
{axis:"Deposit Interest Rate",value:"20.25833333"},
{axis:"Lending Interest Rate",value:"19.13333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.073600801"},
{axis:"Unemployment",value:"6"}]
    },
{className:"Belize",
axes: [
{axis:"Inflation",value:"0.509747769"},
{axis:"Deposit Interest Rate",value:"3.585"},
{axis:"Lending Interest Rate",value:"11.56916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.313220167"},
{axis:"Unemployment",value:"11.69999981"}]
    },
{className:"Bermuda",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.511154431"},
{axis:"Unemployment",value:""}]
    },
{className:"Bolivia",
axes: [
{axis:"Inflation",value:"5.715580098"},
{axis:"Deposit Interest Rate",value:"1.739183525"},
{axis:"Lending Interest Rate",value:"11.05139928"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.796011706"},
{axis:"Unemployment",value:"2.599999905"}]
    },
{className:"Brazil",
axes: [
{axis:"Inflation",value:"6.201899613"},
{axis:"Deposit Interest Rate",value:"7.807103787"},
{axis:"Lending Interest Rate",value:"27.39166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.015140511"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Barbados",
axes: [
{axis:"Inflation",value:"1.804005504"},
{axis:"Deposit Interest Rate",value:"2.510833333"},
{axis:"Lending Interest Rate",value:"8.7"},
{axis:"Central Government Debt",value:"131.631527"},
{axis:"GDP",value:"0"},
{axis:"Unemployment",value:"11.60000038"}]
    },
{className:"Brunei Darussalam",
axes: [
{axis:"Inflation",value:"0.383263086"},
{axis:"Deposit Interest Rate",value:"0.284346667"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.751960547"},
{axis:"Unemployment",value:"3.799999952"}]
    },
{className:"Bhutan",
axes: [
{axis:"Inflation",value:"7.006666667"},
{axis:"Deposit Interest Rate",value:"6"},
{axis:"Lending Interest Rate",value:"14"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.142496554"},
{axis:"Unemployment",value:"2.900000095"}]
    },
{className:"Botswana",
axes: [
{axis:"Inflation",value:"5.883888483"},
{axis:"Deposit Interest Rate",value:"3.1096525"},
{axis:"Lending Interest Rate",value:"10.18923333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.860292657"},
{axis:"Unemployment",value:"17.60000038"}]
    },
{className:"Central African Republic",
axes: [
{axis:"Inflation",value:"1.501845124"},
{axis:"Deposit Interest Rate",value:"3.208333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-37.01195691"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Canada",
axes: [
{axis:"Inflation",value:"0.938291898"},
{axis:"Deposit Interest Rate",value:"0.55"},
{axis:"Lending Interest Rate",value:"3"},
{axis:"Central Government Debt",value:"48.884284"},
{axis:"GDP",value:"2.218068188"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Central Europe and the Baltics",
axes: [
{axis:"Inflation",value:"1.434726602"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"49.67603577"},
{axis:"GDP",value:"1.2727673"},
{axis:"Unemployment",value:"10.10372887"}]
    },
{className:"Switzerland",
axes: [
{axis:"Inflation",value:"-0.217319662"},
{axis:"Deposit Interest Rate",value:"0.03"},
{axis:"Lending Interest Rate",value:"2.689166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.768830561"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Chile",
axes: [
{axis:"Inflation",value:"1.791710733"},
{axis:"Deposit Interest Rate",value:"5.168868155"},
{axis:"Lending Interest Rate",value:"9.261876782"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.976596199"},
{axis:"Unemployment",value:"6"}]
    },
{className:"China",
axes: [
{axis:"Inflation",value:"2.627118644"},
{axis:"Deposit Interest Rate",value:"3"},
{axis:"Lending Interest Rate",value:"6"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.68380997"},
{axis:"Unemployment",value:"4.599999905"}]
    },
{className:"Cote dIvoire",
axes: [
{axis:"Inflation",value:"2.581170373"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.218578722"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Cameroon",
axes: [
{axis:"Inflation",value:"1.945145275"},
{axis:"Deposit Interest Rate",value:"3.208333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.561688129"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Republic of Congo",
axes: [
{axis:"Inflation",value:"5.968928863"},
{axis:"Deposit Interest Rate",value:"3.208333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.440705249"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"Colombia",
axes: [
{axis:"Inflation",value:"2.022774948"},
{axis:"Deposit Interest Rate",value:"4.170017565"},
{axis:"Lending Interest Rate",value:"10.98558617"},
{axis:"Central Government Debt",value:"58.62544131"},
{axis:"GDP",value:"4.874065579"},
{axis:"Unemployment",value:"9.600000381"}]
    },
{className:"Comoros",
axes: [
{axis:"Inflation",value:"2.297303022"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"10.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.499999994"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Cabo Verde",
axes: [
{axis:"Inflation",value:"1.512153759"},
{axis:"Deposit Interest Rate",value:"4.174495351"},
{axis:"Lending Interest Rate",value:"10.52009902"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.045244023"},
{axis:"Unemployment",value:"9"}]
    },
{className:"Costa Rica",
axes: [
{axis:"Inflation",value:"5.224285869"},
{axis:"Deposit Interest Rate",value:"3.8775"},
{axis:"Lending Interest Rate",value:"15.18833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.437273971"},
{axis:"Unemployment",value:"8.5"}]
    },
{className:"Caribbean small states",
axes: [
{axis:"Inflation",value:"1.10698554"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.31182369"},
{axis:"Unemployment",value:"11.05494695"}]
    },
{className:"Cuba",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.686032552"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Cyprus",
axes: [
{axis:"Inflation",value:"-0.400053061"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"145.8487086"},
{axis:"GDP",value:"-5.939077045"},
{axis:"Unemployment",value:"15.80000019"}]
    },
{className:"Czech Republic",
axes: [
{axis:"Inflation",value:"1.434726602"},
{axis:"Deposit Interest Rate",value:"0.861548173"},
{axis:"Lending Interest Rate",value:"4.969893014"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.528170821"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Germany",
axes: [
{axis:"Inflation",value:"1.504722267"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"52.33371856"},
{axis:"GDP",value:"0.297847586"},
{axis:"Unemployment",value:"5.300000191"}]
    },
{className:"Djibouti",
axes: [
{axis:"Inflation",value:"2.420593208"},
{axis:"Deposit Interest Rate",value:"2.031958333"},
{axis:"Lending Interest Rate",value:"11.93625"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.999907255"},
{axis:"Unemployment",value:""}]
    },
{className:"Dominica",
axes: [
{axis:"Inflation",value:"-0.046411647"},
{axis:"Deposit Interest Rate",value:"3.050412748"},
{axis:"Lending Interest Rate",value:"9.073960019"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.593723494"},
{axis:"Unemployment",value:""}]
    },
{className:"Denmark",
axes: [
{axis:"Inflation",value:"0.78907178"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"46.14965958"},
{axis:"GDP",value:"-0.243779283"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Dominican Republic",
axes: [
{axis:"Inflation",value:"4.830950967"},
{axis:"Deposit Interest Rate",value:"6.019860778"},
{axis:"Lending Interest Rate",value:"13.59140054"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.777741911"},
{axis:"Unemployment",value:"15"}]
    },
{className:"Algeria",
axes: [
{axis:"Inflation",value:"3.253684177"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.8"},
{axis:"Unemployment",value:"9.800000191"}]
    },
{className:"East Asia and Pacific (excluding high income)",
axes: [
{axis:"Inflation",value:"2.997694081"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.136696214"},
{axis:"Unemployment",value:"4.524287519"}]
    },
{className:"East Asia and Pacific",
axes: [
{axis:"Inflation",value:"2.909178822"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.514780252"},
{axis:"Unemployment",value:"4.472938316"}]
    },
{className:"Europe and Central Asia (excluding high income)",
axes: [
{axis:"Inflation",value:"4.641790221"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.612604092"},
{axis:"Unemployment",value:"7.758629475"}]
    },
{className:"Europe and Central Asia",
axes: [
{axis:"Inflation",value:"1.734030794"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"63.20000379"},
{axis:"GDP",value:"0.597924757"},
{axis:"Unemployment",value:"9.441505606"}]
    },
{className:"Ecuador",
axes: [
{axis:"Inflation",value:"2.738631757"},
{axis:"Deposit Interest Rate",value:"3.89"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.553575531"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Egypt",
axes: [
{axis:"Inflation",value:"9.42157654"},
{axis:"Deposit Interest Rate",value:"7.683333333"},
{axis:"Lending Interest Rate",value:"12.29166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.106724617"},
{axis:"Unemployment",value:"13.19999981"}]
    },
{className:"Eritrea",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Spain",
axes: [
{axis:"Inflation",value:"1.408628285"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"96.47233457"},
{axis:"GDP",value:"-1.671971848"},
{axis:"Unemployment",value:"26.29999924"}]
    },
{className:"Estonia",
axes: [
{axis:"Inflation",value:"2.788496796"},
{axis:"Deposit Interest Rate",value:"0.416999224"},
{axis:"Lending Interest Rate",value:"5.364483106"},
{axis:"Central Government Debt",value:"0.629979215"},
{axis:"GDP",value:"1.567795821"},
{axis:"Unemployment",value:"8.600000381"}]
    },
{className:"Ethiopia",
axes: [
{axis:"Inflation",value:"8.078472326"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.58227004"},
{axis:"Unemployment",value:"5"}]
    },
{className:"European Union",
axes: [
{axis:"Inflation",value:"1.387689946"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"83.41100192"},
{axis:"GDP",value:"0.186819335"},
{axis:"Unemployment",value:"10.88201392"}]
    },
{className:"Finland",
axes: [
{axis:"Inflation",value:"1.478288133"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"53.5310665"},
{axis:"GDP",value:"-0.758036295"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Fiji",
axes: [
{axis:"Inflation",value:"2.909178822"},
{axis:"Deposit Interest Rate",value:"2.069908996"},
{axis:"Lending Interest Rate",value:"6.10473364"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.35548347"},
{axis:"Unemployment",value:"8.300000191"}]
    },
{className:"France",
axes: [
{axis:"Inflation",value:"0.86360693"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"88.57934926"},
{axis:"GDP",value:"0.576241547"},
{axis:"Unemployment",value:"10.39999962"}]
    },
{className:"Federal States of Micronesia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.526666667"},
{axis:"Lending Interest Rate",value:"14.825"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.561518835"},
{axis:"Unemployment",value:""}]
    },
{className:"Gabon",
axes: [
{axis:"Inflation",value:"0.480142671"},
{axis:"Deposit Interest Rate",value:"3.208333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.63841405"},
{axis:"Unemployment",value:"20.29999924"}]
    },
{className:"United Kingdom",
axes: [
{axis:"Inflation",value:"2.554546687"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"0.5"},
{axis:"Central Government Debt",value:"98.26398355"},
{axis:"GDP",value:"2.159903871"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Georgia",
axes: [
{axis:"Inflation",value:"-0.512058411"},
{axis:"Deposit Interest Rate",value:"9.726617269"},
{axis:"Lending Interest Rate",value:"13.5948916"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.387043726"},
{axis:"Unemployment",value:"14.60000038"}]
    },
{className:"Ghana",
axes: [
{axis:"Inflation",value:"11.60833333"},
{axis:"Deposit Interest Rate",value:"12.35"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.312525021"},
{axis:"Unemployment",value:"1.799999952"}]
    },
{className:"Guinea",
axes: [
{axis:"Inflation",value:"11.88842377"},
{axis:"Deposit Interest Rate",value:"15.62308333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.299999238"},
{axis:"Unemployment",value:"1.700000048"}]
    },
{className:"Gambia",
axes: [
{axis:"Inflation",value:"5.699730297"},
{axis:"Deposit Interest Rate",value:"13.43583333"},
{axis:"Lending Interest Rate",value:"28"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.780907872"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Guinea-Bissau",
axes: [
{axis:"Inflation",value:"1.207125557"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.820272416"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Equatorial Guinea",
axes: [
{axis:"Inflation",value:"1.169743628"},
{axis:"Deposit Interest Rate",value:"3.208333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-6.507499735"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Greece",
axes: [
{axis:"Inflation",value:"-0.921271918"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"181.9295642"},
{axis:"GDP",value:"-3.198239636"},
{axis:"Unemployment",value:"27.20000076"}]
    },
{className:"Grenada",
axes: [
{axis:"Inflation",value:"-0.044228555"},
{axis:"Deposit Interest Rate",value:"2.640459829"},
{axis:"Lending Interest Rate",value:"9.270206825"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.352300913"},
{axis:"Unemployment",value:""}]
    },
{className:"Greenland",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Guatemala",
axes: [
{axis:"Inflation",value:"4.343371313"},
{axis:"Deposit Interest Rate",value:"5.451666667"},
{axis:"Lending Interest Rate",value:"13.5975"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.697585578"},
{axis:"Unemployment",value:"3"}]
    },
{className:"Guyana",
axes: [
{axis:"Inflation",value:"1.832450594"},
{axis:"Deposit Interest Rate",value:"1.133680556"},
{axis:"Lending Interest Rate",value:"13.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.22162589"},
{axis:"Unemployment",value:"11.10000038"}]
    },
{className:"Hong Kong",
axes: [
{axis:"Inflation",value:"4.351767906"},
{axis:"Deposit Interest Rate",value:"0.01"},
{axis:"Lending Interest Rate",value:"5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.072174041"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Honduras",
axes: [
{axis:"Inflation",value:"5.161898986"},
{axis:"Deposit Interest Rate",value:"11.64742833"},
{axis:"Lending Interest Rate",value:"20.08086667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.791559757"},
{axis:"Unemployment",value:"3.900000095"}]
    },
{className:"Croatia",
axes: [
{axis:"Inflation",value:"2.216582064"},
{axis:"Deposit Interest Rate",value:"1.520833333"},
{axis:"Lending Interest Rate",value:"9.246666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.063921096"},
{axis:"Unemployment",value:"17.29999924"}]
    },
{className:"Haiti",
axes: [
{axis:"Inflation",value:"5.853472722"},
{axis:"Deposit Interest Rate",value:"0.683333333"},
{axis:"Lending Interest Rate",value:"8.7225"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.247935032"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Hungary",
axes: [
{axis:"Inflation",value:"1.721102477"},
{axis:"Deposit Interest Rate",value:"2.459441112"},
{axis:"Lending Interest Rate",value:"6.303912354"},
{axis:"Central Government Debt",value:"94.53781897"},
{axis:"GDP",value:"1.889768022"},
{axis:"Unemployment",value:"10.19999981"}]
    },
{className:"Indonesia",
axes: [
{axis:"Inflation",value:"6.413386778"},
{axis:"Deposit Interest Rate",value:"6.264166667"},
{axis:"Lending Interest Rate",value:"11.6575"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.557263689"},
{axis:"Unemployment",value:"6.300000191"}]
    },
{className:"India",
axes: [
{axis:"Inflation",value:"10.90764331"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"10.29166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.638812736"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Ireland",
axes: [
{axis:"Inflation",value:"0.502678204"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"132.9785974"},
{axis:"GDP",value:"1.434302453"},
{axis:"Unemployment",value:"13.10000038"}]
    },
{className:"Iran",
axes: [
{axis:"Inflation",value:"39.26636098"},
{axis:"Deposit Interest Rate",value:"14.76277306"},
{axis:"Lending Interest Rate",value:"11"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.911575057"},
{axis:"Unemployment",value:"12.89999962"}]
    },
{className:"Iraq",
axes: [
{axis:"Inflation",value:"1.879498007"},
{axis:"Deposit Interest Rate",value:"5.746666667"},
{axis:"Lending Interest Rate",value:"13.12583333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.572160298"},
{axis:"Unemployment",value:"15.10000038"}]
    },
{className:"Iceland",
axes: [
{axis:"Inflation",value:"3.884644993"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"8.151666667"},
{axis:"Central Government Debt",value:"103.1947623"},
{axis:"GDP",value:"3.895970473"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Israel",
axes: [
{axis:"Inflation",value:"1.525873129"},
{axis:"Deposit Interest Rate",value:"1.083688259"},
{axis:"Lending Interest Rate",value:"4.194552422"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.353203071"},
{axis:"Unemployment",value:"6.300000191"}]
    },
{className:"Italy",
axes: [
{axis:"Inflation",value:"1.219992129"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"5.144166667"},
{axis:"Central Government Debt",value:"134.8563315"},
{axis:"GDP",value:"-1.748190439"},
{axis:"Unemployment",value:"12.19999981"}]
    },
{className:"Jamaica",
axes: [
{axis:"Inflation",value:"9.344402834"},
{axis:"Deposit Interest Rate",value:"3.65649735"},
{axis:"Lending Interest Rate",value:"17.71645756"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.547910509"},
{axis:"Unemployment",value:"15"}]
    },
{className:"Jordan",
axes: [
{axis:"Inflation",value:"4.830067361"},
{axis:"Deposit Interest Rate",value:"4.8475"},
{axis:"Lending Interest Rate",value:"9.01"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.829210769"},
{axis:"Unemployment",value:"12.60000038"}]
    },
{className:"Japan",
axes: [
{axis:"Inflation",value:"0.35947166"},
{axis:"Deposit Interest Rate",value:"0.542166667"},
{axis:"Lending Interest Rate",value:"1.30375"},
{axis:"Central Government Debt",value:"201.567701"},
{axis:"GDP",value:"1.356716501"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Kazakhstan",
axes: [
{axis:"Inflation",value:"5.836702333"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.8"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"Kenya",
axes: [
{axis:"Inflation",value:"5.71827408"},
{axis:"Deposit Interest Rate",value:"8.641769671"},
{axis:"Lending Interest Rate",value:"17.31345769"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.693530352"},
{axis:"Unemployment",value:"9.100000381"}]
    },
{className:"Kyrgyz Republic",
axes: [
{axis:"Inflation",value:"6.606535722"},
{axis:"Deposit Interest Rate",value:"2.244324603"},
{axis:"Lending Interest Rate",value:"21.72713217"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.91546938"},
{axis:"Unemployment",value:"8.300000191"}]
    },
{className:"Cambodia",
axes: [
{axis:"Inflation",value:"2.94260016"},
{axis:"Deposit Interest Rate",value:"1.343402778"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.480003653"},
{axis:"Unemployment",value:"0.300000012"}]
    },
{className:"St Kitts and Nevis",
axes: [
{axis:"Inflation",value:"1.10698554"},
{axis:"Deposit Interest Rate",value:"3.736245864"},
{axis:"Lending Interest Rate",value:"8.776353612"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.820111758"},
{axis:"Unemployment",value:""}]
    },
{className:"South Korea",
axes: [
{axis:"Inflation",value:"1.307866014"},
{axis:"Deposit Interest Rate",value:"2.890833333"},
{axis:"Lending Interest Rate",value:"4.643333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.896220054"},
{axis:"Unemployment",value:"3.099999905"}]
    },
{className:"Kosovo",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.4"},
{axis:"Lending Interest Rate",value:"10.9"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.440464709"},
{axis:"Unemployment",value:""}]
    },
{className:"Kuwait",
axes: [
{axis:"Inflation",value:"2.702702703"},
{axis:"Deposit Interest Rate",value:"2.020675"},
{axis:"Lending Interest Rate",value:"4.561308333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.149038847"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Latin America and Caribbean (excluding high income)",
axes: [
{axis:"Inflation",value:"3.806389823"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.781772598"},
{axis:"Unemployment",value:"6.253421189"}]
    },
{className:"Lao PDR",
axes: [
{axis:"Inflation",value:"6.364939277"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.471097672"},
{axis:"Unemployment",value:"1.299999952"}]
    },
{className:"Lebanon",
axes: [
{axis:"Inflation",value:"5.543828737"},
{axis:"Deposit Interest Rate",value:"5.828333333"},
{axis:"Lending Interest Rate",value:"7.348333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.900000061"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"Liberia",
axes: [
{axis:"Inflation",value:"7.574897857"},
{axis:"Deposit Interest Rate",value:"3.871703933"},
{axis:"Lending Interest Rate",value:"13.48939298"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.703875016"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Libya",
axes: [
{axis:"Inflation",value:"2.605818027"},
{axis:"Deposit Interest Rate",value:"2.5"},
{axis:"Lending Interest Rate",value:"6"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-13.55238921"},
{axis:"Unemployment",value:"19.20000076"}]
    },
{className:"St Lucia",
axes: [
{axis:"Inflation",value:"1.472018389"},
{axis:"Deposit Interest Rate",value:"2.934238185"},
{axis:"Lending Interest Rate",value:"9.075214298"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.138582388"},
{axis:"Unemployment",value:""}]
    },
{className:"Latin America and Caribbean",
axes: [
{axis:"Inflation",value:"2.738631757"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.781351405"},
{axis:"Unemployment",value:"6.286898528"}]
    },
{className:"Liechtenstein",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Sri Lanka",
axes: [
{axis:"Inflation",value:"6.911546529"},
{axis:"Deposit Interest Rate",value:"9.14"},
{axis:"Lending Interest Rate",value:"9.14"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.395709596"},
{axis:"Unemployment",value:"4.400000095"}]
    },
{className:"Lesotho",
axes: [
{axis:"Inflation",value:"4.928340711"},
{axis:"Deposit Interest Rate",value:"2.85"},
{axis:"Lending Interest Rate",value:"9.92"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.461031071"},
{axis:"Unemployment",value:"24.60000038"}]
    },
{className:"Lithuania",
axes: [
{axis:"Inflation",value:"1.047466621"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"43.76049951"},
{axis:"GDP",value:"3.544744983"},
{axis:"Unemployment",value:"11.80000019"}]
    },
{className:"Luxembourg",
axes: [
{axis:"Inflation",value:"1.734030794"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.346679537"},
{axis:"Unemployment",value:"5.900000095"}]
    },
{className:"Latvia",
axes: [
{axis:"Inflation",value:"0"},
{axis:"Deposit Interest Rate",value:"0.128333333"},
{axis:"Lending Interest Rate",value:"5.923333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.021631081"},
{axis:"Unemployment",value:"11.89999962"}]
    },
{className:"Macau",
axes: [
{axis:"Inflation",value:"5.510678322"},
{axis:"Deposit Interest Rate",value:"0.044590863"},
{axis:"Lending Interest Rate",value:"5.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.20062232"},
{axis:"Unemployment",value:"1.799999952"}]
    },
{className:"Morocco",
axes: [
{axis:"Inflation",value:"1.88750188"},
{axis:"Deposit Interest Rate",value:"3.914166667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.725331777"},
{axis:"Unemployment",value:"9.199999809"}]
    },
{className:"Monaco",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Moldova",
axes: [
{axis:"Inflation",value:"4.641790221"},
{axis:"Deposit Interest Rate",value:"7.228333333"},
{axis:"Lending Interest Rate",value:"12.29416667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.396806409"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Madagascar",
axes: [
{axis:"Inflation",value:"5.826429445"},
{axis:"Deposit Interest Rate",value:"10.75"},
{axis:"Lending Interest Rate",value:"60"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.263499584"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Maldives",
axes: [
{axis:"Inflation",value:"2.314011322"},
{axis:"Deposit Interest Rate",value:"3.806529722"},
{axis:"Lending Interest Rate",value:"11.14190737"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.699793673"},
{axis:"Unemployment",value:"11.30000019"}]
    },
{className:"Middle East and North Africa",
axes: [
{axis:"Inflation",value:"3.192627609"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.176024502"},
{axis:"Unemployment",value:"11.20311888"}]
    },
{className:"Mexico",
axes: [
{axis:"Inflation",value:"3.806389823"},
{axis:"Deposit Interest Rate",value:"1.331666667"},
{axis:"Lending Interest Rate",value:"4.248333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.34536242"},
{axis:"Unemployment",value:"4.900000095"}]
    },

{className:"Macedonia",
axes: [
{axis:"Inflation",value:"2.784383849"},
{axis:"Deposit Interest Rate",value:"4.418458649"},
{axis:"Lending Interest Rate",value:"8.043156284"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.925265321"},
{axis:"Unemployment",value:"29"}]
    },
{className:"Mali",
axes: [
{axis:"Inflation",value:"-0.606221674"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.014482138"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Malta",
axes: [
{axis:"Inflation",value:"1.374906203"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"88.29822653"},
{axis:"GDP",value:"2.9"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Myanmar",
axes: [
{axis:"Inflation",value:"5.524279207"},
{axis:"Deposit Interest Rate",value:"8"},
{axis:"Lending Interest Rate",value:"13"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.519691107"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Montenegro",
axes: [
{axis:"Inflation",value:"2.205892681"},
{axis:"Deposit Interest Rate",value:"2.911708333"},
{axis:"Lending Interest Rate",value:"9.39"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.548980552"},
{axis:"Unemployment",value:"19.5"}]
    },
{className:"Mongolia",
axes: [
{axis:"Inflation",value:"8.604828111"},
{axis:"Deposit Interest Rate",value:"12.04568609"},
{axis:"Lending Interest Rate",value:"18.48202279"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"11.64891583"},
{axis:"Unemployment",value:"5"}]
    },

{className:"Mozambique",
axes: [
{axis:"Inflation",value:"4.261352509"},
{axis:"Deposit Interest Rate",value:"8.795096333"},
{axis:"Lending Interest Rate",value:"15.32060185"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.1416833"},
{axis:"Unemployment",value:"22.5"}]
    },
{className:"Mauritania",
axes: [
{axis:"Inflation",value:"4.12964239"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.090258729"},
{axis:"Unemployment",value:"31.10000038"}]
    },
{className:"Mauritius",
axes: [
{axis:"Inflation",value:"3.543295739"},
{axis:"Deposit Interest Rate",value:"6.8125"},
{axis:"Lending Interest Rate",value:"8.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.189178155"},
{axis:"Unemployment",value:"8"}]
    },
{className:"Malawi",
axes: [
{axis:"Inflation",value:"27.28333333"},
{axis:"Deposit Interest Rate",value:"18.40972222"},
{axis:"Lending Interest Rate",value:"46.01117424"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.199999998"},
{axis:"Unemployment",value:"7.599999905"}]
    },
{className:"Malaysia",
axes: [
{axis:"Inflation",value:"2.105012312"},
{axis:"Deposit Interest Rate",value:"2.97"},
{axis:"Lending Interest Rate",value:"4.6125"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.713453716"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"North America",
axes: [
{axis:"Inflation",value:"1.201562277"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"72.82339742"},
{axis:"GDP",value:"1.559846278"},
{axis:"Unemployment",value:"7.367351501"}]
    },
{className:"Namibia",
axes: [
{axis:"Inflation",value:"5.600925023"},
{axis:"Deposit Interest Rate",value:"3.9775"},
{axis:"Lending Interest Rate",value:"8.289166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.654561701"},
{axis:"Unemployment",value:"19"}]
    },
{className:"Niger",
axes: [
{axis:"Inflation",value:"2.298521698"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.268378734"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Nigeria",
axes: [
{axis:"Inflation",value:"8.475827285"},
{axis:"Deposit Interest Rate",value:"7.945"},
{axis:"Lending Interest Rate",value:"16.7225"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.394416311"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Nicaragua",
axes: [
{axis:"Inflation",value:"7.135380793"},
{axis:"Deposit Interest Rate",value:"1.010510547"},
{axis:"Lending Interest Rate",value:"14.98460189"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.533235949"},
{axis:"Unemployment",value:"5.300000191"}]
    },
{className:"Netherlands",
axes: [
{axis:"Inflation",value:"2.506898527"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"68.27290787"},
{axis:"GDP",value:"-0.495377915"},
{axis:"Unemployment",value:"6.699999809"}]
    },
{className:"Norway",
axes: [
{axis:"Inflation",value:"2.131709174"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"20.93721733"},
{axis:"GDP",value:"0.99870545"},
{axis:"Unemployment",value:"3.5"}]
    },
{className:"Nepal",
axes: [
{axis:"Inflation",value:"9.042681456"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.128877676"},
{axis:"Unemployment",value:"2.700000048"}]
    },
{className:"New Zealand",
axes: [
{axis:"Inflation",value:"1.302862025"},
{axis:"Deposit Interest Rate",value:"3.827016471"},
{axis:"Lending Interest Rate",value:"5.5330696"},
{axis:"Central Government Debt",value:"59.32137789"},
{axis:"GDP",value:"1.579084705"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"Oman",
axes: [
{axis:"Inflation",value:"1.245416982"},
{axis:"Deposit Interest Rate",value:"2.386"},
{axis:"Lending Interest Rate",value:"5.409"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.912783126"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"Pakistan",
axes: [
{axis:"Inflation",value:"7.689503655"},
{axis:"Deposit Interest Rate",value:"7.171666667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.367249451"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Panama",
axes: [
{axis:"Inflation",value:"4.027159916"},
{axis:"Deposit Interest Rate",value:"2.11625"},
{axis:"Lending Interest Rate",value:"6.594166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.624158955"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Peru",
axes: [
{axis:"Inflation",value:"2.816502821"},
{axis:"Deposit Interest Rate",value:"2.324866667"},
{axis:"Lending Interest Rate",value:"18.13925"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.854057072"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Philippines",
axes: [
{axis:"Inflation",value:"2.997694081"},
{axis:"Deposit Interest Rate",value:"1.661833333"},
{axis:"Lending Interest Rate",value:"5.766833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.055272228"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Palau",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.436323367"},
{axis:"Unemployment",value:""}]
    },
{className:"Papua New Guinea",
axes: [
{axis:"Inflation",value:"4.96031746"},
{axis:"Deposit Interest Rate",value:"0.33"},
{axis:"Lending Interest Rate",value:"10.13"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.537412004"},
{axis:"Unemployment",value:"2.5"}]
    },
{className:"Poland",
axes: [
{axis:"Inflation",value:"1.034269836"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"55.59157203"},
{axis:"GDP",value:"1.264705163"},
{axis:"Unemployment",value:"10.39999962"}]
    },
{className:"Puerto Rico",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.577342697"},
{axis:"Unemployment",value:"14.69999981"}]
    },
{className:"Portugal",
axes: [
{axis:"Inflation",value:"0.274416667"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"138.0460028"},
{axis:"GDP",value:"-1.130155829"},
{axis:"Unemployment",value:"16.5"}]
    },
{className:"Paraguay",
axes: [
{axis:"Inflation",value:"2.683857387"},
{axis:"Deposit Interest Rate",value:"4.24"},
{axis:"Lending Interest Rate",value:"19.27057315"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"14.03627767"},
{axis:"Unemployment",value:"5"}]
    },
{className:"Qatar",
axes: [
{axis:"Inflation",value:"3.131571042"},
{axis:"Deposit Interest Rate",value:"1.417838796"},
{axis:"Lending Interest Rate",value:"5.112674134"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.58167359"},
{axis:"Unemployment",value:"0.300000012"}]
    },
{className:"Romania",
axes: [
{axis:"Inflation",value:"3.985359902"},
{axis:"Deposit Interest Rate",value:"4.550833333"},
{axis:"Lending Interest Rate",value:"10.5225"},
{axis:"Central Government Debt",value:"41.50278607"},
{axis:"GDP",value:"3.531603199"},
{axis:"Unemployment",value:"7.300000191"}]
    },
{className:"Russian Federation",
axes: [
{axis:"Inflation",value:"6.776457883"},
{axis:"Deposit Interest Rate",value:"5.591666667"},
{axis:"Lending Interest Rate",value:"9.466666667"},
{axis:"Central Government Debt",value:"12.67799879"},
{axis:"GDP",value:"1.279453911"},
{axis:"Unemployment",value:"5.5"}]
    },
{className:"Rwanda",
axes: [
{axis:"Inflation",value:"4.234780151"},
{axis:"Deposit Interest Rate",value:"8.58"},
{axis:"Lending Interest Rate",value:"16.93"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.684512428"},
{axis:"Unemployment",value:"0.600000024"}]
    },
{className:"South Asia",
axes: [
{axis:"Inflation",value:"7.592144695"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.266686681"},
{axis:"Unemployment",value:"3.908677612"}]
    },
{className:"Saudi Arabia",
axes: [
{axis:"Inflation",value:"3.506263617"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.669911395"},
{axis:"Unemployment",value:"5.699999809"}]
    },
{className:"Sudan",
axes: [
{axis:"Inflation",value:"29.95860642"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.299999857"},
{axis:"Unemployment",value:"14.60000038"}]
    },
{className:"Senegal",
axes: [
{axis:"Inflation",value:"0.698626837"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.485217346"},
{axis:"Unemployment",value:"10.30000019"}]
    },
{className:"Singapore",
axes: [
{axis:"Inflation",value:"2.378490176"},
{axis:"Deposit Interest Rate",value:"0.14"},
{axis:"Lending Interest Rate",value:"5.38"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.67547762"},
{axis:"Unemployment",value:"2.799999952"}]
    },
{className:"Solomon Islands",
axes: [
{axis:"Inflation",value:"5.391363886"},
{axis:"Deposit Interest Rate",value:"0.291608986"},
{axis:"Lending Interest Rate",value:"10.77394761"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.014386846"},
{axis:"Unemployment",value:"3.799999952"}]
    },
{className:"Sierra Leone",
axes: [
{axis:"Inflation",value:"10.26641371"},
{axis:"Deposit Interest Rate",value:"8.909166667"},
{axis:"Lending Interest Rate",value:"20.56"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"20.48744024"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"El Salvador",
axes: [
{axis:"Inflation",value:"0.792509315"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"55.85748371"},
{axis:"GDP",value:"1.847286731"},
{axis:"Unemployment",value:"5.900000095"}]
    },
{className:"San Marino",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Somalia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Serbia",
axes: [
{axis:"Inflation",value:"7.694263629"},
{axis:"Deposit Interest Rate",value:"7.92"},
{axis:"Lending Interest Rate",value:"17.07"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.571734107"},
{axis:"Unemployment",value:"22.10000038"}]
    },
{className:"Sao Tome and Principe",
axes: [
{axis:"Inflation",value:"8.106292728"},
{axis:"Deposit Interest Rate",value:"9.38"},
{axis:"Lending Interest Rate",value:"23.28"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.186074416"},
{axis:"Unemployment",value:""}]
    },
{className:"Suriname",
axes: [
{axis:"Inflation",value:"1.91719888"},
{axis:"Deposit Interest Rate",value:"7.091666667"},
{axis:"Lending Interest Rate",value:"11.98333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.837741968"},
{axis:"Unemployment",value:"4.800000191"}]
    },
{className:"Slovak Republic",
axes: [
{axis:"Inflation",value:"1.40047369"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"63.20000379"},
{axis:"GDP",value:"1.427984633"},
{axis:"Unemployment",value:"14.19999981"}]
    },
{className:"Slovenia",
axes: [
{axis:"Inflation",value:"1.760351239"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.057865675"},
{axis:"Unemployment",value:"10.19999981"}]
    },
{className:"Sweden",
axes: [
{axis:"Inflation",value:"-0.04429297"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"41.98058892"},
{axis:"GDP",value:"1.241204917"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Swaziland",
axes: [
{axis:"Inflation",value:"5.619599417"},
{axis:"Deposit Interest Rate",value:"2.08"},
{axis:"Lending Interest Rate",value:"8.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.949144427"},
{axis:"Unemployment",value:"22.29999924"}]
    },
{className:"Seychelles",
axes: [
{axis:"Inflation",value:"4.338938483"},
{axis:"Deposit Interest Rate",value:"3.42883589"},
{axis:"Lending Interest Rate",value:"12.28683447"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.049822064"},
{axis:"Unemployment",value:""}]
    },
{className:"Syrian Arab Republic",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"11.30000019"}]
    },
{className:"Chad",
axes: [
{axis:"Inflation",value:"0.145451048"},
{axis:"Deposit Interest Rate",value:"3.208333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.700001363"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"East Asia and Pacific (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"2.997694081"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.136696214"},
{axis:"Unemployment",value:"4.53004765"}]
    },
{className:"Europe and Central Asia (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.985359902"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.379756511"},
{axis:"Unemployment",value:"8.068316385"}]
    },
{className:"Togo",
axes: [
{axis:"Inflation",value:"1.766766021"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.967792633"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Thailand",
axes: [
{axis:"Inflation",value:"2.184041934"},
{axis:"Deposit Interest Rate",value:"2.883333333"},
{axis:"Lending Interest Rate",value:"6.958333333"},
{axis:"Central Government Debt",value:"29.25031745"},
{axis:"GDP",value:"2.70211729"},
{axis:"Unemployment",value:"0.699999988"}]
    },
{className:"Tajikistan",
axes: [
{axis:"Inflation",value:"5.009646453"},
{axis:"Deposit Interest Rate",value:"6.578818848"},
{axis:"Lending Interest Rate",value:"24.33416667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.40000057"},
{axis:"Unemployment",value:"11.19999981"}]
    },
{className:"Turkmenistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.2000001"},
{axis:"Unemployment",value:"10.69999981"}]
    },
{className:"Latin America and the Caribbean (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.311446322"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.845807725"},
{axis:"Unemployment",value:"6.2975681"}]
    },
{className:"Middle East and North Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"4.830067361"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.935085788"},
{axis:"Unemployment",value:"12.66741726"}]
    },
{className:"Timor-Leste",
axes: [
{axis:"Inflation",value:"11.15662246"},
{axis:"Deposit Interest Rate",value:"0.900322602"},
{axis:"Lending Interest Rate",value:"12.4128209"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.757352941"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Tonga",
axes: [
{axis:"Inflation",value:"0.712058511"},
{axis:"Deposit Interest Rate",value:"2.732590911"},
{axis:"Lending Interest Rate",value:"9.663251452"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.675541923"},
{axis:"Unemployment",value:""}]
    },
{className:"South Asia (IDA and IBRD)",
axes: [
{axis:"Inflation",value:"7.592144695"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.266686681"},
{axis:"Unemployment",value:"3.908677612"}]
    },
{className:"Sub-Saharan Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"4.633639597"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.74264319"},
{axis:"Unemployment",value:"7.912281555"}]
    },
{className:"Trinidad and Tobago",
axes: [
{axis:"Inflation",value:"5.199817405"},
{axis:"Deposit Interest Rate",value:"1.5"},
{axis:"Lending Interest Rate",value:"7.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.739760541"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Tunisia",
axes: [
{axis:"Inflation",value:"5.798544619"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.299999969"},
{axis:"Unemployment",value:"13.30000019"}]
    },
{className:"Turkey",
axes: [
{axis:"Inflation",value:"7.493090305"},
{axis:"Deposit Interest Rate",value:"15.76333333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"38.01021442"},
{axis:"GDP",value:"4.192509347"},
{axis:"Unemployment",value:"8.699999809"}]
    },
{className:"Tuvalu",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.298187614"},
{axis:"Unemployment",value:""}]
    },
{className:"Tanzania",
axes: [
{axis:"Inflation",value:"7.870723646"},
{axis:"Deposit Interest Rate",value:"9.818030898"},
{axis:"Lending Interest Rate",value:"15.83487943"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.26306003"},
{axis:"Unemployment",value:"2.900000095"}]
    },
{className:"Uganda",
axes: [
{axis:"Inflation",value:"5.464401872"},
{axis:"Deposit Interest Rate",value:"11.8407882"},
{axis:"Lending Interest Rate",value:"23.25140199"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.270736613"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Ukraine",
axes: [
{axis:"Inflation",value:"-0.276243094"},
{axis:"Deposit Interest Rate",value:"10.77735"},
{axis:"Lending Interest Rate",value:"16.6492"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Uruguay",
axes: [
{axis:"Inflation",value:"8.57513504"},
{axis:"Deposit Interest Rate",value:"4.64794079"},
{axis:"Lending Interest Rate",value:"12.43406496"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.63753863"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"United States",
axes: [
{axis:"Inflation",value:"1.464832656"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"3.25"},
{axis:"Central Government Debt",value:"96.76251083"},
{axis:"GDP",value:"1.489524949"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Uzbekistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8"},
{axis:"Unemployment",value:"10.80000019"}]
    },
{className:"St Vincent and the Grenadines",
axes: [
{axis:"Inflation",value:"0.805127804"},
{axis:"Deposit Interest Rate",value:"2.733122015"},
{axis:"Lending Interest Rate",value:"9.439781329"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.670008481"},
{axis:"Unemployment",value:""}]
    },
{className:"Venezuela",
axes: [
{axis:"Inflation",value:"40.63942752"},
{axis:"Deposit Interest Rate",value:"14.50333333"},
{axis:"Lending Interest Rate",value:"15.895"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.343094036"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Vietnam",
axes: [
{axis:"Inflation",value:"6.592255898"},
{axis:"Deposit Interest Rate",value:"7.14"},
{axis:"Lending Interest Rate",value:"10.37416667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.421882991"},
{axis:"Unemployment",value:"2.200000048"}]
    },
{className:"Vanuatu",
axes: [
{axis:"Inflation",value:"1.446143318"},
{axis:"Deposit Interest Rate",value:"1.25"},
{axis:"Lending Interest Rate",value:"5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.96914608"},
{axis:"Unemployment",value:""}]
    },
{className:"West Bank and Gaza",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.6225"},
{axis:"Lending Interest Rate",value:"7.515"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-4.280020715"},
{axis:"Unemployment",value:"23.39999962"}]
    },
{className:"World",
axes: [
{axis:"Inflation",value:"2.702702703"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.3929521"},
{axis:"Unemployment",value:"5.99341815"}]
    },
{className:"Samoa",
axes: [
{axis:"Inflation",value:"0.610085721"},
{axis:"Deposit Interest Rate",value:"2.880833333"},
{axis:"Lending Interest Rate",value:"10.20083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.933858756"},
{axis:"Unemployment",value:""}]
    },
{className:"Yemen",
axes: [
{axis:"Inflation",value:"10.96844215"},
{axis:"Deposit Interest Rate",value:"15.25"},
{axis:"Lending Interest Rate",value:"22.08333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.155705526"},
{axis:"Unemployment",value:"17.70000076"}]
    },
{className:"South Africa",
axes: [
{axis:"Inflation",value:"5.445279482"},
{axis:"Deposit Interest Rate",value:"5.1525"},
{axis:"Lending Interest Rate",value:"8.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.212354431"},
{axis:"Unemployment",value:"24.60000038"}]
    },
{className:"Democratic Republic of the Congo",
axes: [
{axis:"Inflation",value:"1.632925411"},
{axis:"Deposit Interest Rate",value:"4.709"},
{axis:"Lending Interest Rate",value:"19.3660119"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.503503317"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Zambia",
axes: [
{axis:"Inflation",value:"6.977676055"},
{axis:"Deposit Interest Rate",value:"6.490859877"},
{axis:"Lending Interest Rate",value:"9.520833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.131819138"},
{axis:"Unemployment",value:"13.10000038"}]
    },
{className:"Zimbabwe",
axes: [
{axis:"Inflation",value:"1.631622019"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.484095146"},
{axis:"Unemployment",value:"5.300000191"}]
    }
],

["2014",
{className:"Aruba",
axes: [
{axis:"Inflation",value:"0.420998172"},
{axis:"Deposit Interest Rate",value:"2.175"},
{axis:"Lending Interest Rate",value:"8.233333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Andorra",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Afghanistan",
axes: [
{axis:"Inflation",value:"4.604334009"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"15"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.312530908"},
{axis:"Unemployment",value:"9.100000381"}]
    },
{className:"Angola",
axes: [
{axis:"Inflation",value:"7.279561541"},
{axis:"Deposit Interest Rate",value:"3.526964417"},
{axis:"Lending Interest Rate",value:"16.38227094"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.804472704"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Albania",
axes: [
{axis:"Inflation",value:"1.631777988"},
{axis:"Deposit Interest Rate",value:"1.914729676"},
{axis:"Lending Interest Rate",value:"8.658617478"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2"},
{axis:"Unemployment",value:"16.10000038"}]
    },
{className:"United Arab Emirates",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.570289721"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Argentina",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"20.41768368"},
{axis:"Lending Interest Rate",value:"24.00916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.558477446"},
{axis:"Unemployment",value:"8.199999809"}]
    },
{className:"Armenia",
axes: [
{axis:"Inflation",value:"2.980988073"},
{axis:"Deposit Interest Rate",value:"10.42578503"},
{axis:"Lending Interest Rate",value:"16.40866526"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.499999999"},
{axis:"Unemployment",value:"17.10000038"}]
    },
{className:"Antigua and Barbuda",
axes: [
{axis:"Inflation",value:"1.089441574"},
{axis:"Deposit Interest Rate",value:"2.893393954"},
{axis:"Lending Interest Rate",value:"10.07183771"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.821980293"},
{axis:"Unemployment",value:""}]
    },
{className:"Australia",
axes: [
{axis:"Inflation",value:"2.487922705"},
{axis:"Deposit Interest Rate",value:"2.904166667"},
{axis:"Lending Interest Rate",value:"5.95"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.499851222"},
{axis:"Unemployment",value:"6"}]
    },
{className:"Austria",
axes: [
{axis:"Inflation",value:"1.605805605"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.353471066"},
{axis:"Unemployment",value:"5"}]
    },
{className:"Azerbaijan",
axes: [
{axis:"Inflation",value:"1.385028931"},
{axis:"Deposit Interest Rate",value:"9.171666667"},
{axis:"Lending Interest Rate",value:"17.8575"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"Burundi",
axes: [
{axis:"Inflation",value:"4.379840041"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"15.66833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.660918184"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Belgium",
axes: [
{axis:"Inflation",value:"0.34"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.295473353"},
{axis:"Unemployment",value:"8.5"}]
    },
{className:"Benin",
axes: [
{axis:"Inflation",value:"-1.085744469"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.541486651"},
{axis:"Unemployment",value:"1"}]
    },
{className:"Burkina Faso",
axes: [
{axis:"Inflation",value:"-0.258089518"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.047796031"},
{axis:"Unemployment",value:"3.099999905"}]
    },
{className:"Bangladesh",
axes: [
{axis:"Inflation",value:"6.991165327"},
{axis:"Deposit Interest Rate",value:"9.8"},
{axis:"Lending Interest Rate",value:"12.945"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.061093054"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Bulgaria",
axes: [
{axis:"Inflation",value:"-1.418122662"},
{axis:"Deposit Interest Rate",value:"1.655816667"},
{axis:"Lending Interest Rate",value:"8.276716667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.55"},
{axis:"Unemployment",value:"11.60000038"}]
    },
{className:"Bahrain",
axes: [
{axis:"Inflation",value:"2.651195499"},
{axis:"Deposit Interest Rate",value:"0.981666667"},
{axis:"Lending Interest Rate",value:"5.868333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.480935152"},
{axis:"Unemployment",value:"3.900000095"}]
    },
{className:"The Bahamas",
axes: [
{axis:"Inflation",value:"1.504464399"},
{axis:"Deposit Interest Rate",value:"1.4175"},
{axis:"Lending Interest Rate",value:"4.75"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.022786105"},
{axis:"Unemployment",value:"15.39999962"}]
    },
{className:"Bosnia and Herzegovina",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.661785471"},
{axis:"Lending Interest Rate",value:"6.641508639"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.081875932"},
{axis:"Unemployment",value:"27.89999962"}]
    },
{className:"Belarus",
axes: [
{axis:"Inflation",value:"18.11955435"},
{axis:"Deposit Interest Rate",value:"18.58333333"},
{axis:"Lending Interest Rate",value:"18.74166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.723086003"},
{axis:"Unemployment",value:"5.900000095"}]
    },
{className:"Belize",
axes: [
{axis:"Inflation",value:"1.201399645"},
{axis:"Deposit Interest Rate",value:"2.897061368"},
{axis:"Lending Interest Rate",value:"10.82178318"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.081916492"},
{axis:"Unemployment",value:"11.5"}]
    },
{className:"Bermuda",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Bolivia",
axes: [
{axis:"Inflation",value:"5.783563722"},
{axis:"Deposit Interest Rate",value:"2.950136805"},
{axis:"Lending Interest Rate",value:"9.694228216"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.460569752"},
{axis:"Unemployment",value:"2.700000048"}]
    },
{className:"Brazil",
axes: [
{axis:"Inflation",value:"6.332092342"},
{axis:"Deposit Interest Rate",value:"10.0236351"},
{axis:"Lending Interest Rate",value:"32.00833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.103371359"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Barbados",
axes: [
{axis:"Inflation",value:"1.887170246"},
{axis:"Deposit Interest Rate",value:"2.509166667"},
{axis:"Lending Interest Rate",value:"8.383333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.180342651"},
{axis:"Unemployment",value:"12"}]
    },
{className:"Brunei Darussalam",
axes: [
{axis:"Inflation",value:"-0.194426292"},
{axis:"Deposit Interest Rate",value:"0.3"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.339999835"},
{axis:"Unemployment",value:"3.799999952"}]
    },
{className:"Bhutan",
axes: [
{axis:"Inflation",value:"8.206545146"},
{axis:"Deposit Interest Rate",value:"4"},
{axis:"Lending Interest Rate",value:"14.15"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.458817312"},
{axis:"Unemployment",value:"2.799999952"}]
    },
{className:"Botswana",
axes: [
{axis:"Inflation",value:"4.40313594"},
{axis:"Deposit Interest Rate",value:"2.534375"},
{axis:"Lending Interest Rate",value:"9"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.203915093"},
{axis:"Unemployment",value:"18.20000076"}]
    },
{className:"Central African Republic",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.6"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.257108489"},
{axis:"Unemployment",value:"7.400000095"}]
    },
{className:"Canada",
axes: [
{axis:"Inflation",value:"1.906635907"},
{axis:"Deposit Interest Rate",value:"0.55"},
{axis:"Lending Interest Rate",value:"3"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.472892638"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Central Europe and the Baltics",
axes: [
{axis:"Inflation",value:"0.106494137"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.772204032"},
{axis:"Unemployment",value:"9.063863362"}]
    },
{className:"Switzerland",
axes: [
{axis:"Inflation",value:"-0.013186044"},
{axis:"Deposit Interest Rate",value:"0.02"},
{axis:"Lending Interest Rate",value:"2.69"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.889476944"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Chile",
axes: [
{axis:"Inflation",value:"4.395"},
{axis:"Deposit Interest Rate",value:"3.919105175"},
{axis:"Lending Interest Rate",value:"8.098058248"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.876395397"},
{axis:"Unemployment",value:"6.400000095"}]
    },
{className:"China",
axes: [
{axis:"Inflation",value:"1.996847084"},
{axis:"Deposit Interest Rate",value:"2.75"},
{axis:"Lending Interest Rate",value:"5.6"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.268513241"},
{axis:"Unemployment",value:"4.699999809"}]
    },
{className:"Cote dIvoire",
axes: [
{axis:"Inflation",value:"0.45303046"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.546467852"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Cameroon",
axes: [
{axis:"Inflation",value:"1.947948268"},
{axis:"Deposit Interest Rate",value:"2.6"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.926964959"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Republic of Congo",
axes: [
{axis:"Inflation",value:"0.077160494"},
{axis:"Deposit Interest Rate",value:"2.6"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.779940953"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Colombia",
axes: [
{axis:"Inflation",value:"2.877810251"},
{axis:"Deposit Interest Rate",value:"4.08940715"},
{axis:"Lending Interest Rate",value:"10.86733504"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.385710901"},
{axis:"Unemployment",value:"10.10000038"}]
    },
{className:"Comoros",
axes: [
{axis:"Inflation",value:"0.578747502"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"10.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.061639469"},
{axis:"Unemployment",value:"6.5"}]
    },
{className:"Cabo Verde",
axes: [
{axis:"Inflation",value:"-0.243630795"},
{axis:"Deposit Interest Rate",value:"3.48231365"},
{axis:"Lending Interest Rate",value:"10.89375653"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.799846803"},
{axis:"Unemployment",value:"9.199999809"}]
    },
{className:"Costa Rica",
axes: [
{axis:"Inflation",value:"4.515312677"},
{axis:"Deposit Interest Rate",value:"3.322777778"},
{axis:"Lending Interest Rate",value:"14.90305556"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.502352231"},
{axis:"Unemployment",value:"8.300000191"}]
    },
{className:"Caribbean small states",
axes: [
{axis:"Inflation",value:"1.201399645"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.282425682"},
{axis:"Unemployment",value:"10.40517882"}]
    },
{className:"Cuba",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Cyprus",
axes: [
{axis:"Inflation",value:"-1.354988854"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.497056608"},
{axis:"Unemployment",value:"15.60000038"}]
    },
{className:"Czech Republic",
axes: [
{axis:"Inflation",value:"0.337186898"},
{axis:"Deposit Interest Rate",value:"0.701499898"},
{axis:"Lending Interest Rate",value:"4.644905464"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.978154045"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"Germany",
axes: [
{axis:"Inflation",value:"0.906797035"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.599770392"},
{axis:"Unemployment",value:"5"}]
    },
{className:"Djibouti",
axes: [
{axis:"Inflation",value:"2.887276145"},
{axis:"Deposit Interest Rate",value:"1.2375"},
{axis:"Lending Interest Rate",value:"12.69"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.000194324"},
{axis:"Unemployment",value:""}]
    },
{className:"Dominica",
axes: [
{axis:"Inflation",value:"0.799139764"},
{axis:"Deposit Interest Rate",value:"2.874717528"},
{axis:"Lending Interest Rate",value:"8.936633142"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.878583474"},
{axis:"Unemployment",value:""}]
    },
{className:"Denmark",
axes: [
{axis:"Inflation",value:"0.56402054"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.261905838"},
{axis:"Unemployment",value:"6.599999905"}]
    },
{className:"Dominican Republic",
axes: [
{axis:"Inflation",value:"2.998642261"},
{axis:"Deposit Interest Rate",value:"6.726666667"},
{axis:"Lending Interest Rate",value:"13.9025"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.340878365"},
{axis:"Unemployment",value:"15"}]
    },
{className:"Algeria",
axes: [
{axis:"Inflation",value:"2.916406413"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.8"},
{axis:"Unemployment",value:"9.5"}]
    },
{className:"East Asia and Pacific (excluding high income)",
axes: [
{axis:"Inflation",value:"3.855238553"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.722531263"},
{axis:"Unemployment",value:"4.58378611"}]
    },
{className:"East Asia and Pacific",
axes: [
{axis:"Inflation",value:"2.748854644"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.996192527"},
{axis:"Unemployment",value:"4.522146493"}]
    },
{className:"Europe and Central Asia (excluding high income)",
axes: [
{axis:"Inflation",value:"3.068812104"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.55474832"},
{axis:"Unemployment",value:"7.61617233"}]
    },
{className:"Europe and Central Asia",
axes: [
{axis:"Inflation",value:"0.60851927"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.408720444"},
{axis:"Unemployment",value:"9.0076516"}]
    },
{className:"Ecuador",
axes: [
{axis:"Inflation",value:"3.57312785"},
{axis:"Deposit Interest Rate",value:"4.0275"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.67498214"},
{axis:"Unemployment",value:"4.599999905"}]
    },
{className:"Egypt",
axes: [
{axis:"Inflation",value:"10.14580055"},
{axis:"Deposit Interest Rate",value:"6.916666667"},
{axis:"Lending Interest Rate",value:"11.70833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.228791014"},
{axis:"Unemployment",value:"13.19999981"}]
    },
{className:"Eritrea",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Spain",
axes: [
{axis:"Inflation",value:"-0.14703181"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.360673017"},
{axis:"Unemployment",value:"24.70000076"}]
    },
{className:"Estonia",
axes: [
{axis:"Inflation",value:"-0.144815519"},
{axis:"Deposit Interest Rate",value:"0.507295714"},
{axis:"Lending Interest Rate",value:"4.763612657"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.906537167"},
{axis:"Unemployment",value:"7.699999809"}]
    },
{className:"Ethiopia",
axes: [
{axis:"Inflation",value:"7.39181448"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.27918702"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"European Union",
axes: [
{axis:"Inflation",value:"0.2205662"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.357815733"},
{axis:"Unemployment",value:"10.20739971"}]
    },
{className:"Finland",
axes: [
{axis:"Inflation",value:"1.041200006"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.698309888"},
{axis:"Unemployment",value:"8.600000381"}]
    },
{className:"Fiji",
axes: [
{axis:"Inflation",value:"0.540328896"},
{axis:"Deposit Interest Rate",value:"1.858552921"},
{axis:"Lending Interest Rate",value:"5.761124822"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.941674542"},
{axis:"Unemployment",value:"7.900000095"}]
    },
{className:"France",
axes: [
{axis:"Inflation",value:"0.507700673"},
{axis:"Deposit Interest Rate",value:"1.145833333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.259494108"},
{axis:"Unemployment",value:"9.899999619"}]
    },
{className:"Federal States of Micronesia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.539166667"},
{axis:"Lending Interest Rate",value:"15.83333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.402898057"},
{axis:"Unemployment",value:""}]
    },
{className:"Gabon",
axes: [
{axis:"Inflation",value:"4.655607891"},
{axis:"Deposit Interest Rate",value:"2.6"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.314877125"},
{axis:"Unemployment",value:"19.70000076"}]
    },
{className:"United Kingdom",
axes: [
{axis:"Inflation",value:"1.460191609"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"0.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.852843317"},
{axis:"Unemployment",value:"6.300000191"}]
    },
{className:"Georgia",
axes: [
{axis:"Inflation",value:"3.068812104"},
{axis:"Deposit Interest Rate",value:"8.425679978"},
{axis:"Lending Interest Rate",value:"11.90971177"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.623331907"},
{axis:"Unemployment",value:"13.39999962"}]
    },
{className:"Ghana",
axes: [
{axis:"Inflation",value:"15.49316807"},
{axis:"Deposit Interest Rate",value:"12.90416667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.985865624"},
{axis:"Unemployment",value:"2.400000095"}]
    },
{className:"Guinea",
axes: [
{axis:"Inflation",value:"9.713977334"},
{axis:"Deposit Interest Rate",value:"13.12625"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.399998601"},
{axis:"Unemployment",value:"1.799999952"}]
    },
{className:"Gambia",
axes: [
{axis:"Inflation",value:"5.947374922"},
{axis:"Deposit Interest Rate",value:"16.51083333"},
{axis:"Lending Interest Rate",value:"28.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.877460551"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Guinea-Bissau",
axes: [
{axis:"Inflation",value:"-1.509244606"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.541075102"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Equatorial Guinea",
axes: [
{axis:"Inflation",value:"4.825089579"},
{axis:"Deposit Interest Rate",value:"2.6"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.284307682"},
{axis:"Unemployment",value:"7.900000095"}]
    },
{className:"Greece",
axes: [
{axis:"Inflation",value:"-1.312242411"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.653982658"},
{axis:"Unemployment",value:"26.29999924"}]
    },
{className:"Grenada",
axes: [
{axis:"Inflation",value:"-0.946757299"},
{axis:"Deposit Interest Rate",value:"2.399541306"},
{axis:"Lending Interest Rate",value:"9.185980402"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.684820479"},
{axis:"Unemployment",value:""}]
    },
{className:"Greenland",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Guatemala",
axes: [
{axis:"Inflation",value:"3.418361697"},
{axis:"Deposit Interest Rate",value:"5.4775"},
{axis:"Lending Interest Rate",value:"13.77333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.174169137"},
{axis:"Unemployment",value:"2.900000095"}]
    },
{className:"Guyana",
axes: [
{axis:"Inflation",value:"0.920769724"},
{axis:"Deposit Interest Rate",value:"1.072916667"},
{axis:"Lending Interest Rate",value:"12.83333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.840915282"},
{axis:"Unemployment",value:"11.10000038"}]
    },
{className:"Hong Kong",
axes: [
{axis:"Inflation",value:"4.430929626"},
{axis:"Deposit Interest Rate",value:"0.01"},
{axis:"Lending Interest Rate",value:"5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.61439406"},
{axis:"Unemployment",value:"3.200000048"}]
    },
{className:"Honduras",
axes: [
{axis:"Inflation",value:"6.129249303"},
{axis:"Deposit Interest Rate",value:"10.82267833"},
{axis:"Lending Interest Rate",value:"20.61221833"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.085214961"},
{axis:"Unemployment",value:"3.900000095"}]
    },
{className:"Croatia",
axes: [
{axis:"Inflation",value:"-0.21519616"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.360434269"},
{axis:"Unemployment",value:"16.70000076"}]
    },
{className:"Haiti",
axes: [
{axis:"Inflation",value:"4.566173531"},
{axis:"Deposit Interest Rate",value:"2.614166667"},
{axis:"Lending Interest Rate",value:"10.77333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.79645782"},
{axis:"Unemployment",value:"6.800000191"}]
    },
{className:"Hungary",
axes: [
{axis:"Inflation",value:"-0.222315061"},
{axis:"Deposit Interest Rate",value:"1.420729749"},
{axis:"Lending Interest Rate",value:"4.447534327"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.67222002"},
{axis:"Unemployment",value:"7.800000191"}]
    },
{className:"Indonesia",
axes: [
{axis:"Inflation",value:"6.394925408"},
{axis:"Deposit Interest Rate",value:"8.7525"},
{axis:"Lending Interest Rate",value:"12.605"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.023889052"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"India",
axes: [
{axis:"Inflation",value:"6.353194544"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"10.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.243471746"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Ireland",
axes: [
{axis:"Inflation",value:"0.196785831"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.199368895"},
{axis:"Unemployment",value:"11.60000038"}]
    },
{className:"Iran",
axes: [
{axis:"Inflation",value:"17.23535868"},
{axis:"Deposit Interest Rate",value:"16.94210723"},
{axis:"Lending Interest Rate",value:"14"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.343343402"},
{axis:"Unemployment",value:"12.80000019"}]
    },
{className:"Iraq",
axes: [
{axis:"Inflation",value:"2.235974079"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.118268061"},
{axis:"Unemployment",value:"16.39999962"}]
    },
{className:"Iceland",
axes: [
{axis:"Inflation",value:"2.034999715"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"7.7425"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.826660454"},
{axis:"Unemployment",value:"5"}]
    },
{className:"Israel",
axes: [
{axis:"Inflation",value:"0.475956015"},
{axis:"Deposit Interest Rate",value:"0.565063059"},
{axis:"Lending Interest Rate",value:"3.586613178"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.599679423"},
{axis:"Unemployment",value:"6.099999905"}]
    },
{className:"Italy",
axes: [
{axis:"Inflation",value:"0.241057543"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"4.866666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.343160836"},
{axis:"Unemployment",value:"12.5"}]
    },
{className:"Jamaica",
axes: [
{axis:"Inflation",value:"8.290005777"},
{axis:"Deposit Interest Rate",value:"5.266688191"},
{axis:"Lending Interest Rate",value:"17.21700864"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.687750718"},
{axis:"Unemployment",value:"13.19999981"}]
    },
{className:"Jordan",
axes: [
{axis:"Inflation",value:"2.891566265"},
{axis:"Deposit Interest Rate",value:"4.519166667"},
{axis:"Lending Interest Rate",value:"8.99"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.096330275"},
{axis:"Unemployment",value:"11.10000038"}]
    },
{className:"Japan",
axes: [
{axis:"Inflation",value:"2.748854644"},
{axis:"Deposit Interest Rate",value:"0.41525"},
{axis:"Lending Interest Rate",value:"1.219166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.031429266"},
{axis:"Unemployment",value:"3.700000048"}]
    },
{className:"Kazakhstan",
axes: [
{axis:"Inflation",value:"6.71830658"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.1"},
{axis:"Unemployment",value:"4.099999905"}]
    },
{className:"Kenya",
axes: [
{axis:"Inflation",value:"6.877498097"},
{axis:"Deposit Interest Rate",value:"8.373379608"},
{axis:"Lending Interest Rate",value:"16.51393071"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.331859404"},
{axis:"Unemployment",value:"9.199999809"}]
    },
{className:"Kyrgyz Republic",
axes: [
{axis:"Inflation",value:"7.534247298"},
{axis:"Deposit Interest Rate",value:"2.711445857"},
{axis:"Lending Interest Rate",value:"22.36143134"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.024038761"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Cambodia",
axes: [
{axis:"Inflation",value:"3.855238553"},
{axis:"Deposit Interest Rate",value:"1.41875"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.071525352"},
{axis:"Unemployment",value:"0.400000006"}]
    },
{className:"St Kitts and Nevis",
axes: [
{axis:"Inflation",value:"0.247865392"},
{axis:"Deposit Interest Rate",value:"3.183687739"},
{axis:"Lending Interest Rate",value:"9.281492191"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.903070938"},
{axis:"Unemployment",value:""}]
    },
{className:"South Korea",
axes: [
{axis:"Inflation",value:"1.272406427"},
{axis:"Deposit Interest Rate",value:"2.535833333"},
{axis:"Lending Interest Rate",value:"4.263333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.341447519"},
{axis:"Unemployment",value:"3.5"}]
    },
{className:"Kosovo",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"1.11"},
{axis:"Lending Interest Rate",value:"9.29"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.218533857"},
{axis:"Unemployment",value:""}]
    },
{className:"Kuwait",
axes: [
{axis:"Inflation",value:"2.908900929"},
{axis:"Deposit Interest Rate",value:"2.02425"},
{axis:"Lending Interest Rate",value:"4.26845"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.622033474"},
{axis:"Unemployment",value:"3"}]
    },
{className:"Latin America and Caribbean (excluding high income)",
axes: [
{axis:"Inflation",value:"3.468419939"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.668636406"},
{axis:"Unemployment",value:"6.543979026"}]
    },
{className:"Lao PDR",
axes: [
{axis:"Inflation",value:"4.13522637"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.515270123"},
{axis:"Unemployment",value:"1.399999976"}]
    },
{className:"Lebanon",
axes: [
{axis:"Inflation",value:"0.749718611"},
{axis:"Deposit Interest Rate",value:"5.913333333"},
{axis:"Lending Interest Rate",value:"7.274166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.810007635"},
{axis:"Unemployment",value:"6.400000095"}]
    },
{className:"Liberia",
axes: [
{axis:"Inflation",value:"9.826358043"},
{axis:"Deposit Interest Rate",value:"4.160833333"},
{axis:"Lending Interest Rate",value:"13.50166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.701141636"},
{axis:"Unemployment",value:"3.799999952"}]
    },
{className:"Libya",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.5"},
{axis:"Lending Interest Rate",value:"6"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-24"},
{axis:"Unemployment",value:"19.20000076"}]
    },
{className:"St Lucia",
axes: [
{axis:"Inflation",value:"3.518478182"},
{axis:"Deposit Interest Rate",value:"2.800228129"},
{axis:"Lending Interest Rate",value:"8.997742389"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.456088954"},
{axis:"Unemployment",value:""}]
    },
{className:"Latin America and Caribbean",
axes: [
{axis:"Inflation",value:"3.404053712"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.74511727"},
{axis:"Unemployment",value:"6.577241937"}]
    },
{className:"Liechtenstein",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Sri Lanka",
axes: [
{axis:"Inflation",value:"3.277825629"},
{axis:"Deposit Interest Rate",value:"8"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.878603033"},
{axis:"Unemployment",value:"4.599999905"}]
    },
{className:"Lesotho",
axes: [
{axis:"Inflation",value:"5.340361677"},
{axis:"Deposit Interest Rate",value:"2.725"},
{axis:"Lending Interest Rate",value:"10.33944444"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.639082752"},
{axis:"Unemployment",value:"26.20000076"}]
    },
{className:"Lithuania",
axes: [
{axis:"Inflation",value:"0.106494137"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.032469985"},
{axis:"Unemployment",value:"11.30000019"}]
    },
{className:"Luxembourg",
axes: [
{axis:"Inflation",value:"0.629749069"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.069293381"},
{axis:"Unemployment",value:"6.099999905"}]
    },
{className:"Latvia",
axes: [
{axis:"Inflation",value:"0.60851927"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.359205218"},
{axis:"Unemployment",value:"10"}]
    },
{className:"Macau",
axes: [
{axis:"Inflation",value:"6.04090194"},
{axis:"Deposit Interest Rate",value:"0.050426669"},
{axis:"Lending Interest Rate",value:"5.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.852104"},
{axis:"Unemployment",value:"1.5"}]
    },
{className:"Morocco",
axes: [
{axis:"Inflation",value:"0.435456491"},
{axis:"Deposit Interest Rate",value:"3.8925"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.417081182"},
{axis:"Unemployment",value:"10.19999981"}]
    },
{className:"Monaco",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Moldova",
axes: [
{axis:"Inflation",value:"5.088785832"},
{axis:"Deposit Interest Rate",value:"5.716666667"},
{axis:"Lending Interest Rate",value:"11.0125"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.8"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"Madagascar",
axes: [
{axis:"Inflation",value:"6.080595483"},
{axis:"Deposit Interest Rate",value:"12.4"},
{axis:"Lending Interest Rate",value:"60"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.126165895"},
{axis:"Unemployment",value:"3.599999905"}]
    },
{className:"Maldives",
axes: [
{axis:"Inflation",value:"2.120113096"},
{axis:"Deposit Interest Rate",value:"4.138889292"},
{axis:"Lending Interest Rate",value:"11.41744656"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.480585724"},
{axis:"Unemployment",value:"11.60000038"}]
    },
{className:"Middle East and North Africa",
axes: [
{axis:"Inflation",value:"2.778900849"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.49195606"},
{axis:"Unemployment",value:"11.26297194"}]
    },
{className:"Mexico",
axes: [
{axis:"Inflation",value:"4.018617202"},
{axis:"Deposit Interest Rate",value:"0.84"},
{axis:"Lending Interest Rate",value:"3.551666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.250316467"},
{axis:"Unemployment",value:"4.900000095"}]
    },

{className:"Macedonia",
axes: [
{axis:"Inflation",value:"-0.28101807"},
{axis:"Deposit Interest Rate",value:"3.698610239"},
{axis:"Lending Interest Rate",value:"7.456609104"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.540834345"},
{axis:"Unemployment",value:"27.89999962"}]
    },
{className:"Mali",
axes: [
{axis:"Inflation",value:"0.895009182"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.788725571"},
{axis:"Unemployment",value:"8.100000381"}]
    },
{className:"Malta",
axes: [
{axis:"Inflation",value:"0.311500058"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"5.900000095"}]
    },
{className:"Myanmar",
axes: [
{axis:"Inflation",value:"5.474464713"},
{axis:"Deposit Interest Rate",value:"8"},
{axis:"Lending Interest Rate",value:"13"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.49636586"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"Montenegro",
axes: [
{axis:"Inflation",value:"-0.710514052"},
{axis:"Deposit Interest Rate",value:"2.139366667"},
{axis:"Lending Interest Rate",value:"9.4125"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.783712681"},
{axis:"Unemployment",value:"19.10000038"}]
    },
{className:"Mongolia",
axes: [
{axis:"Inflation",value:"13.02464811"},
{axis:"Deposit Interest Rate",value:"12.31495612"},
{axis:"Lending Interest Rate",value:"19.02543062"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.885225829"},
{axis:"Unemployment",value:"4.800000191"}]
    },

{className:"Mozambique",
axes: [
{axis:"Inflation",value:"2.559748758"},
{axis:"Deposit Interest Rate",value:"8.578018074"},
{axis:"Lending Interest Rate",value:"14.79791667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.434140922"},
{axis:"Unemployment",value:"22.60000038"}]
    },
{className:"Mauritania",
axes: [
{axis:"Inflation",value:"3.535218852"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.206214056"},
{axis:"Unemployment",value:"31"}]
    },
{className:"Mauritius",
axes: [
{axis:"Inflation",value:"3.21769192"},
{axis:"Deposit Interest Rate",value:"6.784166667"},
{axis:"Lending Interest Rate",value:"8.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.624025462"},
{axis:"Unemployment",value:"7.699999809"}]
    },
{className:"Malawi",
axes: [
{axis:"Inflation",value:"24.43367815"},
{axis:"Deposit Interest Rate",value:"13.17455808"},
{axis:"Lending Interest Rate",value:"44.28958333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.700000004"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Malaysia",
axes: [
{axis:"Inflation",value:"3.142990509"},
{axis:"Deposit Interest Rate",value:"3.048107787"},
{axis:"Lending Interest Rate",value:"4.586901235"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.992609342"},
{axis:"Unemployment",value:"2"}]
    },
{className:"North America",
axes: [
{axis:"Inflation",value:"1.764429442"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:"97.54744217"},
{axis:"GDP",value:"2.43225446"},
{axis:"Unemployment",value:"6.276374507"}]
    },
{className:"Namibia",
axes: [
{axis:"Inflation",value:"5.350169669"},
{axis:"Deposit Interest Rate",value:"4.248333333"},
{axis:"Lending Interest Rate",value:"8.699166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.330232139"},
{axis:"Unemployment",value:"18.60000038"}]
    },
{className:"Niger",
axes: [
{axis:"Inflation",value:"-0.92454472"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.049797948"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Nigeria",
axes: [
{axis:"Inflation",value:"8.057382626"},
{axis:"Deposit Interest Rate",value:"9.339166667"},
{axis:"Lending Interest Rate",value:"16.54833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.309718253"},
{axis:"Unemployment",value:"7.5"}]
    },
{className:"Nicaragua",
axes: [
{axis:"Inflation",value:"6.035791868"},
{axis:"Deposit Interest Rate",value:"1.047746747"},
{axis:"Lending Interest Rate",value:"13.53794136"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.565212146"},
{axis:"Unemployment",value:"5.300000191"}]
    },
{className:"Netherlands",
axes: [
{axis:"Inflation",value:"0.97603508"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.011128408"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Norway",
axes: [
{axis:"Inflation",value:"2.025096285"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.214762793"},
{axis:"Unemployment",value:"3.400000095"}]
    },
{className:"Nepal",
axes: [
{axis:"Inflation",value:"8.36797877"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.380583821"},
{axis:"Unemployment",value:"2.700000048"}]
    },
{className:"New Zealand",
axes: [
{axis:"Inflation",value:"0.906599199"},
{axis:"Deposit Interest Rate",value:"4.011666667"},
{axis:"Lending Interest Rate",value:"5.804166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.172835807"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Oman",
axes: [
{axis:"Inflation",value:"1.014014839"},
{axis:"Deposit Interest Rate",value:"2.017"},
{axis:"Lending Interest Rate",value:"5.083"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.894205544"},
{axis:"Unemployment",value:"7.199999809"}]
    },
{className:"Pakistan",
axes: [
{axis:"Inflation",value:"7.191671165"},
{axis:"Deposit Interest Rate",value:"7.265"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.738354944"},
{axis:"Unemployment",value:"5.199999809"}]
    },
{className:"Panama",
axes: [
{axis:"Inflation",value:"2.637829357"},
{axis:"Deposit Interest Rate",value:"2.159166667"},
{axis:"Lending Interest Rate",value:"6.83"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.053334058"},
{axis:"Unemployment",value:"4.300000191"}]
    },
{className:"Peru",
axes: [
{axis:"Inflation",value:"3.226046789"},
{axis:"Deposit Interest Rate",value:"2.312191667"},
{axis:"Lending Interest Rate",value:"15.74331667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.38417296"},
{axis:"Unemployment",value:"4.199999809"}]
    },
{className:"Philippines",
axes: [
{axis:"Inflation",value:"4.104477612"},
{axis:"Deposit Interest Rate",value:"1.228833333"},
{axis:"Lending Interest Rate",value:"5.525916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.132343044"},
{axis:"Unemployment",value:"7.099999905"}]
    },
{className:"Palau",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.256526674"},
{axis:"Unemployment",value:""}]
    },
{className:"Papua New Guinea",
axes: [
{axis:"Inflation",value:"5.207939509"},
{axis:"Deposit Interest Rate",value:"0.331666667"},
{axis:"Lending Interest Rate",value:"9.375833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.533901802"},
{axis:"Unemployment",value:"2.5"}]
    },
{className:"Poland",
axes: [
{axis:"Inflation",value:"0.106951872"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.282538076"},
{axis:"Unemployment",value:"9.199999809"}]
    },
{className:"Puerto Rico",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"14.30000019"}]
    },
{className:"Portugal",
axes: [
{axis:"Inflation",value:"-0.278153367"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.905794225"},
{axis:"Unemployment",value:"14.19999981"}]
    },
{className:"Paraguay",
axes: [
{axis:"Inflation",value:"5.028827675"},
{axis:"Deposit Interest Rate",value:"4.306666667"},
{axis:"Lending Interest Rate",value:"21.18606778"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.722333745"},
{axis:"Unemployment",value:"4.5"}]
    },
{className:"Qatar",
axes: [
{axis:"Inflation",value:"3.082474313"},
{axis:"Deposit Interest Rate",value:"1.351827604"},
{axis:"Lending Interest Rate",value:"4.963923611"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.18377303"},
{axis:"Unemployment",value:"0.300000012"}]
    },
{className:"Romania",
axes: [
{axis:"Inflation",value:"1.068961022"},
{axis:"Deposit Interest Rate",value:"3.02"},
{axis:"Lending Interest Rate",value:"8.465833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.959047007"},
{axis:"Unemployment",value:"7"}]
    },
{className:"Russian Federation",
axes: [
{axis:"Inflation",value:"7.81289507"},
{axis:"Deposit Interest Rate",value:"6.041666667"},
{axis:"Lending Interest Rate",value:"11.14166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.70637056"},
{axis:"Unemployment",value:"5.099999905"}]
    },
{className:"Rwanda",
axes: [
{axis:"Inflation",value:"1.784100412"},
{axis:"Deposit Interest Rate",value:"7.75704154"},
{axis:"Lending Interest Rate",value:"17.66"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.00913242"},
{axis:"Unemployment",value:"0.600000024"}]
    },
{className:"South Asia",
axes: [
{axis:"Inflation",value:"6.672179936"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.852434295"},
{axis:"Unemployment",value:"3.898770718"}]
    },
{className:"Saudi Arabia",
axes: [
{axis:"Inflation",value:"2.670525554"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.638741595"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Sudan",
axes: [
{axis:"Inflation",value:"36.90776377"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.100000262"},
{axis:"Unemployment",value:"14.80000019"}]
    },
{className:"Senegal",
axes: [
{axis:"Inflation",value:"-1.079744817"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.311051022"},
{axis:"Unemployment",value:"10"}]
    },
{className:"Singapore",
axes: [
{axis:"Inflation",value:"1.01010101"},
{axis:"Deposit Interest Rate",value:"0.144166667"},
{axis:"Lending Interest Rate",value:"5.35"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.260015288"},
{axis:"Unemployment",value:"3"}]
    },
{className:"Solomon Islands",
axes: [
{axis:"Inflation",value:"5.165902379"},
{axis:"Deposit Interest Rate",value:"0.245931232"},
{axis:"Lending Interest Rate",value:"10.90995219"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.507426291"},
{axis:"Unemployment",value:"3.900000095"}]
    },
{className:"Sierra Leone",
axes: [
{axis:"Inflation",value:"7.329444388"},
{axis:"Deposit Interest Rate",value:"6.605902778"},
{axis:"Lending Interest Rate",value:"19.41166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.590841309"},
{axis:"Unemployment",value:"3.299999952"}]
    },
{className:"El Salvador",
axes: [
{axis:"Inflation",value:"1.105775113"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.425262043"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"San Marino",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Somalia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Serbia",
axes: [
{axis:"Inflation",value:"2.082447939"},
{axis:"Deposit Interest Rate",value:"6.81"},
{axis:"Lending Interest Rate",value:"14.81"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.831301107"},
{axis:"Unemployment",value:"22.20000076"}]
    },
{className:"Sao Tome and Principe",
axes: [
{axis:"Inflation",value:"6.987769276"},
{axis:"Deposit Interest Rate",value:"3.383333333"},
{axis:"Lending Interest Rate",value:"15.89832937"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.478554136"},
{axis:"Unemployment",value:""}]
    },
{className:"Suriname",
axes: [
{axis:"Inflation",value:"3.389745726"},
{axis:"Deposit Interest Rate",value:"7.35"},
{axis:"Lending Interest Rate",value:"12.28333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.842909234"},
{axis:"Unemployment",value:"5.599999905"}]
    },
{className:"Slovak Republic",
axes: [
{axis:"Inflation",value:"-0.07616533"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.521909235"},
{axis:"Unemployment",value:"13.30000019"}]
    },
{className:"Slovenia",
axes: [
{axis:"Inflation",value:"0.200074858"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.048362068"},
{axis:"Unemployment",value:"9.5"}]
    },
{className:"Sweden",
axes: [
{axis:"Inflation",value:"-0.179638494"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.266978422"},
{axis:"Unemployment",value:"8"}]
    },
{className:"Swaziland",
axes: [
{axis:"Inflation",value:"5.685266864"},
{axis:"Deposit Interest Rate",value:"2.14"},
{axis:"Lending Interest Rate",value:"8.625"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.450372365"},
{axis:"Unemployment",value:"22.29999924"}]
    },
{className:"Seychelles",
axes: [
{axis:"Inflation",value:"1.385834546"},
{axis:"Deposit Interest Rate",value:"2.333049839"},
{axis:"Lending Interest Rate",value:"11.64816842"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.316985028"},
{axis:"Unemployment",value:""}]
    },
{className:"Syrian Arab Republic",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"10.80000019"}]
    },
{className:"Chad",
axes: [
{axis:"Inflation",value:"1.680835875"},
{axis:"Deposit Interest Rate",value:"2.6"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.899985045"},
{axis:"Unemployment",value:"7"}]
    },
{className:"East Asia and Pacific (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.855238553"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.722531263"},
{axis:"Unemployment",value:"4.590353693"}]
    },
{className:"Europe and Central Asia (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"2.980988073"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.752214122"},
{axis:"Unemployment",value:"7.829583784"}]
    },
{className:"Togo",
axes: [
{axis:"Inflation",value:"0.186716067"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.937491372"},
{axis:"Unemployment",value:"6.900000095"}]
    },
{className:"Thailand",
axes: [
{axis:"Inflation",value:"1.890377125"},
{axis:"Deposit Interest Rate",value:"1.958333333"},
{axis:"Lending Interest Rate",value:"6.771666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.817633102"},
{axis:"Unemployment",value:"0.899999976"}]
    },
{className:"Tajikistan",
axes: [
{axis:"Inflation",value:"6.104427651"},
{axis:"Deposit Interest Rate",value:"5.489515024"},
{axis:"Lending Interest Rate",value:"24.53123634"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.69925066"},
{axis:"Unemployment",value:"10.89999962"}]
    },
{className:"Turkmenistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"10.29999997"},
{axis:"Unemployment",value:"10.5"}]
    },
{className:"Latin America and the Caribbean (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.518478182"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.74516589"},
{axis:"Unemployment",value:"6.595051101"}]
    },
{className:"Middle East and North Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"2.891566265"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.579532982"},
{axis:"Unemployment",value:"12.76012593"}]
    },
{className:"Timor-Leste",
axes: [
{axis:"Inflation",value:"0.443548387"},
{axis:"Deposit Interest Rate",value:"0.852718199"},
{axis:"Lending Interest Rate",value:"12.86648572"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.5"},
{axis:"Unemployment",value:"4.699999809"}]
    },
{className:"Tonga",
axes: [
{axis:"Inflation",value:"2.510876333"},
{axis:"Deposit Interest Rate",value:"2.837049738"},
{axis:"Lending Interest Rate",value:"8.949835338"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.143955465"},
{axis:"Unemployment",value:""}]
    },
{className:"South Asia (IDA and IBRD)",
axes: [
{axis:"Inflation",value:"6.672179936"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.852434295"},
{axis:"Unemployment",value:"3.898770718"}]
    },
{className:"Sub-Saharan Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"4.39148799"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.631527012"},
{axis:"Unemployment",value:"7.970089909"}]
    },
{className:"Trinidad and Tobago",
axes: [
{axis:"Inflation",value:"5.684418146"},
{axis:"Deposit Interest Rate",value:"1.5"},
{axis:"Lending Interest Rate",value:"7.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.816480106"},
{axis:"Unemployment",value:"4"}]
    },
{className:"Tunisia",
axes: [
{axis:"Inflation",value:"4.937735303"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.299999972"},
{axis:"Unemployment",value:"13.30000019"}]
    },
{className:"Turkey",
axes: [
{axis:"Inflation",value:"8.854572714"},
{axis:"Deposit Interest Rate",value:"16.765"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.020118213"},
{axis:"Unemployment",value:"9.199999809"}]
    },
{className:"Tuvalu",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.987889667"},
{axis:"Unemployment",value:""}]
    },
{className:"Tanzania",
axes: [
{axis:"Inflation",value:"6.13161433"},
{axis:"Deposit Interest Rate",value:"9.855261393"},
{axis:"Lending Interest Rate",value:"16.26413585"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.965132962"},
{axis:"Unemployment",value:"3.099999905"}]
    },
{className:"Uganda",
axes: [
{axis:"Inflation",value:"4.288209263"},
{axis:"Deposit Interest Rate",value:"10.80951067"},
{axis:"Lending Interest Rate",value:"21.52754211"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.815273108"},
{axis:"Unemployment",value:"3.799999952"}]
    },
{className:"Ukraine",
axes: [
{axis:"Inflation",value:"12.18836565"},
{axis:"Deposit Interest Rate",value:"12.10025"},
{axis:"Lending Interest Rate",value:"17.71804167"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-6.60000296"},
{axis:"Unemployment",value:"7.699999809"}]
    },
{className:"Uruguay",
axes: [
{axis:"Inflation",value:"8.877353332"},
{axis:"Deposit Interest Rate",value:"4.898054982"},
{axis:"Lending Interest Rate",value:"15.5341402"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.238791229"},
{axis:"Unemployment",value:"7"}]
    },
{className:"United States",
axes: [
{axis:"Inflation",value:"1.622222977"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"3.25"},
{axis:"Central Government Debt",value:"97.54744217"},
{axis:"GDP",value:"2.427795636"},
{axis:"Unemployment",value:"6.199999809"}]
    },
{className:"Uzbekistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.1"},
{axis:"Unemployment",value:"10.60000038"}]
    },
{className:"St Vincent and the Grenadines",
axes: [
{axis:"Inflation",value:"0.193858561"},
{axis:"Deposit Interest Rate",value:"2.637101225"},
{axis:"Lending Interest Rate",value:"9.146008452"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.656613575"},
{axis:"Unemployment",value:""}]
    },
{className:"Venezuela",
axes: [
{axis:"Inflation",value:"62.16864998"},
{axis:"Deposit Interest Rate",value:"14.68166667"},
{axis:"Lending Interest Rate",value:"17.21166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.894386475"},
{axis:"Unemployment",value:"8.600000381"}]
    },
{className:"Vietnam",
axes: [
{axis:"Inflation",value:"4.085899941"},
{axis:"Deposit Interest Rate",value:"5.7575"},
{axis:"Lending Interest Rate",value:"8.665"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.983654637"},
{axis:"Unemployment",value:"2.299999952"}]
    },
{className:"Vanuatu",
axes: [
{axis:"Inflation",value:"0.798863838"},
{axis:"Deposit Interest Rate",value:"1.104166667"},
{axis:"Lending Interest Rate",value:"4.691666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.304347102"},
{axis:"Unemployment",value:""}]
    },
{className:"West Bank and Gaza",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.825"},
{axis:"Lending Interest Rate",value:"6.41"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-1.091389245"},
{axis:"Unemployment",value:"26.20000076"}]
    },
{className:"World",
axes: [
{axis:"Inflation",value:"2.660860527"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.612130171"},
{axis:"Unemployment",value:"5.932298644"}]
    },
{className:"Samoa",
axes: [
{axis:"Inflation",value:"-0.406816088"},
{axis:"Deposit Interest Rate",value:"3.02"},
{axis:"Lending Interest Rate",value:"9.980833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.196147337"},
{axis:"Unemployment",value:""}]
    },
{className:"Yemen",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:"17.39999962"}]
    },
{className:"South Africa",
axes: [
{axis:"Inflation",value:"6.375259009"},
{axis:"Deposit Interest Rate",value:"5.800833333"},
{axis:"Lending Interest Rate",value:"9.125"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.548700635"},
{axis:"Unemployment",value:"25.10000038"}]
    },
{className:"Democratic Republic of the Congo",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"4.006666667"},
{axis:"Lending Interest Rate",value:"18.6925"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.969479484"},
{axis:"Unemployment",value:"8"}]
    },
{className:"Zambia",
axes: [
{axis:"Inflation",value:"7.811954417"},
{axis:"Deposit Interest Rate",value:"7.877220557"},
{axis:"Lending Interest Rate",value:"11.57291667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.024890232"},
{axis:"Unemployment",value:"13.30000019"}]
    },
{className:"Zimbabwe",
axes: [
{axis:"Inflation",value:"-0.217286171"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.848290307"},
{axis:"Unemployment",value:"5.400000095"}]
    }
],
["2015",
{className:"Aruba",
axes: [
{axis:"Inflation",value:"0.476485008"},
{axis:"Deposit Interest Rate",value:"1.95"},
{axis:"Lending Interest Rate",value:"8.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Andorra",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Afghanistan",
axes: [
{axis:"Inflation",value:"-1.533846583"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"15"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.519911264"},
{axis:"Unemployment",value:""}]
    },
{className:"Angola",
axes: [
{axis:"Inflation",value:"10.27932672"},
{axis:"Deposit Interest Rate",value:"3.31462018"},
{axis:"Lending Interest Rate",value:"16.8818624"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.997704073"},
{axis:"Unemployment",value:""}]
    },
{className:"Albania",
axes: [
{axis:"Inflation",value:"1.887809532"},
{axis:"Deposit Interest Rate",value:"1.39187012"},
{axis:"Lending Interest Rate",value:"8.70284668"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.56"},
{axis:"Unemployment",value:""}]
    },
{className:"United Arab Emirates",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.182678195"},
{axis:"Unemployment",value:""}]
    },
{className:"Argentina",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"21.16914854"},
{axis:"Lending Interest Rate",value:"24.91583333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.372296017"},
{axis:"Unemployment",value:""}]
    },
{className:"Armenia",
axes: [
{axis:"Inflation",value:"3.726586028"},
{axis:"Deposit Interest Rate",value:"14.14815917"},
{axis:"Lending Interest Rate",value:"17.59033032"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.000000001"},
{axis:"Unemployment",value:""}]
    },
{className:"Antigua and Barbuda",
axes: [
{axis:"Inflation",value:"0.968993459"},
{axis:"Deposit Interest Rate",value:"2.46625"},
{axis:"Lending Interest Rate",value:"9.834"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.664120729"},
{axis:"Unemployment",value:""}]
    },
{className:"Australia",
axes: [
{axis:"Inflation",value:"1.508366722"},
{axis:"Deposit Interest Rate",value:"2.304166667"},
{axis:"Lending Interest Rate",value:"5.575"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.257825112"},
{axis:"Unemployment",value:""}]
    },
{className:"Austria",
axes: [
{axis:"Inflation",value:"0.896566164"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.862105019"},
{axis:"Unemployment",value:""}]
    },
{className:"Azerbaijan",
axes: [
{axis:"Inflation",value:"4.171965726"},
{axis:"Deposit Interest Rate",value:"8.998333333"},
{axis:"Lending Interest Rate",value:"17.53416667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.1"},
{axis:"Unemployment",value:""}]
    },
{className:"Burundi",
axes: [
{axis:"Inflation",value:"5.554204168"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"15.32916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-2.535865642"},
{axis:"Unemployment",value:""}]
    },
{className:"Belgium",
axes: [
{axis:"Inflation",value:"0.56059398"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.373937182"},
{axis:"Unemployment",value:""}]
    },
{className:"Benin",
axes: [
{axis:"Inflation",value:"0.320398718"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.240447102"},
{axis:"Unemployment",value:""}]
    },
{className:"Burkina Faso",
axes: [
{axis:"Inflation",value:"0.954993317"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.979542067"},
{axis:"Unemployment",value:""}]
    },
{className:"Bangladesh",
axes: [
{axis:"Inflation",value:"6.19428023"},
{axis:"Deposit Interest Rate",value:"8.244166667"},
{axis:"Lending Interest Rate",value:"11.70916667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.552633316"},
{axis:"Unemployment",value:""}]
    },
{className:"Bulgaria",
axes: [
{axis:"Inflation",value:"-0.104872333"},
{axis:"Deposit Interest Rate",value:"0.613891667"},
{axis:"Lending Interest Rate",value:"7.484858333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.967135479"},
{axis:"Unemployment",value:""}]
    },
{className:"Bahrain",
axes: [
{axis:"Inflation",value:"1.835993697"},
{axis:"Deposit Interest Rate",value:"0.993333333"},
{axis:"Lending Interest Rate",value:"5.160833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.926567217"},
{axis:"Unemployment",value:""}]
    },
{className:"The Bahamas",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"1.405"},
{axis:"Lending Interest Rate",value:"4.75"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.2204836"},
{axis:"Unemployment",value:""}]
    },
{className:"Bosnia and Herzegovina",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.059663519"},
{axis:"Lending Interest Rate",value:"5.78888799"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.157576299"},
{axis:"Unemployment",value:""}]
    },
{className:"Belarus",
axes: [
{axis:"Inflation",value:"13.53448976"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.887698502"},
{axis:"Unemployment",value:""}]
    },
{className:"Belize",
axes: [
{axis:"Inflation",value:"-0.885281552"},
{axis:"Deposit Interest Rate",value:"2.60059702"},
{axis:"Lending Interest Rate",value:"10.32027993"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.918485814"},
{axis:"Unemployment",value:""}]
    },
{className:"Bermuda",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Bolivia",
axes: [
{axis:"Inflation",value:"4.060963726"},
{axis:"Deposit Interest Rate",value:"1.413897539"},
{axis:"Lending Interest Rate",value:"8.073253797"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.961728072"},
{axis:"Unemployment",value:""}]
    },
{className:"Brazil",
axes: [
{axis:"Inflation",value:"9.027239774"},
{axis:"Deposit Interest Rate",value:"12.62245884"},
{axis:"Lending Interest Rate",value:"43.95833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.847362495"},
{axis:"Unemployment",value:""}]
    },
{className:"Barbados",
axes: [
{axis:"Inflation",value:"-1.061216469"},
{axis:"Deposit Interest Rate",value:"1.3225"},
{axis:"Lending Interest Rate",value:"8.058333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.99009901"},
{axis:"Unemployment",value:""}]
    },
{className:"Brunei Darussalam",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.335832667"},
{axis:"Lending Interest Rate",value:"5.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.5"},
{axis:"Unemployment",value:""}]
    },
{className:"Bhutan",
axes: [
{axis:"Inflation",value:"4.521708543"},
{axis:"Deposit Interest Rate",value:"4"},
{axis:"Lending Interest Rate",value:"13.75"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.254254739"},
{axis:"Unemployment",value:""}]
    },
{className:"Botswana",
axes: [
{axis:"Inflation",value:"3.060357042"},
{axis:"Deposit Interest Rate",value:"2.502291667"},
{axis:"Lending Interest Rate",value:"7.95"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.254733178"},
{axis:"Unemployment",value:""}]
    },
{className:"Central African Republic",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.45"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.48645856"},
{axis:"Unemployment",value:""}]
    },
{className:"Canada",
axes: [
{axis:"Inflation",value:"1.125241361"},
{axis:"Deposit Interest Rate",value:"0.075"},
{axis:"Lending Interest Rate",value:"2.775"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.078268751"},
{axis:"Unemployment",value:""}]
    },
{className:"Central Europe and the Baltics",
axes: [
{axis:"Inflation",value:"-0.456766653"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.397822043"},
{axis:"Unemployment",value:""}]
    },
{className:"Switzerland",
axes: [
{axis:"Inflation",value:"-1.143915069"},
{axis:"Deposit Interest Rate",value:"-0.18"},
{axis:"Lending Interest Rate",value:"2.680833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.909636998"},
{axis:"Unemployment",value:""}]
    },
{className:"Chile",
axes: [
{axis:"Inflation",value:"4.348867283"},
{axis:"Deposit Interest Rate",value:"3.608544045"},
{axis:"Lending Interest Rate",value:"5.514927323"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.066140519"},
{axis:"Unemployment",value:""}]
    },
{className:"China",
axes: [
{axis:"Inflation",value:"1.442555384"},
{axis:"Deposit Interest Rate",value:"1.5"},
{axis:"Lending Interest Rate",value:"4.35"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.9"},
{axis:"Unemployment",value:""}]
    },
{className:"Cote dIvoire",
axes: [
{axis:"Inflation",value:"1.237443262"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8.441713171"},
{axis:"Unemployment",value:""}]
    },
{className:"Cameroon",
axes: [
{axis:"Inflation",value:"2.685982772"},
{axis:"Deposit Interest Rate",value:"2.45"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.239188246"},
{axis:"Unemployment",value:""}]
    },
{className:"Republic of Congo",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.45"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.646447935"},
{axis:"Unemployment",value:""}]
    },
{className:"Colombia",
axes: [
{axis:"Inflation",value:"5.005030657"},
{axis:"Deposit Interest Rate",value:"4.579239182"},
{axis:"Lending Interest Rate",value:"11.44998726"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.081928033"},
{axis:"Unemployment",value:""}]
    },
{className:"Comoros",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"10.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Cabo Verde",
axes: [
{axis:"Inflation",value:"0.132579722"},
{axis:"Deposit Interest Rate",value:"2.867881028"},
{axis:"Lending Interest Rate",value:"10.40582256"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.523108492"},
{axis:"Unemployment",value:""}]
    },
{className:"Costa Rica",
axes: [
{axis:"Inflation",value:"0.79668498"},
{axis:"Deposit Interest Rate",value:"2.370833333"},
{axis:"Lending Interest Rate",value:"14.23333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.757443821"},
{axis:"Unemployment",value:""}]
    },
{className:"Caribbean small states",
axes: [
{axis:"Inflation",value:"-0.885281552"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.322206672"},
{axis:"Unemployment",value:""}]
    },
{className:"Cuba",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Cyprus",
axes: [
{axis:"Inflation",value:"-2.096997691"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.586206341"},
{axis:"Unemployment",value:""}]
    },
{className:"Czech Republic",
axes: [
{axis:"Inflation",value:"0.344782438"},
{axis:"Deposit Interest Rate",value:"0.529332846"},
{axis:"Lending Interest Rate",value:"4.282533329"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.198049657"},
{axis:"Unemployment",value:""}]
    },
{className:"Germany",
axes: [
{axis:"Inflation",value:"0.234429945"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.687723781"},
{axis:"Unemployment",value:""}]
    },
{className:"Djibouti",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Dominica",
axes: [
{axis:"Inflation",value:"-0.749971714"},
{axis:"Deposit Interest Rate",value:"2.44975"},
{axis:"Lending Interest Rate",value:"8.6675"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.75974026"},
{axis:"Unemployment",value:""}]
    },
{className:"Denmark",
axes: [
{axis:"Inflation",value:"0.452034154"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.178551281"},
{axis:"Unemployment",value:""}]
    },
{className:"Dominican Republic",
axes: [
{axis:"Inflation",value:"0.836746347"},
{axis:"Deposit Interest Rate",value:"6.560833333"},
{axis:"Lending Interest Rate",value:"14.87666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.953313621"},
{axis:"Unemployment",value:""}]
    },
{className:"Algeria",
axes: [
{axis:"Inflation",value:"4.784976963"},
{axis:"Deposit Interest Rate",value:"1.75"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.9"},
{axis:"Unemployment",value:""}]
    },
{className:"East Asia and Pacific (excluding high income)",
axes: [
{axis:"Inflation",value:"1.323525489"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.460260277"},
{axis:"Unemployment",value:""}]
    },
{className:"East Asia and Pacific",
axes: [
{axis:"Inflation",value:"1.276227705"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.885800106"},
{axis:"Unemployment",value:""}]
    },
{className:"Europe and Central Asia (excluding high income)",
axes: [
{axis:"Inflation",value:"4.087771966"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.654397251"},
{axis:"Unemployment",value:""}]
    },
{className:"Europe and Central Asia",
axes: [
{axis:"Inflation",value:"0.289606191"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.482482368"},
{axis:"Unemployment",value:""}]
    },
{className:"Ecuador",
axes: [
{axis:"Inflation",value:"3.970219159"},
{axis:"Deposit Interest Rate",value:"4.375"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.290361073"},
{axis:"Unemployment",value:""}]
    },
{className:"Egypt",
axes: [
{axis:"Inflation",value:"10.35748965"},
{axis:"Deposit Interest Rate",value:"6.908333333"},
{axis:"Lending Interest Rate",value:"11.625"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.2"},
{axis:"Unemployment",value:""}]
    },
{className:"Eritrea",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Spain",
axes: [
{axis:"Inflation",value:"-0.501190518"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.214286402"},
{axis:"Unemployment",value:""}]
    },
{className:"Estonia",
axes: [
{axis:"Inflation",value:"-0.456766653"},
{axis:"Deposit Interest Rate",value:"0.503435583"},
{axis:"Lending Interest Rate",value:"4.481133401"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.067840531"},
{axis:"Unemployment",value:""}]
    },
{className:"Ethiopia",
axes: [
{axis:"Inflation",value:"10.13411465"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.607518001"},
{axis:"Unemployment",value:""}]
    },
{className:"European Union",
axes: [
{axis:"Inflation",value:"-0.05853361"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.948759597"},
{axis:"Unemployment",value:""}]
    },
{className:"Finland",
axes: [
{axis:"Inflation",value:"-0.207164371"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.546055314"},
{axis:"Unemployment",value:""}]
    },
{className:"Fiji",
axes: [
{axis:"Inflation",value:"1.370823273"},
{axis:"Deposit Interest Rate",value:"2.515321657"},
{axis:"Lending Interest Rate",value:"5.789299856"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.419565179"},
{axis:"Unemployment",value:""}]
    },
{className:"France",
axes: [
{axis:"Inflation",value:"0.037803733"},
{axis:"Deposit Interest Rate",value:"0.895833333"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.155966989"},
{axis:"Unemployment",value:""}]
    },
{className:"Federal States of Micronesia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.563333333"},
{axis:"Lending Interest Rate",value:"15.93333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Gabon",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.45"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.856683734"},
{axis:"Unemployment",value:""}]
    },
{className:"United Kingdom",
axes: [
{axis:"Inflation",value:"0.050020842"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.329183321"},
{axis:"Unemployment",value:""}]
    },
{className:"Georgia",
axes: [
{axis:"Inflation",value:"4.003578207"},
{axis:"Deposit Interest Rate",value:"8.910206891"},
{axis:"Lending Interest Rate",value:"12.48847546"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.774928095"},
{axis:"Unemployment",value:""}]
    },
{className:"Ghana",
axes: [
{axis:"Inflation",value:"17.1450737"},
{axis:"Deposit Interest Rate",value:"13.33916667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.882704469"},
{axis:"Unemployment",value:""}]
    },
{className:"Guinea",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"6.694525"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.099994528"},
{axis:"Unemployment",value:""}]
    },
{className:"Gambia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Guinea-Bissau",
axes: [
{axis:"Inflation",value:"1.404608873"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.796779831"},
{axis:"Unemployment",value:""}]
    },
{className:"Equatorial Guinea",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.45"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-12.19385266"},
{axis:"Unemployment",value:""}]
    },
{className:"Greece",
axes: [
{axis:"Inflation",value:"-1.735902366"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.231571523"},
{axis:"Unemployment",value:""}]
    },
{className:"Grenada",
axes: [
{axis:"Inflation",value:"-1.382492029"},
{axis:"Deposit Interest Rate",value:"1.82675"},
{axis:"Lending Interest Rate",value:"8.96125"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.410985657"},
{axis:"Unemployment",value:""}]
    },
{className:"Greenland",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Guatemala",
axes: [
{axis:"Inflation",value:"2.388720328"},
{axis:"Deposit Interest Rate",value:"5.465833333"},
{axis:"Lending Interest Rate",value:"13.2275"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.148784475"},
{axis:"Unemployment",value:""}]
    },
{className:"Guyana",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"1.114583333"},
{axis:"Lending Interest Rate",value:"12.83333056"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.005814078"},
{axis:"Unemployment",value:""}]
    },
{className:"Hong Kong",
axes: [
{axis:"Inflation",value:"2.995008319"},
{axis:"Deposit Interest Rate",value:"0.01"},
{axis:"Lending Interest Rate",value:"5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.360550321"},
{axis:"Unemployment",value:""}]
    },
{className:"Honduras",
axes: [
{axis:"Inflation",value:"3.15783118"},
{axis:"Deposit Interest Rate",value:"9.700419167"},
{axis:"Lending Interest Rate",value:"20.65756667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.635262488"},
{axis:"Unemployment",value:""}]
    },
{className:"Croatia",
axes: [
{axis:"Inflation",value:"-0.464499005"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.644613259"},
{axis:"Unemployment",value:""}]
    },
{className:"Haiti",
axes: [
{axis:"Inflation",value:"9.016518813"},
{axis:"Deposit Interest Rate",value:"4.285833333"},
{axis:"Lending Interest Rate",value:"12.92333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.651661377"},
{axis:"Unemployment",value:""}]
    },
{className:"Hungary",
axes: [
{axis:"Inflation",value:"-0.070282476"},
{axis:"Deposit Interest Rate",value:"0.867014243"},
{axis:"Lending Interest Rate",value:"2.90249069"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.938915791"},
{axis:"Unemployment",value:""}]
    },
{className:"Indonesia",
axes: [
{axis:"Inflation",value:"6.363121131"},
{axis:"Deposit Interest Rate",value:"8.336666667"},
{axis:"Lending Interest Rate",value:"12.6625"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.793921304"},
{axis:"Unemployment",value:""}]
    },
{className:"India",
axes: [
{axis:"Inflation",value:"5.872426595"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"10.00833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.570130368"},
{axis:"Unemployment",value:""}]
    },
{className:"Ireland",
axes: [
{axis:"Inflation",value:"-0.294599018"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.811395995"},
{axis:"Unemployment",value:""}]
    },
{className:"Iran",
axes: [
{axis:"Inflation",value:"13.70579975"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Iraq",
axes: [
{axis:"Inflation",value:"-1.187756967"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.1"},
{axis:"Unemployment",value:""}]
    },
{className:"Iceland",
axes: [
{axis:"Inflation",value:"1.631284916"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"7.61"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.957122201"},
{axis:"Unemployment",value:""}]
    },
{className:"Israel",
axes: [
{axis:"Inflation",value:"-0.633122293"},
{axis:"Deposit Interest Rate",value:"0.452366441"},
{axis:"Lending Interest Rate",value:"3.448552608"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.488076224"},
{axis:"Unemployment",value:""}]
    },
{className:"Italy",
axes: [
{axis:"Inflation",value:"0.03878675"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"4.12925"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.759532981"},
{axis:"Unemployment",value:""}]
    },
{className:"Jamaica",
axes: [
{axis:"Inflation",value:"3.677171055"},
{axis:"Deposit Interest Rate",value:"4.896434154"},
{axis:"Lending Interest Rate",value:"16.97650582"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.9"},
{axis:"Unemployment",value:""}]
    },
{className:"Jordan",
axes: [
{axis:"Inflation",value:"-0.872897594"},
{axis:"Deposit Interest Rate",value:"3.499166667"},
{axis:"Lending Interest Rate",value:"8.476666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.382686629"},
{axis:"Unemployment",value:""}]
    },
{className:"Japan",
axes: [
{axis:"Inflation",value:"0.786380219"},
{axis:"Deposit Interest Rate",value:"0.40625"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.472784704"},
{axis:"Unemployment",value:""}]
    },
{className:"Kazakhstan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.2"},
{axis:"Unemployment",value:""}]
    },
{className:"Kenya",
axes: [
{axis:"Inflation",value:"6.582410917"},
{axis:"Deposit Interest Rate",value:"9.188945211"},
{axis:"Lending Interest Rate",value:"16.08661379"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.649197078"},
{axis:"Unemployment",value:""}]
    },
{className:"Kyrgyz Republic",
axes: [
{axis:"Inflation",value:"6.503318391"},
{axis:"Deposit Interest Rate",value:"2.693424288"},
{axis:"Lending Interest Rate",value:"24.24535385"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.469280798"},
{axis:"Unemployment",value:""}]
    },
{className:"Cambodia",
axes: [
{axis:"Inflation",value:"1.221270061"},
{axis:"Deposit Interest Rate",value:"1.418770833"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.036087179"},
{axis:"Unemployment",value:""}]
    },
{className:"St Kitts and Nevis",
axes: [
{axis:"Inflation",value:"-2.30187563"},
{axis:"Deposit Interest Rate",value:"2.7225"},
{axis:"Lending Interest Rate",value:"9.29675"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.618097924"},
{axis:"Unemployment",value:""}]
    },
{className:"South Korea",
axes: [
{axis:"Inflation",value:"0.706162876"},
{axis:"Deposit Interest Rate",value:"1.809166667"},
{axis:"Lending Interest Rate",value:"3.533333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.611935409"},
{axis:"Unemployment",value:""}]
    },
{className:"Kosovo",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"1.15"},
{axis:"Lending Interest Rate",value:"7.69"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.62444573"},
{axis:"Unemployment",value:""}]
    },
{className:"Kuwait",
axes: [
{axis:"Inflation",value:"3.271702481"},
{axis:"Deposit Interest Rate",value:"2.029108333"},
{axis:"Lending Interest Rate",value:"4.276483333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.4"},
{axis:"Unemployment",value:""}]
    },
{className:"Latin America and Caribbean (excluding high income)",
axes: [
{axis:"Inflation",value:"3.129002745"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.841319409"},
{axis:"Unemployment",value:""}]
    },
{className:"Lao PDR",
axes: [
{axis:"Inflation",value:"1.276227705"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.99522552"},
{axis:"Unemployment",value:""}]
    },
{className:"Lebanon",
axes: [
{axis:"Inflation",value:"-3.748891999"},
{axis:"Deposit Interest Rate",value:"5.9775"},
{axis:"Lending Interest Rate",value:"7.090833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.508567042"},
{axis:"Unemployment",value:""}]
    },
{className:"Liberia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"4.050833333"},
{axis:"Lending Interest Rate",value:"13.60666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.297657564"},
{axis:"Unemployment",value:""}]
    },
{className:"Libya",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-10.2"},
{axis:"Unemployment",value:""}]
    },
{className:"St Lucia",
axes: [
{axis:"Inflation",value:"-0.984737964"},
{axis:"Deposit Interest Rate",value:"2.27325"},
{axis:"Lending Interest Rate",value:"8.856"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.760480089"},
{axis:"Unemployment",value:""}]
    },
{className:"Latin America and Caribbean",
axes: [
{axis:"Inflation",value:"2.924822004"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.683008466"},
{axis:"Unemployment",value:""}]
    },
{className:"Liechtenstein",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Sri Lanka",
axes: [
{axis:"Inflation",value:"0.922021962"},
{axis:"Deposit Interest Rate",value:"8"},
{axis:"Lending Interest Rate",value:"8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.785984567"},
{axis:"Unemployment",value:""}]
    },
{className:"Lesotho",
axes: [
{axis:"Inflation",value:"3.175454594"},
{axis:"Deposit Interest Rate",value:"2.335833333"},
{axis:"Lending Interest Rate",value:"10.59083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Lithuania",
axes: [
{axis:"Inflation",value:"-0.879019528"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.593774606"},
{axis:"Unemployment",value:""}]
    },
{className:"Luxembourg",
axes: [
{axis:"Inflation",value:"0.474513795"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.849233222"},
{axis:"Unemployment",value:""}]
    },
{className:"Latvia",
axes: [
{axis:"Inflation",value:"0.201612903"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.886912296"},
{axis:"Unemployment",value:""}]
    },
{className:"Macau",
axes: [
{axis:"Inflation",value:"4.559390763"},
{axis:"Deposit Interest Rate",value:"0.039195664"},
{axis:"Lending Interest Rate",value:"5.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-20.34873256"},
{axis:"Unemployment",value:""}]
    },
{className:"Morocco",
axes: [
{axis:"Inflation",value:"1.557907113"},
{axis:"Deposit Interest Rate",value:"3.801666667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.4"},
{axis:"Unemployment",value:""}]
    },
{className:"Monaco",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Moldova",
axes: [
{axis:"Inflation",value:"9.678609467"},
{axis:"Deposit Interest Rate",value:"11.97070893"},
{axis:"Lending Interest Rate",value:"14.14924417"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.5"},
{axis:"Unemployment",value:""}]
    },
{className:"Madagascar",
axes: [
{axis:"Inflation",value:"7.404002032"},
{axis:"Deposit Interest Rate",value:"15"},
{axis:"Lending Interest Rate",value:"60"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.016568886"},
{axis:"Unemployment",value:""}]
    },
{className:"Maldives",
axes: [
{axis:"Inflation",value:"0.952318842"},
{axis:"Deposit Interest Rate",value:"4.117083216"},
{axis:"Lending Interest Rate",value:"11.10124634"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.513884196"},
{axis:"Unemployment",value:""}]
    },
{className:"Middle East and North Africa",
axes: [
{axis:"Inflation",value:"1.835993697"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.908028787"},
{axis:"Unemployment",value:""}]
    },
{className:"Mexico",
axes: [
{axis:"Inflation",value:"2.720641263"},
{axis:"Deposit Interest Rate",value:"0.589166667"},
{axis:"Lending Interest Rate",value:"3.4225"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.546869971"},
{axis:"Unemployment",value:""}]
    },

{className:"Macedonia",
axes: [
{axis:"Inflation",value:"-0.301279059"},
{axis:"Deposit Interest Rate",value:"2.886194164"},
{axis:"Lending Interest Rate",value:"7.079158056"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.665280374"},
{axis:"Unemployment",value:""}]
    },
{className:"Mali",
axes: [
{axis:"Inflation",value:"1.435735842"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.61105767"},
{axis:"Unemployment",value:""}]
    },
{className:"Malta",
axes: [
{axis:"Inflation",value:"1.099931591"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Myanmar",
axes: [
{axis:"Inflation",value:"10.80343284"},
{axis:"Deposit Interest Rate",value:"8"},
{axis:"Lending Interest Rate",value:"13"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.991270978"},
{axis:"Unemployment",value:""}]
    },
{className:"Montenegro",
axes: [
{axis:"Inflation",value:"1.548691582"},
{axis:"Deposit Interest Rate",value:"1.458083333"},
{axis:"Lending Interest Rate",value:"8.933333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.374693813"},
{axis:"Unemployment",value:""}]
    },
{className:"Mongolia",
axes: [
{axis:"Inflation",value:"5.77594951"},
{axis:"Deposit Interest Rate",value:"12.9787417"},
{axis:"Lending Interest Rate",value:"19.56271702"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.29544361"},
{axis:"Unemployment",value:""}]
    },

{className:"Mozambique",
axes: [
{axis:"Inflation",value:"3.550759674"},
{axis:"Deposit Interest Rate",value:"8.531881511"},
{axis:"Lending Interest Rate",value:"14.8665"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.266542057"},
{axis:"Unemployment",value:""}]
    },
{className:"Mauritania",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Mauritius",
axes: [
{axis:"Inflation",value:"1.286549708"},
{axis:"Deposit Interest Rate",value:"6.085833333"},
{axis:"Lending Interest Rate",value:"8.5"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.500010227"},
{axis:"Unemployment",value:""}]
    },
{className:"Malawi",
axes: [
{axis:"Inflation",value:"21.24592234"},
{axis:"Deposit Interest Rate",value:"11.59469697"},
{axis:"Lending Interest Rate",value:"44.38721591"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.950000002"},
{axis:"Unemployment",value:""}]
    },
{className:"Malaysia",
axes: [
{axis:"Inflation",value:"2.104389802"},
{axis:"Deposit Interest Rate",value:"3.134487179"},
{axis:"Lending Interest Rate",value:"4.58531358"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.952370606"},
{axis:"Unemployment",value:""}]
    },
{className:"North America",
axes: [
{axis:"Inflation",value:"0.621934248"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.2926679"},
{axis:"Unemployment",value:""}]
    },
{className:"Namibia",
axes: [
{axis:"Inflation",value:"3.405773308"},
{axis:"Deposit Interest Rate",value:"4.713333333"},
{axis:"Lending Interest Rate",value:"9.324166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.663774181"},
{axis:"Unemployment",value:""}]
    },
{className:"Niger",
axes: [
{axis:"Inflation",value:"1.006885086"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.605301605"},
{axis:"Unemployment",value:""}]
    },
{className:"Nigeria",
axes: [
{axis:"Inflation",value:"9.017683791"},
{axis:"Deposit Interest Rate",value:"9.148029271"},
{axis:"Lending Interest Rate",value:"16.84883268"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.652693623"},
{axis:"Unemployment",value:""}]
    },
{className:"Nicaragua",
axes: [
{axis:"Inflation",value:"3.999101824"},
{axis:"Deposit Interest Rate",value:"1.047305629"},
{axis:"Lending Interest Rate",value:"12.05235462"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.928954392"},
{axis:"Unemployment",value:""}]
    },
{className:"Netherlands",
axes: [
{axis:"Inflation",value:"0.600248147"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.990584966"},
{axis:"Unemployment",value:""}]
    },
{className:"Norway",
axes: [
{axis:"Inflation",value:"2.17364832"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.598068601"},
{axis:"Unemployment",value:""}]
    },
{className:"Nepal",
axes: [
{axis:"Inflation",value:"7.868908957"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.362953183"},
{axis:"Unemployment",value:""}]
    },
{className:"New Zealand",
axes: [
{axis:"Inflation",value:"0.229837025"},
{axis:"Deposit Interest Rate",value:"3.730833333"},
{axis:"Lending Interest Rate",value:"5.7625"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.39302765"},
{axis:"Unemployment",value:""}]
    },
{className:"Oman",
axes: [
{axis:"Inflation",value:"0.065290133"},
{axis:"Deposit Interest Rate",value:"1.934"},
{axis:"Lending Interest Rate",value:"4.762"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.5"},
{axis:"Unemployment",value:""}]
    },
{className:"Pakistan",
axes: [
{axis:"Inflation",value:"2.539515909"},
{axis:"Deposit Interest Rate",value:"5.9725"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.538100562"},
{axis:"Unemployment",value:""}]
    },
{className:"Panama",
axes: [
{axis:"Inflation",value:"0.125526143"},
{axis:"Deposit Interest Rate",value:"2.135"},
{axis:"Lending Interest Rate",value:"7.455833333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.777393473"},
{axis:"Unemployment",value:""}]
    },
{className:"Peru",
axes: [
{axis:"Inflation",value:"3.555396247"},
{axis:"Deposit Interest Rate",value:"2.289373029"},
{axis:"Lending Interest Rate",value:"16.10582778"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.25689986"},
{axis:"Unemployment",value:""}]
    },
{className:"Philippines",
axes: [
{axis:"Inflation",value:"1.433691756"},
{axis:"Deposit Interest Rate",value:"1.592"},
{axis:"Lending Interest Rate",value:"5.57825"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.805728663"},
{axis:"Unemployment",value:""}]
    },
{className:"Palau",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"9.363091998"},
{axis:"Unemployment",value:""}]
    },
{className:"Papua New Guinea",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.425"},
{axis:"Lending Interest Rate",value:"8.7325"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Poland",
axes: [
{axis:"Inflation",value:"-0.991300366"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.649719131"},
{axis:"Unemployment",value:""}]
    },
{className:"Puerto Rico",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Portugal",
axes: [
{axis:"Inflation",value:"0.487271927"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.454463805"},
{axis:"Unemployment",value:""}]
    },
{className:"Paraguay",
axes: [
{axis:"Inflation",value:"3.129002745"},
{axis:"Deposit Interest Rate",value:"3.5125"},
{axis:"Lending Interest Rate",value:"19.73585618"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.014746509"},
{axis:"Unemployment",value:""}]
    },
{className:"Qatar",
axes: [
{axis:"Inflation",value:"1.883589329"},
{axis:"Deposit Interest Rate",value:"1.611990162"},
{axis:"Lending Interest Rate",value:"4.435962126"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.58277343"},
{axis:"Unemployment",value:""}]
    },
{className:"Romania",
axes: [
{axis:"Inflation",value:"-0.593318715"},
{axis:"Deposit Interest Rate",value:"1.888333333"},
{axis:"Lending Interest Rate",value:"6.7675"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.736683579"},
{axis:"Unemployment",value:""}]
    },
{className:"Russian Federation",
axes: [
{axis:"Inflation",value:"15.52532833"},
{axis:"Deposit Interest Rate",value:"9.195833333"},
{axis:"Lending Interest Rate",value:"15.71666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-3.72667344"},
{axis:"Unemployment",value:""}]
    },
{className:"Rwanda",
axes: [
{axis:"Inflation",value:"2.518087704"},
{axis:"Deposit Interest Rate",value:"7.589181372"},
{axis:"Lending Interest Rate",value:"17.03"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.904203115"},
{axis:"Unemployment",value:""}]
    },
{className:"South Asia",
axes: [
{axis:"Inflation",value:"3.530612226"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.196362456"},
{axis:"Unemployment",value:""}]
    },
{className:"Saudi Arabia",
axes: [
{axis:"Inflation",value:"2.184637068"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.485656413"},
{axis:"Unemployment",value:""}]
    },
{className:"Sudan",
axes: [
{axis:"Inflation",value:"16.91179225"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.43961625"},
{axis:"Unemployment",value:""}]
    },
{className:"Senegal",
axes: [
{axis:"Inflation",value:"0.14510746"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.485194754"},
{axis:"Unemployment",value:""}]
    },
{className:"Singapore",
axes: [
{axis:"Inflation",value:"-0.541666667"},
{axis:"Deposit Interest Rate",value:"0.166666667"},
{axis:"Lending Interest Rate",value:"5.35"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.008372345"},
{axis:"Unemployment",value:""}]
    },
{className:"Solomon Islands",
axes: [
{axis:"Inflation",value:"-0.558559364"},
{axis:"Deposit Interest Rate",value:"0.308519631"},
{axis:"Lending Interest Rate",value:"10.47824631"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.253985586"},
{axis:"Unemployment",value:""}]
    },
{className:"Sierra Leone",
axes: [
{axis:"Inflation",value:"7.982153325"},
{axis:"Deposit Interest Rate",value:"4.485833333"},
{axis:"Lending Interest Rate",value:"18.73"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-20.30124592"},
{axis:"Unemployment",value:""}]
    },
{className:"El Salvador",
axes: [
{axis:"Inflation",value:"-0.73063367"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.455062222"},
{axis:"Unemployment",value:""}]
    },
{className:"San Marino",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Somalia",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Serbia",
axes: [
{axis:"Inflation",value:"1.39235822"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.726074887"},
{axis:"Unemployment",value:""}]
    },
{className:"Sao Tome and Principe",
axes: [
{axis:"Inflation",value:"5.255447451"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Suriname",
axes: [
{axis:"Inflation",value:"6.899804649"},
{axis:"Deposit Interest Rate",value:"7.533333333"},
{axis:"Lending Interest Rate",value:"12.61666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.499332108"},
{axis:"Unemployment",value:""}]
    },
{className:"Slovak Republic",
axes: [
{axis:"Inflation",value:"-0.325219777"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.595020933"},
{axis:"Unemployment",value:""}]
    },
{className:"Slovenia",
axes: [
{axis:"Inflation",value:"-0.518126124"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.879160899"},
{axis:"Unemployment",value:""}]
    },
{className:"Sweden",
axes: [
{axis:"Inflation",value:"-0.046784745"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.093637317"},
{axis:"Unemployment",value:""}]
    },
{className:"Swaziland",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.27"},
{axis:"Lending Interest Rate",value:"9.041666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.657387295"},
{axis:"Unemployment",value:""}]
    },
{className:"Seychelles",
axes: [
{axis:"Inflation",value:"4.041590498"},
{axis:"Deposit Interest Rate",value:"3.161291287"},
{axis:"Lending Interest Rate",value:"12.35502482"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.497813866"},
{axis:"Unemployment",value:""}]
    },
{className:"Syrian Arab Republic",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Chad",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"2.45"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.799999521"},
{axis:"Unemployment",value:""}]
    },
{className:"East Asia and Pacific (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"1.323525489"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.460260277"},
{axis:"Unemployment",value:""}]
    },
{className:"Europe and Central Asia (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.865082117"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.052181309"},
{axis:"Unemployment",value:""}]
    },
{className:"Togo",
axes: [
{axis:"Inflation",value:"1.789864499"},
{axis:"Deposit Interest Rate",value:"3.5"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.475268985"},
{axis:"Unemployment",value:""}]
    },
{className:"Thailand",
axes: [
{axis:"Inflation",value:"-0.895021443"},
{axis:"Deposit Interest Rate",value:"1.416666667"},
{axis:"Lending Interest Rate",value:"6.563333333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.819683122"},
{axis:"Unemployment",value:""}]
    },
{className:"Tajikistan",
axes: [
{axis:"Inflation",value:"5.714559496"},
{axis:"Deposit Interest Rate",value:"4.226196453"},
{axis:"Lending Interest Rate",value:"25.83626016"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.2"},
{axis:"Unemployment",value:""}]
    },
{className:"Turkmenistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.49999991"},
{axis:"Unemployment",value:""}]
    },
{className:"Latin America and the Caribbean (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.143416962"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-0.687050494"},
{axis:"Unemployment",value:""}]
    },
{className:"Middle East and North Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.171442038"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Timor-Leste",
axes: [
{axis:"Inflation",value:"0.63428342"},
{axis:"Deposit Interest Rate",value:"0.777286678"},
{axis:"Lending Interest Rate",value:"13.4977926"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"4.251"},
{axis:"Unemployment",value:""}]
    },
{className:"Tonga",
axes: [
{axis:"Inflation",value:"-1.046360651"},
{axis:"Deposit Interest Rate",value:"3.096113781"},
{axis:"Lending Interest Rate",value:"8.328425429"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"South Asia (IDA and IBRD)",
axes: [
{axis:"Inflation",value:"3.530612226"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"7.196362456"},
{axis:"Unemployment",value:""}]
    },
{className:"Sub-Saharan Africa (IDA and IBRD countries)",
axes: [
{axis:"Inflation",value:"3.796175086"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.97845892"},
{axis:"Unemployment",value:""}]
    },
{className:"Trinidad and Tobago",
axes: [
{axis:"Inflation",value:"4.658171173"},
{axis:"Deposit Interest Rate",value:"1.5"},
{axis:"Lending Interest Rate",value:"8.1825"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.006273702"},
{axis:"Unemployment",value:""}]
    },
{className:"Tunisia",
axes: [
{axis:"Inflation",value:"4.857182282"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.80000008"},
{axis:"Unemployment",value:""}]
    },
{className:"Turkey",
axes: [
{axis:"Inflation",value:"7.670853648"},
{axis:"Deposit Interest Rate",value:"14.91666667"},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.984859202"},
{axis:"Unemployment",value:""}]
    },
{className:"Tuvalu",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"Tanzania",
axes: [
{axis:"Inflation",value:"5.587837361"},
{axis:"Deposit Interest Rate",value:"9.896528105"},
{axis:"Lending Interest Rate",value:"16.10432422"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.967871634"},
{axis:"Unemployment",value:""}]
    },
{className:"Uganda",
axes: [
{axis:"Inflation",value:"5.22542724"},
{axis:"Deposit Interest Rate",value:"12.7676244"},
{axis:"Lending Interest Rate",value:"22.60133971"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"5.04298098"},
{axis:"Unemployment",value:""}]
    },
{className:"Ukraine",
axes: [
{axis:"Inflation",value:"48.72427984"},
{axis:"Deposit Interest Rate",value:"13.01048333"},
{axis:"Lending Interest Rate",value:"21.82294167"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-9.899982989"},
{axis:"Unemployment",value:""}]
    },
{className:"Uruguay",
axes: [
{axis:"Inflation",value:"8.666269871"},
{axis:"Deposit Interest Rate",value:"5.6023041"},
{axis:"Lending Interest Rate",value:"15.84108139"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"0.982258638"},
{axis:"Unemployment",value:""}]
    },
{className:"United States",
axes: [
{axis:"Inflation",value:"0.118627136"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:"3.26"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.425970526"},
{axis:"Unemployment",value:""}]
    },
{className:"Uzbekistan",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"8"},
{axis:"Unemployment",value:""}]
    },
{className:"St Vincent and the Grenadines",
axes: [
{axis:"Inflation",value:"-1.73361195"},
{axis:"Deposit Interest Rate",value:"2.119"},
{axis:"Lending Interest Rate",value:"9.3045"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.451904416"},
{axis:"Unemployment",value:""}]
    },
{className:"Venezuela",
axes: [
{axis:"Inflation",value:"121.7380853"},
{axis:"Deposit Interest Rate",value:"14.88666667"},
{axis:"Lending Interest Rate",value:"19.395"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"-5.7"},
{axis:"Unemployment",value:""}]
    },
{className:"Vietnam",
axes: [
{axis:"Inflation",value:"0.630612105"},
{axis:"Deposit Interest Rate",value:"4.7475"},
{axis:"Lending Interest Rate",value:"7.1175"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.679288789"},
{axis:"Unemployment",value:""}]
    },
{className:"Vanuatu",
axes: [
{axis:"Inflation",value:"2.465656921"},
{axis:"Deposit Interest Rate",value:"1.416666667"},
{axis:"Lending Interest Rate",value:"3.625"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"West Bank and Gaza",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"0.95"},
{axis:"Lending Interest Rate",value:"6.8"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"12.39324294"},
{axis:"Unemployment",value:""}]
    },
{className:"World",
axes: [
{axis:"Inflation",value:"1.439145613"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"2.466404149"},
{axis:"Unemployment",value:""}]
    },
{className:"Samoa",
axes: [
{axis:"Inflation",value:"0.724470135"},
{axis:"Deposit Interest Rate",value:"2.481666667"},
{axis:"Lending Interest Rate",value:"9.389166667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.634776026"},
{axis:"Unemployment",value:""}]
    },
{className:"Yemen",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:""},
{axis:"Unemployment",value:""}]
    },
{className:"South Africa",
axes: [
{axis:"Inflation",value:"4.588271042"},
{axis:"Deposit Interest Rate",value:"6.153333333"},
{axis:"Lending Interest Rate",value:"9.416666667"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.283295722"},
{axis:"Unemployment",value:""}]
    },
{className:"Democratic Republic of the Congo",
axes: [
{axis:"Inflation",value:""},
{axis:"Deposit Interest Rate",value:"3.658333333"},
{axis:"Lending Interest Rate",value:"19.37083333"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"6.91618781"},
{axis:"Unemployment",value:""}]
    },
{className:"Zambia",
axes: [
{axis:"Inflation",value:"10.10069485"},
{axis:"Deposit Interest Rate",value:"8.992284407"},
{axis:"Lending Interest Rate",value:"13.25"},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"3.221575675"},
{axis:"Unemployment",value:""}]
    },
{className:"Zimbabwe",
axes: [
{axis:"Inflation",value:"-2.398709959"},
{axis:"Deposit Interest Rate",value:""},
{axis:"Lending Interest Rate",value:""},
{axis:"Central Government Debt",value:""},
{axis:"GDP",value:"1.073431709"},
{axis:"Unemployment",value:""}]
    }
]]


